﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using Microsoft.Win32; //追加
using Excel = Microsoft.Office.Interop.Excel;
using System.Drawing;
//using Core = Microsoft.Office.Core;

namespace test
{
    /// <summary>
    /// MainWindow.xaml の相互作用ロジック
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.FileName = "";
            ofd.DefaultExt = "*.*";
            if (ofd.ShowDialog() == true)
            {
                textBox1.Text = ofd.FileName;
            }
        }

        private void button2_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.FileName = "";
            ofd.DefaultExt = "*.*";
            if (ofd.ShowDialog() == true)
            {
                textBox2.Text = ofd.FileName;
            }
        }

        private void button3_Click(object sender, RoutedEventArgs e)
        {
            // 入力元のEXCELファイルパス
            string openFilePath = textBox1.Text;
            // 画像の取り込み先シート名
            string targetSheetName = textBox3.Text;
            // 取り込み画像ファイルパス
            string targetImageFilePath = textBox2.Text;
            // 出力先のEXCELファイルパス
            string saveDirectoryPath = System.IO.Path.GetDirectoryName(textBox1.Text);
            string saveFileExtension = System.IO.Path.GetExtension(textBox1.Text);
            string saveFileName = System.IO.Path.GetFileNameWithoutExtension(textBox1.Text) + "_save." + saveFileExtension;
            string saveFilePath = System.IO.Path.Combine(saveDirectoryPath, saveFileName);

            // Sheet1のセルC10にJpeg画像を貼り付ける
            Excel.Application exApp = new Excel.Application();
            Excel.Workbook wkbook;
            Excel.Workbooks wkbooks = exApp.Workbooks;
            Excel.Sheets wkSheet;

            exApp.Visible = true;
            exApp.DisplayAlerts = false;

            try
            {
                wkbook = (Excel.Workbook)wkbooks.Open(openFilePath, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                Excel.Sheets sheets = wkbook.Worksheets;
                Excel.Worksheet wksheet = (Excel.Worksheet)sheets[targetSheetName];
                Excel.Range cells = wksheet.Cells;
                Excel.Range range = (Excel.Range)cells[10, 3];
                range.Select();
                Excel.Pictures pictures = (Excel.Pictures)wksheet.Pictures(Type.Missing);
                Excel.Picture picture = pictures.Insert(targetImageFilePath, Type.Missing);

                // 画像を取り込んだEXCELファイルを保存する
                wkbook.SaveAs(saveFilePath, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                // シートを追加
                Excel.Worksheet newWksheet = wkbook.Worksheets.Add();
                newWksheet.Select(Type.Missing);
                int totalSheets = wkbook.Sheets.Count;
                newWksheet.Move(Type.Missing, wkbook.Worksheets[totalSheets]);

                // シート数の確認
                wkSheet = wkbook.Worksheets;
                var wkSheetCnt = wkSheet.Count.ToString();
                newWksheet.Cells[1, 1] = wkSheetCnt;

                // タイトル
                newWksheet.Cells[1, 1] = "■評価結果";
                newWksheet.Cells[1, 1].Font.Size = 14;

                // 基本情報
                // セルの結合、色の変更
                for (var i = 3; i <= 6; i++)
                {
                    // 範囲開始位置(左上)
                    Excel.Range stRange = newWksheet.Cells[i, 1];
                    // 範囲終了位置(右下)
                    Excel.Range edRange = newWksheet.Cells[i, 2];
                    // 範囲指定
                    var mergeRange = newWksheet.get_Range(stRange, edRange);
                    // 色の変更
                    newWksheet.get_Range(stRange, edRange).Interior.Color = ColorTranslator.ToOle(System.Drawing.Color.FromArgb(255, 255, 153));
                    // セルの結合
                    mergeRange.Merge();
                }
                for (var i = 3; i <= 6; i++)
                {
                    var mergeRange = newWksheet.get_Range("C" + i, "D" + i);
                    mergeRange.Merge();
                }

                // 枠線を引く
                var borderRegion = newWksheet.get_Range("A3", "D6");
                borderRegion.BorderAround(Excel.XlLineStyle.xlContinuous, Excel.XlBorderWeight.xlMedium);


            }
            catch (Exception)
            {
            }

            if ((bool)checkBox1.IsChecked)
            {
                //wkbook.Close();
                exApp.Quit();
            }

            // [参考URL]
            // ●指定したセルに画像を挿入したい
            //    https://social.msdn.microsoft.com/Forums/vstudio/ja-JP/c68f4658-1537-4859-a05d-fbb46ddf28f3?forum=csharpgeneralja
        }
    }
}
