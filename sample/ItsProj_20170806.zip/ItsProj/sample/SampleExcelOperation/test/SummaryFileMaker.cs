﻿using Microsoft.Office.Interop.Excel;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

//using Excel = Microsoft.Office.Interop.Excel;

namespace BeaconDataEvaluator
{
    /// <summary>
    /// サマリファイル作成処理クラス
    /// </summary>
    /// <remarks>
    /// サマリファイルを作成し、該当フォルダに出力処理を行う。
    /// サマリファイル作成に必要な全6ファイル+フォルダパスを入力とする
    ///  ①評価結果
    ///  ②カテゴリ別NG件数カウント結果
    ///  ③評価結果NG項目
    ///  ④オフセット信号同期
    ///  ⑤MAP画像
    ///  ⑥路線別位置情報
    /// </remarks>
    class SummaryFileMaker : IDisposable
    {
        /// <summary>
        /// メンバ変数
        /// </summary>
        private const int maxSheetNum = 20;     //シートの最大枚数(20枚)
        // Excel操作用オブジェクト
        private Application m_xlApp = null;
        private Workbooks m_xlBooks = null;
        private Workbook m_xlBook = null;
        private Sheets m_xlSheets = null;
        private Worksheet m_xlSheet = null;

        private bool isDispose;

        /// <summary>
        /// リリース対象
        /// </summary>
        private enum EnumReleaseMode
        {
            Sheet,
            Sheets,
            Book,
            Books,
            App
        }

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public SummaryFileMaker()
        {
            m_xlApp = new Application();
        }

        /// <summary>
        /// デストラクタ
        /// </summary>
        ~SummaryFileMaker()
        {
            // 呼出し側がDispose()してなかったらここでDispose
            if (isDispose == false)
            {
                Dispose();
            }
        }

        /// <summary>
        /// 解放
        /// </summary>
        public void Dispose()
        {
            // ExcelManagerが使われなくなったときに破棄する資源
            ReleaseExcelComObject(EnumReleaseMode.App);

            // dispose判定フラグON
            isDispose = true;

            // Dispose()が明示的に呼ばれたときは、GCからFinalize()呼び出しをさせない。
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// サマリファイル作成処理を実行する(サマリファイル作成のメイン処理)
        /// </summary>
        /// <param name="summaryInputFilePath">サマリファイル入力パス</param>
        /// <param name="evaluationDatetime">評価日時</param>
        /// <param name="categoryCountResultFileName">カテゴリ別NG件数カウント結果ファイル名</param>
        /// <param name="EvaluationResultNgItemFileName">評価結果NG項目ファイル名</param>
        /// <param name="OffsetSignalSyncValueFileName">オフセット信号同期ファイル名</param>
        /// <param name="MapImageFileName">MAP画像ファイル名</param>
        /// <param name="LocationInfoFileName">路線別位置情報ファイル名</param>
        /// <returns>成功/失敗</returns>
        public bool start(string summaryInputFilePath,
                          string evaluationDatetime,
                          string categoryCountResultFileName,
                          string EvaluationResultNgItemFileName,
                          string OffsetSignalSyncValueFileName,
                          string MapImageFileName,
                          string LocationInfoFileName)
        {
            // 出力ファイルのフルパスを作成
            string outputFolderPath = getOutputFolderPath(summaryInputFilePath);
            string outputPrefectureName = getPrefecture(summaryInputFilePath);
            string outputFileName = getOutputFileName(outputFolderPath, evaluationDatetime, outputPrefectureName);
            string outputFilePath = outputFolderPath + "\\" + outputFileName;

            // Excelシートを開き、Excelファイルのフォーマットを整える
            try
            {
                m_xlBooks = m_xlApp.Workbooks;
                m_xlBook = (Workbook)m_xlBooks.Open(outputFilePath, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                m_xlSheets = m_xlBook.Worksheets;
            }
            catch(Exception)
            {
                // エラー処理
            }

            // 都道府県名、路線No.、版、走行日時、評価日付をサマリファイルに書き込む
            writeHeaderData(categoryCountResultFileName);

            // オフセット信号周期をサマリファイルに書き込む
            writeOffsetSignalData(summaryInputFilePath, OffsetSignalSyncValueFileName);

            // カテゴリ別NG件数カウント結果をサマリファイルに書き込む
            writeCategoryCountResultData(summaryInputFilePath, categoryCountResultFileName);

            // 評価結果(NG)をサマリファイルに書き込む


            // 路線別位置情報をサマリファイルに書き込む


            // MAP(JPEG)をサマリファイルに書き込む

            // 印刷フォーマットを整える

            // Excelファイルを保存し、閉じる

            // ステータスをサマリファイル作成にする


            return false;
        }

        /// <summary>
        /// サマリファイルの大枠を作成する
        /// </summary>
        /// <returns></returns>
        private bool makeSummaryFileFormat()
        {
            return false;
        }

        /// <summary>
        /// 結果ファイル名から、都道府県名、路線No.、版、走行日時、評価日付を取得し、サマリファイルに書き込む
        /// </summary>
        /// <param name="resultFileName">結果ファイル名</param>
        private void writeHeaderData(string resultFileName)
        {
            try
            {
                // ファイル名をカンマでスプリットし、都道府県名、路線No.、版、走行日時、評価日付を取得
                string[] headerData = resultFileName.Split('_');
                string prefectureName = headerData[2];
                string routeNum = headerData[3];
                string version = headerData[4];
                string drivingDatetime = headerData[0];
                string evaluationDate = headerData[5];

                // シート名の取得、選択
                string sheetName = getSheetName(resultFileName);
                m_xlSheet = m_xlBook.Sheets[sheetName];

                // Excelシートに書き込む
                m_xlSheet.Cells[3, 3] = prefectureName;
                m_xlSheet.Cells[4, 3] = routeNum;
                m_xlSheet.Cells[5, 3] = version;
                m_xlSheet.Cells[6, 3] = drivingDatetime.Substring(0, 4) + "/" + 
                                        drivingDatetime.Substring(4, 2) + "/" + 
                                        drivingDatetime.Substring(6, 2) + " " +
                                        drivingDatetime.Substring(9, 2) + ":" +
                                        drivingDatetime.Substring(11, 2) + ":" +
                                        drivingDatetime.Substring(13, 2) + "." +
                                        drivingDatetime.Substring(15, 3);
                m_xlSheet.Cells[3, 8] = evaluationDate.Substring(0, 4) + "/" +
                                        evaluationDate.Substring(4, 2) + "/" +
                                        evaluationDate.Substring(6, 2) + " " +
                                        evaluationDate.Substring(9, 2) + ":" +
                                        evaluationDate.Substring(11, 2) + ":" +
                                        evaluationDate.Substring(13, 2);
            }
            catch (Exception e)
            {
                // エラー処理
                // ヘッダ入力未達成
                System.Console.WriteLine(e.Message);
                throw;
            }
        }

        /// <summary>
        /// オフセット信号周期をサマリファイルに書き込む
        /// </summary>
        /// <param name="summaryInputFilePath">サマリファイル入力パス</param>
        /// <param name="OffsetSignalSyncValueFileName">オフセット信号同期ファイル名</param>
        private void writeOffsetSignalData(string summaryInputFilePath, string OffsetSignalSyncValueFileName)
        {
            try
            {
                // オフセット信号周期のファイルパスを作成し、ファイルを開く
                var filePath = @summaryInputFilePath + "\\" + OffsetSignalSyncValueFileName;
                var sr = new StreamReader(filePath, Encoding.GetEncoding("Shift_JIS"));

                // シート名の取得、選択
                string sheetName = getSheetName(OffsetSignalSyncValueFileName);
                m_xlSheet = m_xlBook.Sheets[sheetName];

                var lineCnt = 0;
                while (!sr.EndOfStream)
                {
                    // ファイルから1行読み込む
                    var line = sr.ReadLine();

                    // ヘッダ行以外であれば、文字列をサマリファイルに出力
                    if (lineCnt != 0)
                    {
                        // オフセット信号周期の書き込み
                        m_xlSheet.Cells[3, 26] = line;
                    }
                }
            }
            catch (Exception e)
            {
                // エラー処理
                // オフセット信号周期書き込み未達成
                System.Console.WriteLine(e.Message);
                throw;
            }
        }

        /// <summary>
        /// カテゴリ別NG件数カウント結果をサマリファイルに書き込む
        /// </summary>
        /// <param name="summaryInputFilePath">サマリファイル入力パス</param>
        /// <param name="categoryCountResultFileName">カテゴリ別NG件数カウント結果</param>
        private void writeCategoryCountResultData(string summaryInputFilePath, string categoryCountResultFileName)
        {
            try
            {
                // カテゴリ別NG件数カウント結果のファイルパスを作成し、ファイルを開く
                var filePath = @summaryInputFilePath + "\\" + categoryCountResultFileName;
                var sr = new StreamReader(filePath, Encoding.GetEncoding("Shift_JIS"));

                // シート名の取得、選択
                string sheetName = getSheetName(categoryCountResultFileName);
                m_xlSheet = m_xlBook.Sheets[sheetName];

                var lineCnt = 0;
                while (!sr.EndOfStream)
                {
                    // ファイルから1行読み込む
                    var line = sr.ReadLine();
                    var values = line.Split(',');

                    switch (lineCnt)
                    {
                        case 1:
                            m_xlSheet.Cells[3, 22] = values[1];
                            break;
                        case 2:
                            m_xlSheet.Cells[4, 22] = values[1];
                            break;
                        case 3:
                            m_xlSheet.Cells[5, 22] = values[1];
                            break;
                        case 4:
                            m_xlSheet.Cells[6, 22] = values[1];
                            break;
                        default:
                            break;
                    }
                }
            }
            catch (Exception e)
            {
                // エラー処理
                // カテゴリ別NG件数カウント結果書き込み未達成
                System.Console.WriteLine(e.Message);
                throw;
            }
        }

        /// <summary>
        /// 路線別位置情報をサマリファイルに書き込む
        /// </summary>
        /// <param name="summaryInputFilePath">サマリファイル入力パス</param>
        /// <param name="LocationInfoFileName">路線別位置情報ファイル名</param>
        private void writeLocationInfoData(string summaryInputFilePath, string LocationInfoFileName)
        {
            try
            {
                // 路線別位置情報のファイルパスを作成し、ファイルを開く
                var filePath = @summaryInputFilePath + "\\" + LocationInfoFileName;
                var sr = new StreamReader(filePath, Encoding.GetEncoding("Shift_JIS"));

                // シート名の取得、選択
                string sheetName = getSheetName(LocationInfoFileName);
                m_xlSheet = m_xlBook.Sheets[sheetName];

                var lineCnt = 0;
                while (!sr.EndOfStream)
                {
                    // ファイルから1行読み込む
                    var line = sr.ReadLine();

                    // ヘッダ行以外であれば、文字列をサマリファイルに出力
                    if (lineCnt != 0)
                    {
                        var values = line.Split(',');

                        // 路線別位置情報の書き込み
                        for (var i = 0; i <= 18; i++)
                        {
                            m_xlSheet.Cells[(lineCnt + 51), (i + 1)] = values[i];
                        }
                    }
                }

                // 交差点数が19未満の場合
                if(lineCnt < 19)
                {
                    for (var i = lineCnt; i <= 18; i++)
                    {
                        for(var j = 1; j <= 18; j++)
                        {
                            m_xlSheet.Cells[(i + 51), (j)] = "'--";
                        }
                    }
                }
            }
            catch (Exception e)
            {
                // エラー処理
                // 路線別位置情報書き込み未達成
                System.Console.WriteLine(e.Message);
                throw;
            }
        }

        /// <summary>
        /// ファイル名からシート名を作成し、シート名を返す
        /// </summary>
        /// <param name="fileName">ファイル名</param>
        /// <returns>シート名</returns>
        private string getSheetName(string fileName)
        {
            string retSheetName = "";

            // ファイル名をカンマでスプリットし、路線No.、走行日時を取得
            string[] headerData = fileName.Split('_');
            string routeNum = headerData[3];
            string drivingDatetime = headerData[0];

            // シート名の取得、選択
            retSheetName = routeNum + "_" + drivingDatetime;

            return retSheetName;
        }

        /// <summary>
        /// ファイルパスから対象の「都道府県No._都道府県名」を取得する
        /// </summary>
        /// <param name="summaryInputFilePath">サマリファイル入力パス</param>
        /// <returns>都道府県No._都道府県名</returns>
        private string getPrefecture(string summaryInputFilePath)
        {
            string retFolderName = "";

            // フォルダパスを\でスプリットし、各フォルダ名を配列に格納する。
            string[] arrayFolderName = summaryInputFilePath.Split('\\');
            // 最後から2番目のフォルダ名を取得し、戻り値用の変数に格納する。
            retFolderName = arrayFolderName[arrayFolderName.Length - 1].Replace("_", "-");

            return retFolderName;
        }

        /// <summary>
        /// サマリファイル入力パスから、出力先のパスを作成する
        /// </summary>
        /// <param name="summaryInputFilePath">サマリファイル入力パス</param>
        /// <returns>都道府県No._都道府県名</returns>
        private string getOutputFolderPath(string summaryInputFilePath)
        {
            string retOutputFilePath = "";
            string[] folderNames = summaryInputFilePath.Split('\\');

            for(var i = 0; i < (folderNames.Length - 3); i++)
            {
                if(i == 0)
                {
                    retOutputFilePath = folderNames[i];
                }
                else
                {
                    retOutputFilePath = retOutputFilePath + "\\" + folderNames[i];
                }
            }

            retOutputFilePath = retOutputFilePath + "\\00_サマリ";

            return retOutputFilePath;
        }

        /// <summary>
        /// 出力ファイル名を取得する
        /// </summary>
        /// <param name="outputFolderPath">出力先のフォルダパス</param>
        /// <param name="evaluationDatetime">評価日時</param>
        /// <param name="prefectureName">都道府県名</param>
        /// <returns>出力ファイル名</returns>
        private string getOutputFileName(string outputFolderPath, string evaluationDatetime, string prefectureName)
        {
            string retFileName = "";
            string baseFileName = evaluationDatetime + "_評価結果サマリ" + prefectureName + "-";

            // 出力先のフォルダパス内に存在する全ファイル名を取得する。
            string[] outputFolderFiles = Directory.GetFiles(outputFolderPath);
            var fileNum = 0;
            if (outputFolderFiles.Length != 0)
            { 
                for (var i = 0; i < outputFolderFiles.Length; i++)
                {
                    // ファイル名内に該当の都道府県名が含まれている場合
                    if (outputFolderFiles[i].IndexOf(prefectureName) > 0)
                    {
                        fileNum++;
                    }
                }
            }
           
            if (fileNum == 0) // ファイルが存在していない場合
            {
                retFileName = baseFileName + (fileNum + 1).ToString() + ".xlsx";
            }
            else // ファイルが存在している場合
            {
                // シート数を確認し、20以上の場合新規ファイル名を作成
                //多分、ここ違う
                string openFilePath = baseFileName + fileNum.ToString() + ".xlsx";
                m_xlBook = (Workbook)m_xlBooks.Open(openFilePath, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                m_xlSheets = m_xlBook.Worksheets;
                if (m_xlSheets.Count >= 20)
                {
                    retFileName = baseFileName + (fileNum + 1).ToString() + ".xlsx";
                }
                else
                {
                    retFileName = baseFileName + fileNum.ToString() + ".xlsx";
                }
                // 一旦Excelファイルを終了
                m_xlBook.Close();
            }
            
            return retFileName;
        }

        /// <summary>
        /// Excelリソース解放
        /// </summary>
        /// <param name="ReleaseMode">リリース対象Enum</param>
        private void ReleaseExcelComObject(EnumReleaseMode ReleaseMode)
        {
            try
            {
                // m_xlSheet解放
                if (m_xlSheet != null)
                {
                    Marshal.ReleaseComObject(m_xlSheet);
                    m_xlSheet = null;
                }
                if (ReleaseMode == EnumReleaseMode.Sheet)
                    return;

                // m_xlSheets解放
                if (m_xlSheets != null)
                {
                    Marshal.ReleaseComObject(m_xlSheets);
                    m_xlSheets = null;
                }
                if (ReleaseMode == EnumReleaseMode.Sheets)
                    return;

                // m_xlBook解放
                if (m_xlBook != null)
                {
                    try
                    {
                        m_xlBook.Close();
                    }
                    finally
                    {
                        Marshal.ReleaseComObject(m_xlBook);
                        m_xlBook = null;
                    }
                }
                if (ReleaseMode == EnumReleaseMode.Book)
                    return;

                // m_xlBooks解放
                if (m_xlBooks != null)
                {
                    Marshal.ReleaseComObject(m_xlBooks);
                    m_xlBooks = null;
                }
                if (ReleaseMode == EnumReleaseMode.Books)
                    return;

                // m_xlApp解放
                if (m_xlApp != null)
                {
                    try
                    {
                        // アラートを戻して終了
                        m_xlApp.DisplayAlerts = true;
                        m_xlApp.Quit();
                    }
                    finally
                    {
                        Marshal.ReleaseComObject(m_xlApp);
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
