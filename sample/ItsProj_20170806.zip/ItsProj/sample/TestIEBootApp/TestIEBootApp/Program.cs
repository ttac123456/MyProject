﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.IO;

namespace TestIEBootApp
{
    class Program
    {
        static void Main(string[] args)
        {
            var IE = new SHDocVw.InternetExplorer();
            IE.Visible = true;
            object URL = @"http://blog.clockahead.com/2015/06/cie-6.html";
            //object URL = @"file://C:/光インフラデータ/TEST/MAP_35_山口_路線29.htm";

            if (System.Net.NetworkInformation.NetworkInterface.GetIsNetworkAvailable())
            {

                IE.Navigate2(ref URL);
                IE.Wait(); //続いてページ内の要素を書き換えるために、ページが表示されるまで待機

                //IE画面をキャプチャする
                var outputPath = @"C:\光インフラデータ\TEST\";
                var jpegPath = Path.Combine(outputPath, Path.ChangeExtension(Path.GetFileName(URL.ToString()), "jpg"));
                IE.Capture(jpegPath);

                Console.WriteLine("IE表示完了");
                Console.ReadKey();

                try
                {
                    IE.Quit();
                }
                catch { }
            }
            else
            {
                Console.WriteLine("インターネット接続なし");
                Console.ReadKey();
            }
        }
    }
}
