﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Forms;

namespace TestIEBootApp
{
    static class SHDovVwEx
    {   
        public static void Wait(this SHDocVw.InternetExplorer ie, int millisecond = 0)
        {
            //while (ie.Busy == true || ie.ReadyState != SHDocVw.tagREADYSTATE.READYSTATE_COMPLETE)
            //{
            //    Thread.Sleep(100);
            //}
            //Thread.Sleep(millisecond);

            while (true)
            {
                try
                {
                    //if (ie.ReadyState == SHDocVw.tagREADYSTATE.READYSTATE_COMPLETE)
                    var aaa = SHDocVw.tagREADYSTATE.READYSTATE_COMPLETE;
                    var bbb = ie.ReadyState;
                    if (aaa == bbb)
                    {
                        break;
                    }
                }
                catch { }
                Thread.Sleep(100);
            }
            Thread.Sleep(millisecond);
        }

        public static void Capture(this SHDocVw.InternetExplorer ie, string jpegPath)
        {
            //IEの座標情報を取得
            var ieWidth = ie.Width;
            var ieHeight = ie.Height;
            var ieLeft = ie.Left;
            var ieTop = ie.Top;
            var posLeftTop = new Point(ieLeft, ieTop);
            var posRightBottom = new Point(ieLeft + ieWidth, ieTop + ieHeight);
            var posOffset = new Point(0, 0);
            //Bitmapの作成
            Bitmap bmp = new Bitmap(ieWidth, ieHeight);
            //Graphicsの作成
            Graphics g = Graphics.FromImage(bmp);
            //範囲を指定して画面コピーする（画面キャプチャ）
            //g.CopyFromScreen(new Point(ieLeft, ieTop), new Point(ieLeft + ieWidth, ieTop + ieHeight), bmp.Size);
            g.CopyFromScreen(posLeftTop, new Point(0, 0), bmp.Size);
            //画像をファイルに保存する
            bmp.Save(jpegPath, System.Drawing.Imaging.ImageFormat.Jpeg);
            //解放
            g.Dispose();
            bmp.Dispose();
        }
    }
}
