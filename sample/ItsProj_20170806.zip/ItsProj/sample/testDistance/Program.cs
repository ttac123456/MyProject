﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace testDistance
{
    /// <summary>
    /// 2次元座標クラス
    /// </summary>
    public class Point
    {
        public double X { get; set; }       ///< x座標
        public double Y { get; set; }       ///< y座標

        /// <summary>
        /// デフォルトコンストラクタ
        /// </summary>
        public Point()
        {
            X = Y = 0;
        }

        /// <summary>
        /// 初期化コンストラクタ(Point)
        /// </summary>
        /// <param name="x">2次元座標X</param>
        /// <param name="y">2次元座標Y</param>
        public Point(double x, double y)
        {
            X = x;
            Y = y;
        }

        /// <summary>
        /// コピーコンストラクタ
        /// </summary>
        /// <param name="previousCoordinate">コピー元の値</param>
        public Point(Point previousPoint)
        {
            this.X = previousPoint.X;
            this.Y = previousPoint.Y;
        }

        public override string ToString()
        {
            return "(" + X + ", " + Y + ")";
        }
    }

    /// <summary>
    /// インポート座標の近接真値座標インデックス割り当てクラス
    /// </summary>
    public class ImportedCoordinate
    {
        public Point ImportedPoint { get; set; }            ///< インポートされた座標
        public int OriginalCoordinateIndex { get; set; }    ///< 真値の座標インデックス

        /// <summary>
        /// デフォルトコンストラクタ
        /// </summary>
        public ImportedCoordinate()
        {
            ImportedPoint.X = 0;
            ImportedPoint.Y = 0;
            OriginalCoordinateIndex = 0;
        }

        /// <summary>
        /// 初期化コンストラクタ(Point)
        /// </summary>
        /// <param name="point">2次元座標</param>
        public ImportedCoordinate(Point point)       
        {
            ImportedPoint = point;
            OriginalCoordinateIndex = 0;
        }

        /// <summary>
        /// 初期化コンストラクタ(x, y)
        /// </summary>
        /// <param name="x">2次元座標X</param>
        /// <param name="y">2次元座標Y</param>
        public ImportedCoordinate(double x, double y)
        {
            ImportedPoint = new Point(x, y);
            OriginalCoordinateIndex = 0;
        }

        /// <summary>
        /// コピーコンストラクタ
        /// </summary>
        /// <param name="previousCoordinate">コピー元の値</param>
        public ImportedCoordinate(ImportedCoordinate previousCoordinate)
        {
            this.ImportedPoint = previousCoordinate.ImportedPoint;
            this.OriginalCoordinateIndex = previousCoordinate.OriginalCoordinateIndex;
        }

        /// 2点間の距離を求める
        /// </summary>
        /// <param name="p1">2次元座標(1)</param>
        /// <param name="p2">2次元座標(2)</param>
        /// <returns>距離</returns>
        public static double Distance(Point p1, Point p2)
        {
            double dx = p1.X - p2.X;
            double dy = p1.Y - p2.Y;
            return Math.Sqrt(dx * dx + dy * dy);
        }

        /// <summary>
        /// インポート座標に最も近い真値座標インデックスを割り当てる
        /// </summary>
        /// <param name="originalCoordinates">インポートされた座標リスト</param>
        /// <param name="importedCoordinates">真値の座標リスト</param>
        public static void ChooseNearestCoordinate(List<Point> originalCoordinates, List<ImportedCoordinate> importedCoordinates)
        {
            foreach (var importedCoordinate in importedCoordinates)
            {
                var distances = new List<double>();
                double minimumDistance = double.MaxValue;
                foreach (var originalCoordinate in originalCoordinates)
                {
                    double distance = Distance(originalCoordinate, importedCoordinate.ImportedPoint);
                    distances.Add(distance);
                    minimumDistance = minimumDistance < distance ? minimumDistance : distance;
                }
                int originalCoordinateIndex = 0;
                foreach (var distance in distances)
                {
                    if (distance == minimumDistance)
                    {
                        importedCoordinate.OriginalCoordinateIndex = originalCoordinateIndex;
                        break;
                    }
                    originalCoordinateIndex++;
                }
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            testGetDistance();
            testChooseNearestCoordinate();

            Console.WriteLine("何かキーを押してください。");
            Console.ReadKey();
        }

        static void testGetDistance()
        {
            Point p1 = new Point(100, 0);
            Point p2 = new Point(400, 400);

            var distance = ImportedCoordinate.Distance(p1, p2);
            Console.WriteLine($"{p1} と {p2} の間の距離は {distance}");
        }

        static void testChooseNearestCoordinate()
        {
            var importedCoordinates = new List<ImportedCoordinate>();
            importedCoordinates.Add(new ImportedCoordinate(new Point(101, 101)));
            importedCoordinates.Add(new ImportedCoordinate(new Point(303, 303)));
            importedCoordinates.Add(new ImportedCoordinate(new Point(505, 505)));

            var originalCoordinates = new List<Point>();
            originalCoordinates.Add(new Point(0, 0));
            originalCoordinates.Add(new Point(100, 100));
            originalCoordinates.Add(new Point(200, 200));
            originalCoordinates.Add(new Point(300, 300));
            originalCoordinates.Add(new Point(305, 305));
            originalCoordinates.Add(new Point(400, 400));
            originalCoordinates.Add(new Point(500, 500));
            originalCoordinates.Add(new Point(600, 600));

            ImportedCoordinate.ChooseNearestCoordinate(originalCoordinates, importedCoordinates);

            int index = 0;
            foreach (var originalCoordinate in originalCoordinates)
            {
                Console.WriteLine($"originalCoordinate[{index++}] = {originalCoordinate}");
            }

            foreach (var importedCoordinate in importedCoordinates)
            {
                Console.WriteLine($"インポート座標 {importedCoordinate.ImportedPoint} の真値座標インデックスは {importedCoordinate.OriginalCoordinateIndex}");
            }
        }

    }
}
