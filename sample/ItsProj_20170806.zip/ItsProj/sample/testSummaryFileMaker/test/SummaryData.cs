﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BeaconDataEvaluator
{
    /// <summary>
    /// サマリーデータ構造体
    /// </summary>
    public struct StSummaryData
    {
        public string FilePath;                         ///< 格納パス
        public string EvaluationResultItemFileName;     ///< 評価結果CSVファイル名
        public string CategoryCountResultFileName;      ///< カテゴリ別NG件数カウント結果CSVファイル名
        public string EvaluationResultNgItemFileName;   ///< 評価結果NG項目CSVファイル名
        public string OffsetSignalSyncValueFileName;    ///< オフセット信号同期CSVファイル名
        public string MapImageFileName;                 ///< 地図(JPEG)ファイル名
        public string LocationInfoFileName;             ///< 路線別位置情報CSVファイル名
    }


}
