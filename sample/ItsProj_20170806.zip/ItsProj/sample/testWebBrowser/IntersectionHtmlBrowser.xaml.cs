﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Microsoft;
using System.Windows.Threading;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace testWebBrowser
{
    //static class SHDovVwEx
    //{
    //    public static void Wait(this SHDocVw.InternetExplorer ie, int millisecond = 0)
    //    {
    //        while (ie.Busy == true || ie.ReadyState != SHDocVw.tagREADYSTATE.READYSTATE_COMPLETE)
    //        {
    //            Thread.Sleep(100);
    //        }
    //        Thread.Sleep(millisecond);
    //    }
    //}

    /// <summary>
    /// IntersectionHtmlBrowser.xaml の相互作用ロジック
    /// </summary>
    public partial class IntersectionHtmlBrowser : Window
    {
        public static Point ImagePictSizeHD = new Point(1366, 768);
        private DispatcherTimer timer;

        public Action<string> OnLoaded;
        public Action OnClosed;

        private CancellationTokenSource cts;
        private bool isLoaded;

        public IntersectionHtmlBrowser()
        {
            InitializeComponent();


            //webBrowserIntersection.

        }

        /// <summary>
        /// ウィンドウのクライアントサイズを設定
        /// </summary>
        /// <param name="w"></param>
        /// <param name="h"></param>
        private void SetWindowSize()
        {
            this.Width = ImagePictSizeHD.X;
            this.Height = ImagePictSizeHD.Y;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            //var axIWebBrowser2 = typeof(WebBrowser).GetProperty("AxIWebBrowser2", BindingFlags.Instance | BindingFlags.NonPublic);
            //var comObj = axIWebBrowser2.GetValue(webBrowserIntersection, null);

            //// JavaScriptのエラー表示を抑止する
            //comObj.GetType().InvokeMember("Silent", BindingFlags.SetProperty, null, comObj, new object[] { true });

            //// Drag&Dropの禁止
            //comObj.GetType().InvokeMember("RegisterAsDropTarget", BindingFlags.SetProperty, null, comObj, new object[] { false, });

            // JavaScriptのエラー表示を抑止する
            webBrowserIntersection.ScriptErrorsSuppressed = true;
            //comObj.GetType().InvokeMember("ScriptErrorsSuppressed", BindingFlags.SetProperty, null, comObj, new object[] { true, });

            // ActiveX実行時のセキュリティ保護警告抑止用文字列
            const string SECURITY_WARNING_SUPPRESSION_STRING = @"< !--saved from url = (0017)http://localhost/ -->";
            // セキュリティ保護警告抑止用文字列はDOCTYPEの次行に記載する
            const string DOCTYPE_STRING = @"< !DOCTYPE html >";

            //InjectAlertBlocker();

            // ウィンドウのクライアントサイズを設定する
            SetWindowSize();

            // 表示ソースを切り替える  
            //webBrowserIntersection.Source = new Uri(@"http://www.atmarkit.co.jp/fdotnet/");
            //webBrowserIntersection.Source = new Uri(@"http://www.microsoft.com");
            webBrowserIntersection.Navigate(@"file:///C:/work/ItsProj/sample/testWebBrowser/DataIntersectionHtml/路線29.htm");
            //webBrowserIntersection.Source = new Uri(@"file://C:/work/ItsProj/sample/testWebBrowser/DataIntersectionHtml/路線29_ori.htm");
            isLoaded = false;


            //var t = Task.Run(() => WaitForLoaded());
            //t.Wait();

            // タイマーを作成する
            timer = new DispatcherTimer(DispatcherPriority.Normal, this.Dispatcher);
            timer.Interval = TimeSpan.FromMilliseconds(100);
            timer.Tick += new EventHandler(DispatcherTimer_Tick);
            // タイマーの実行開始
            timer.Start();

            var doc = webBrowserIntersection.Document;
            //((mshtml.HTMLDocument)doc).body.AttachEventHandler("onload", new EventHandler(MyBodyOnLoad));

        }

        private void InjectAlertBlocker()
        {
            //string alertBlocker = @"window.alert = function () { }; 
            //                window.print = function () { }; 
            //                window.open = function () { }; 
            //                window.onunload = function () { }; 
            //                window.onbeforeunload = function () { };";

            //try
            //{
            //    webBrowserIntersection.InvokeScript("execScript",
            //                                      new Object[] { alertBlocker, "JavaScript" });
            //}
            //catch (Exception ex)
            //{
            //    string msg = "Could not call script: " +
            //                 ex.Message +
            //                "\n\nPlease click the 'Load HTML Document with Script' button to load.";
            //    MessageBox.Show(msg);
            //}
        }

        public void WaitForLoaded(int millisecond = 0)
        {
            cts = new CancellationTokenSource();
            var t = Task.Run(() => waitForLoaded(cts.Token, millisecond));
            t.Wait();

            //var t = Task.Run(() =>
            //{
            //Dispatcher.BeginInvoke(() =>
            //{
            //var browser = webBrowserIntersection;
            //var statusComplete = System.Windows.Forms.WebBrowserReadyState.Complete;
            //while (true == webBrowserIntersection.IsBusy || System.Windows.Forms.WebBrowserReadyState.Complete != webBrowserIntersection.ReadyState)
            //{
            //    Thread.Sleep(100);
            //}
            //Thread.Sleep(millisecond);
            //});
            //});
            //t.Wait();
        }

        private void waitForLoaded(CancellationToken ct, int millisecond)
        {
            while (!ct.IsCancellationRequested)
            {
                if (isLoaded)
                {
                    break;
                }
                Thread.Sleep(100);
            }
        }

        private void DispatcherTimer_Tick(object sender, EventArgs e)
        {
            if (!webBrowserIntersection.IsBusy)
            {
                switch (webBrowserIntersection.ReadyState)
                {
                case System.Windows.Forms.WebBrowserReadyState.Complete:        // コントロールは、新しいドキュメントとそのすべての内容の読み込みを完了しました。
                    break;
                case System.Windows.Forms.WebBrowserReadyState.Interactive:     // コントロールは、表示されたハイパーリンクのクリックなどの、限定的なユーザー操作の許可に十分なドキュメントを読み込みました。
                    break;
                case System.Windows.Forms.WebBrowserReadyState.Loaded:          // コントロールは新しいドキュメントの読み込みと初期化を行いましたが、まだすべてのドキュメント データを受信していません。
                    break;
                case System.Windows.Forms.WebBrowserReadyState.Loading:         // コントロールは新しいドキュメントを読み込んでいます。
                    break;
                case System.Windows.Forms.WebBrowserReadyState.Uninitialized:   // 現在読み込まれているドキュメントはありません。
                    break;
                }
            }
        }

        public void SaveImage(string fileName)
        {
            //WebBrowserコントロールのgraphicsインスタンスを取得する
            System.Drawing.Graphics g = webBrowserIntersection.CreateGraphics();

            //画像を保存するbitmapオブジェクトを生成する
            System.Drawing.Bitmap bmp = new System.Drawing.Bitmap(webBrowserIntersection.Width, webBrowserIntersection.Height);

            //WebBrowserからbitmapオブジェクトに描画する
            webBrowserIntersection.DrawToBitmap(bmp, new System.Drawing.Rectangle(0, 0, webBrowserIntersection.Width, webBrowserIntersection.Height));

            //画像をファイルに保存する
            bmp.Save(fileName, System.Drawing.Imaging.ImageFormat.Jpeg);

            //bitmapオブジェクトを破棄する
            bmp.Dispose();
        }

        // Updates the URL in TextBoxAddress upon navigation.
        private void webBrowserIntersection_Navigated(object sender, WebBrowserNavigatedEventArgs e)
        {
            isLoaded = true;
            Console.WriteLine(webBrowserIntersection.Url.ToString());

            string filepath = @"C:\work\ItsProj\sample\testWebBrowser\DataIntersectionHtml\MAP_35_山口_路線29.jpg";
            var t = Task.Run(() => delaySaveImage(filepath, 3000));
        }

        private void delaySaveImage(string filepath, int millisecond)
        {
            var beginTime = DateTime.Now;
            while (millisecond > 0)
            {
                int passedMillisecond = (int)(DateTime.Now - beginTime).TotalMilliseconds;
                if (passedMillisecond > millisecond)
                    break;
                Thread.Sleep(100);
            }
            timer.Stop();
            Dispatcher.BeginInvoke((Action)(() =>
            {
                SaveImage(filepath);
                OnLoaded(filepath);
                Close();
            }));
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            OnClosed();
        }
    }
}
