﻿using System;
using System.Collections.Generic;

namespace BeaconDataEvaluator
{
    /// <summary>
    /// 走行基本情報構造体
    /// </summary>
    public struct StBasicTripInformation
    {
        public byte PrefecturesId;          // 都道府県ID
        public short RouteNumber;           // 路線番号
        public DateTime TripTimestamp;      // 走行日時
        public byte BeaconDataVersion;      // ビーコンデータバージョン
    }

    /// <summary>
    /// ビーコンデータヘッダ部構造体
    /// </summary>
    /// <remarks>ヘッダ部データ長：5バイト</remarks>
    public struct StBeaconDataHeader
    {
        public byte StandardFlag;       ///< 規格フラグ bin(1) Ｃ－８ １バイト
        public byte InformationFlag;    ///< 情報フラグ bin(1) Ｃ－１
        public byte InformationType;    ///< 情報種別   bin(6) Ｉ－１

        public byte ProvidedTimeInformationHour;  ///< 提供時刻情報：情報提供：時 bin(5) Ｆ－１ ２バイト
        public byte ProvidedTimeInformationMinute;///< 提供時刻情報：情報提供：分 bin(6) Ｆ－２
        public byte Reserved;                     ///< 予備                       bin(5)

        public byte LastFrameFlag;                          ///< 最終フレームフラグ         bin(1) Ｃ－２ １バイト
        public byte FrameNumberWithinSameInformationType;   ///< 同一情報種別内フレーム番号 bin(7) Ａ－７

        public byte FrameDataLength;    ///< フレームデータ有効データ長 bin(8) Ａ－８ １バイト
    }

    /// <summary>
    /// 路線信号情報構造体
    /// </summary>
    /// <remarks>構造体データ長：10バイト + ( I * ( 27バイト + J * 13バイト ) ) + ( 1バイト + K * ( 1バイト + L * 4バイト ) )</remarks>
    public struct StRouteSignalInformation
    {
        public short ElapsedTimeFromReferencePoint;     ///< 基準点からの経過時間       bin(16) Ｓ－16 ２バイト
        public byte Reserved;                           ///< 予備                       bin(8)         １バイト
        public short DifferenceSinceDataGenerationTime; ///< 基準点とデータ生成時刻の差 bin(16) Ｓ－16 ２バイト

        public StInformationValidTime InformationValidTime;   ///< 情報有効時間 ４バイト

        public byte DataTypeIndicator;                  ///< データ形式区分             bin(2)  Ａ－２ １バイト
        public byte NumberOfStorageIntersections;       ///< 格納交差点数：Ｉ           bin(6)  Ａ－６

        public List<StIntersectionRouteSignalInformation> IntersectionRouteSignalInformationList;   ///< 交差点路線信号情報（１～Ｉ） I * ( 39バイト + J * 13バイト )

        public StUTMSLinkInformation UTMSLinkInformation;       ///< ＵＴＭＳリンク情報 1バイト + K * ( 1バイト + L * 4バイト )
    }

    /// <summary>
    /// 情報有効時間構造体
    /// </summary>
    /// <remarks>構造体データ長：4バイト</remarks>
    public struct StInformationValidTime
    {
        public short InformationValidTime1;             ///< 情報有効時間１             bin(16) Ｓ－16 ２バイト
        public short InformationValidTime2;             ///< 情報有効時間２             bin(16) Ｓ－16 ２バイト
    }

    /// <summary>
    /// 交差点路線信号情報構造体
    /// </summary>
    /// <remarks>構造体データ長：27バイト + J * 13バイト</remarks>
    public struct StIntersectionRouteSignalInformation
    {
        public StIntersectionLocationInformation IntersectionLocationInformation;   ///< 交差点位置情報 20バイト

        public StRecommendedSpeedInformation RecommendedSpeedInformation;           ///< 推奨速度情報 １バイト

        public byte SignalControlSupplementInformation;         ///< 信号制御補足情報 bin(8)  Ａ－８ １バイト
        public byte SCSI_OffsetTransferTiming;                  ///< 信号制御補足情報(bit0:オフセット乗り換えタイミング)
        public byte SCSI_SplitControlImplementationStatus;      ///< 信号制御補足情報(bit1:スプリット制御実施状況)
        public byte SCSI_Reserved;                              ///< 信号制御補足情報(Bit2-7:予備)
        public ushort IntersectionIdentificationFlag;           ///< 交差点識別フラグ bin(3)  Ａ－３ ２バイト
        public byte IIF_ProvidedRouteSignalInformation;         ///< 交差点識別フラグ(Bit15:路線信号情報提供対象)
        public byte IIF_ProvidedStatus;                         ///< 交差点識別フラグ(Bit14:提供状態)
        public byte IIF_Reserved;                               ///< 交差点識別フラグ(Bit13:予備)
        public ushort SensitivityEnabledState;                  ///< 感応許可状態     bin(13) Ａ－13
        public byte SES_ResponsiveFAST;                         ///< 感応許可状態(Bit12:FAST感応)
        public byte SES_ResponsivePedestrian;                   ///< 感応許可状態(Bit11:歩行者感応)
        public byte SES_RecallControl;                          ///< 感応許可状態(Bit10:リコール制御)
        public byte SES_ResponsiveDilemma;                      ///< 感応許可状態(Bit9:ジレンマ感応)
        public byte SES_ResponsiveHighway;                      ///< 感応許可状態(Bit8:高速感応)
        public byte SES_ResponsiveBus;                          ///< 感応許可状態(Bit7:バス感応)
        public byte SES_ResponsiveSeniorCitizens;               ///< 感応許可状態(Bit6:高齢者等感応)
        public byte SES_ResponsiveGap;                          ///< 感応許可状態(Bit5:ギャップ感応)
        public byte SES_SensitiveControlOutsideStandardSpec;    ///< 感応許可状態(Bit4:標準仕様外の感応制御)
        public byte SES_Reserved;                               ///< 感応許可状態(Bit3-0:予備)

        public short ElapsedTimeToStartCycleInformation;        ///< サイクル情報（１）開始までの経過時間 bin(16) Ｓ－16 ２バイト
        public byte NumberOfCycleInformation;                   ///< サイクル情報数：Ｊ                   bin(8)  Ａ－８ １バイト

        public List<StCycleInformation> CycleInformationList;   ///< サイクル情報（１～Ｊ） J * 13バイト
    }


    /// <summary>
    /// 交差点位置情報構造体
    /// </summary>
    /// <remarks>構造体データ長：20バイト</remarks>
    public struct StIntersectionLocationInformation
    {
        public StIntersectionReferenceCoordinates IntersectionReferenceCoordinates;         ///< 交差点参照座標 ８バイト
        public ushort ApproximateDistanceToStopLine;            ///< 光ビーコンから当該停止線までの概算道程距離 bin(16) Ａ－16 ２バイト
        public StIntersectionReferenceCoordinates UpstreamIntersectionReferenceCoordinates; ///< 上流交差点参照座標 ８バイト
        public ushort UpstreamApproximateDistanceToStopLine;    ///< 光ビーコンから当該停止線までの概算道程距離 bin(16) Ａ－16 ２バイト
    }

    /// <summary>
    /// 交差点参照座標情報構造体
    /// </summary>
    /// <remarks>構造体データ長：8バイト</remarks>
    public struct StIntersectionReferenceCoordinates
    {
        public ushort SecondaryMeshCoordinates;         ///< ２次メッシュ座標 bin(8)*2  Ｊ－３ ２バイト
        public byte SecondaryMeshCoordinatesLat;        ///< ２次メッシュ座標(緯度)
        public byte SecondaryMeshCoordinatesLon;        ///< ２次メッシュ座標(経度)
        public double SecondaryMeshCoordinatesWGSLat;   ///< ２次メッシュ座標(緯度:世界測地系)
        public double SecondaryMeshCoordinatesWGSLon;   ///< ２次メッシュ座標(経度:世界測地系)
        public ushort NormalizedCoordinatesX;           ///< 正規化座標(X軸)  bin(16)*2 Ｊ－２ ４バイト
        public ushort NormalizedCoordinatesY;           ///< 正規化座標(Y軸)  bin(16)*2 Ｊ－２
        public short HeightCondition;                   ///< 高度             bin(16)   Ｓ－16 ２バイト
    }

    /// <summary>
    /// 推奨速度情報構造体
    /// </summary>
    /// <remarks>構造体データ長：1バイト</remarks>
    public struct StRecommendedSpeedInformation
    {
        public byte PresenceOrAbsenceOfRegulatedSpeedFluctuation;   ///< 規制速度変動有無   bin(1) Ａ－１ １バイト
        public byte MinimumSpeedLimitOfSection;                     ///< 区間の最小規制速度 bin(7) Ａ－７
    }

    /// <summary>
    /// サイクル情報構造体
    /// </summary>
    /// <remarks>構造体データ長：13バイト</remarks>
    public struct StCycleInformation
    {
        public StCycleInformationHeader CycleInformationHeader; ///< サイクル情報ヘッダ １バイト
        public ushort CycleLengthMinimum;       ///< サイクル長（最小） bin(12) Ａ－12 ３バイト
        public ushort CycleLengthMaximum;       ///< サイクル長（最大） bin(12) Ａ－12
        public ushort BlueStartTimeMinimum;     ///< 青開始時間（最小） bin(12) Ａ－12 ３バイト
        public ushort BlueStartTimeMaximum;     ///< 青開始時間（最大） bin(12) Ａ－12
        public ushort BlueEndTimeMinimum;       ///< 青終了時間（最小） bin(12) Ａ－12 ３バイト
        public ushort BlueEndTimeMaximum;       ///< 青終了時間（最大） bin(12) Ａ－12

        public byte CommandCycleLength;         ///< 指令サイクル長     bin(8)  Ａ－８ １バイト
        public ushort YellowTime;               ///< 黄時間             bin(4)  Ａ－４ ２バイト
        public ushort RedStartTimeMaximum;      ///< 赤開始時間（最大） bin(12) Ａ－12
    }

    /// <summary>
    /// サイクル情報ヘッダ構造体
    /// </summary>
    /// <remarks>構造体データ長：1バイト</remarks>
    public struct StCycleInformationHeader
    {
        public byte UseClassification;          ///< 最終サイクル情報の利用区分 bin(2) Ａ－２ １バイト
        public byte NumberOfAppliedCycles;      ///< 適用サイクル数             bin(6) Ａ－６
    }

    /// <summary>
    /// ＵＴＭＳリンク情報構造体
    /// </summary>
    /// <remarks>構造体データ長：1バイト + K * ( 1バイト + L * 4バイト )</remarks>
    public struct StUTMSLinkInformation
    {
        public byte NumberOfGenerations;            ///< 世代数：Ｋ bin(8) Ａ－８ １バイト
        public List<StGeneration> GenerationList;   ///< 第１世代（最新世代）～第Ｋ世代 K * ( 1バイト + L * 4バイト )
    }

    /// <summary>
    /// 世代構造体
    /// </summary>
    /// <remarks>構造体データ長：1バイト + L * 4バイト</remarks>
    public struct StGeneration
    {
        public byte NumberOfStoredLinks;        ///< 格納リンク数：Ｌ bin(8) Ａ－８ １バイト
        public List<StUTMSLink> UTMSLinkList;   ///< ＵＴＭＳリンク（１～Ｌ） L * 4バイト
    }

    /// <summary>
    /// ＵＴＭＳリンク構造体
    /// </summary>
    /// <remarks>構造体データ長：4バイト</remarks>
    public struct StUTMSLink
    {
        public ushort SecondaryMeshCoordinates;         ///< ２次メッシュ座標 bin(16) Ａ－16 ２バイト
        public byte SecondaryMeshCoordinatesLat;        ///< ２次メッシュ座標(緯度)
        public byte SecondaryMeshCoordinatesLon;        ///< ２次メッシュ座標(経度)
        public byte Reserved;                           ///< 予約領域         bin(2)  Ａ－２ ２バイト
        public byte RoadClassification;                 ///< 道路種別         bin(2)  Ｉ－４
        public ushort LinkNumber;                       ///< リンク番号       bin(12) Ａ－12
    }

}
