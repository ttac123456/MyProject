﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace BeaconDataEvaluator
{
    /// <summary>
    /// ビーコンデータ読み込みクラス
    /// </summary>
    /// <remarks>
    /// ファイル「ir_id31_日時.csv」から、ビーコンデータを取得する。
    /// </remarks>
    public class BeaconDataReader
    {
        /// <summary>
        /// 読み込み結果定義
        /// </summary>
        public enum Results
        {
            Success,        ///< 読み込み成功
            OpenError,      ///< ファイルオープンエラー
            LengthError,    ///< データ長不正エラー
            OtherError,     ///< その他のエラー
        }

        /// コンストラクタ
        public BeaconDataReader()
        {
            //test();
        }

        /// デストラクタ
        ~BeaconDataReader()
        {
        }

        /// <summary>
        /// ビーコンデータファイルを読み込む
        /// </summary>
        /// <param name="filepath">読み込み対象ファイルパス</param>
        /// <param name="readBuf">[out]読み込みデータ格納領域</param>
        /// <returns>読み込み結果</returns>
        public Results Read(string filepath, out byte[] readBuf)
        {
            readBuf = null;   // データ格納用配列を初期化

            try
            {
                // ファイルを開く
                FileStream fs = new FileStream(filepath, FileMode.Open, FileAccess.Read);

                // ファイルから読み込んだデータを格納するバイト型配列を作成する
                int fileSize = (int)fs.Length;  // ファイルのサイズ
                readBuf = new byte[fileSize];   // データ格納用配列を確保

                //ファイルを読み込む
                int readSize;               // Readメソッドで読み込んだバイト数
                int remain = fileSize;      // 読み込むべき残りのバイト数
                int bufPos = 0;             // データ格納用配列内の追加位置
                while (remain > 0)
                {
                    // 1024Bytesずつ読み込む
                    readSize = fs.Read(readBuf, bufPos, Math.Min(1024, remain));
                    bufPos += readSize;
                    remain -= readSize;
                }

                // ファイルを閉じる
                fs.Close();
                fs.Dispose();
            }
            catch
            {
                // ファイルオープンエラー
                return Results.OpenError;
            }

            // ファイルオープン成功
            return Results.Success;
        }

        /// <summary>
        /// ビットフィールドデータを取得する
        /// </summary>
        /// <param name="srcBuf">読み出しデータ格納先のバイト配列</param>
        /// <param name="srcPos">読み出しデータ格納先の読み出し位置</param>
        /// <param name="bitPos">読み出しデータのビット位置</param>
        /// <param name="bitLen">読み出しデータのビット幅</param>
        /// <param name="resultValue">ビットフィールド読み出し結果</param>
        /// <returns>読み込み結果</returns>
        /// <remarks>読み出し元データバッファをバイト配列で入力し、</remarks>
        /// <remarks>あわせてデータのビット位置と幅を指定することで、ビットフィールドを読み出す。</remarks>
        public Results GetBitFieldData(byte[] srcBuf, int srcPos, int bitPos, int bitLen, out ulong resultValue)
        {
            resultValue = 0;        // ビットフィールド読み出し結果
            try
            {
                return getBitFieldData(srcBuf, srcPos, bitPos, bitLen, out resultValue);
            }
            catch
            {
                // その他のエラー
                return Results.OtherError;
            }

            /*
             * (例1:byte)
             * bit    01234567
             * target  ++++
             * data   11001100
             * 
             * byteLen = 8
             * bitPos = 1
             * bitLen = 4
             * rightShiftWidth = 3 ( = 8-1-4 = byteLen - bitPos - bitLen)
             */

            /*
             * (例2:short)
             * bit    00000000 00111111
             *        01234567 89012345
             * target    +++++ ++
             * data   11001100 10100101
             * 
             * shortLen = 8
             * bitPos = 3
             * bitLen = 7
             * rightShiftWidth = 6 ( = 16-3-7 = shortLen - bitPos - bitLen)
             */

            /*
             * (例3:byte 次のバイトにまたがる読み出し)
             * byte   0        1
             * bit    00000000 00111111
             *        01234567 89012345
             * target      +++ ++
             * data   11001100 10100101
             * 
             * byteLen = 8
             * bitPos = 5
             * bitLen = 5
             * rightShiftWidth = -2 ( = 8-5-5 = byteLen - bitPos - bitLen)
             * 
             * [補正]
             * leftShiftWidth = 2 ( = (-1) * (-2) = (-1) * rightShiftWidth)
             * rightShiftWidthNextByte = 6 ( = 8-2 = byteLen + rightShiftWidth)
             * result = (byte0 << leftShiftWidth) + (byte1 >> rightShiftWidthNextByte)
             * 
             * [結果]
             * bit    00000
             *        56789
             * target +++++
             * data   10010
             */
        }

        /// <summary>
        /// ビットフィールドデータを取得する
        /// </summary>
        /// <param name="srcBuf">読み出しデータ格納先のバイト配列</param>
        /// <param name="srcPos">読み出しデータ格納先の読み出し位置</param>
        /// <param name="bitPos">読み出しデータのビット位置</param>
        /// <param name="bitLen">読み出しデータのビット幅</param>
        /// <param name="resultValue">ビットフィールド読み出し結果</param>
        /// <returns>読み込み結果</returns>
        /// <remarks>読み出し元データバッファをバイト配列で入力し、</remarks>
        /// <remarks>あわせてデータのビット位置と幅を指定することで、ビットフィールドを読み出す。</remarks>
        public Results getBitFieldData(byte[] srcBuf, int srcPos, int bitPos, int bitLen, out ulong resultValue)
        {
            resultValue = 0;        // ビットフィールド読み出し結果

            // 読み出し対象データのバイト幅を算出する (1:byte/2:ushort/4:uint/8:ulong)
            // NOTE: srcBufからの読み出しバイト幅を決めて、ループをまわしてデータ抽出する。
            int resultByteWidth = 0;
            if (bitLen <= (8 * sizeof(byte)))           resultByteWidth = sizeof(byte);
            else if (bitLen <= (8 * sizeof(ushort)))    resultByteWidth = sizeof(ushort);
            else if (bitLen <= (8 * sizeof(uint)))      resultByteWidth = sizeof(uint);
            else if (bitLen <= (8 * sizeof(ulong)))     resultByteWidth = sizeof(ulong);
            else                                        return Results.LengthError; // 読み出し失敗を返却する

            // 残りバッファサイズをチェックする
            if ((srcPos + resultByteWidth) > srcBuf.Count())
                return Results.LengthError; // 読み出し失敗を返却する

            // 読み出し対象データを抽出する
            int srcReadPos = 0;
            for (; srcReadPos < resultByteWidth; srcReadPos++)
                resultValue = (resultValue << 8) + (srcBuf[srcPos + srcReadPos]);

            // ビットフィールド読み出し用のビットシフト幅を算出する
            int rightShiftWidth = (8 * resultByteWidth) - bitPos - bitLen;
            // ビットシフト幅を補正する
            // NOTE: 次のバイトにまたがる読み出しの場合は補正が必要
            if (rightShiftWidth < 0)
            {
                // まずは、これまでの読み出し結果の左シフト幅を決定する
                int leftShiftWidth = (-1) * rightShiftWidth;
                // 次に、次のバイトで読み出し結果に連結するデータの右シフト幅を決定する
                int rightShiftWidthNextByte = (8 * sizeof(byte)) + rightShiftWidth;
                // 読み出し結果と次バイトの連結データをシフト演算後に加算して、読み出し結果データを作成する
                resultValue = (resultValue << leftShiftWidth)
                            + (ulong)(srcBuf[srcPos + srcReadPos] >> rightShiftWidthNextByte);
            }
            else
                // 読み出し結果をシフト演算して、読み出し結果データを作成する
                resultValue >>= rightShiftWidth;

            // 指定されたビット幅でマスクして、読み出し結果を確定する
            resultValue &= makeMaskBit(bitLen);

            // 読み出し成功を返却する
            return Results.Success;
        }

        /// <summary>
        /// マスクビットを作成する
        /// </summary>
        /// <param name="bitLen">マスク対象ビット長</param>
        /// <returns>マスクビット</returns>
        private ulong makeMaskBit(int bitLen)
        {
            ulong maskBit = 0;
            for (int pos = 0; pos < bitLen; pos++)
            {
                // 対象ビット数分、右端から数値1を連結する
                maskBit <<= 1;
                maskBit += 1;
            }
            return maskBit;
        }

        /// <summary>
        /// プライベートメソッドのテスト
        /// </summary>
        private void test()
        {
            byte[] readBuf;
            var result = Read(@"test.dat", out readBuf);

            // マスクビット作成テスト
            ulong maskBit = 0;
            maskBit = makeMaskBit(0);
            maskBit = makeMaskBit(1);
            maskBit = makeMaskBit(2);
            maskBit = makeMaskBit(3);
            maskBit = makeMaskBit(15);
            maskBit = makeMaskBit(16);
            maskBit = makeMaskBit(17);
            maskBit = makeMaskBit(31);
            maskBit = makeMaskBit(32);
            maskBit = makeMaskBit(33);
            maskBit = makeMaskBit(63);
            maskBit = makeMaskBit(64);
            maskBit = makeMaskBit(65);

            // ビットフィールドデータ取得テスト
            ulong resultValue;
            result = GetBitFieldData(readBuf, 0, 0, 2, out resultValue);
            result = GetBitFieldData(readBuf, 0, 2, 2, out resultValue);
            result = GetBitFieldData(readBuf, 0, 4, 4, out resultValue);
            result = GetBitFieldData(readBuf, 1, 0, 4, out resultValue);
            result = GetBitFieldData(readBuf, 1, 4, 8, out resultValue);
            result = GetBitFieldData(readBuf, 2, 4, 4, out resultValue);
            result = GetBitFieldData(readBuf, 3, 0, 8, out resultValue);
            result = GetBitFieldData(readBuf, 4, 0, 28, out resultValue);
            result = GetBitFieldData(readBuf, 0, 4, 32, out resultValue);
            result = GetBitFieldData(readBuf, 0, 4, 64, out resultValue);
            result = GetBitFieldData(readBuf, 0, 4, 68, out resultValue);
        }

    }
}
