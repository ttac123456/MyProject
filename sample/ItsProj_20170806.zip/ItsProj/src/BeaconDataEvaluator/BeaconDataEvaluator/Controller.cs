﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace BeaconDataEvaluator
{
    /// <summary>
    /// 高度化光インフラデータ解析制御クラス
    /// </summary>
    /// <remarks>インポート/評価/エクスポート処理を順序実行する</remarks>
    public class Controller
    {
        /// <summary>
        /// 実行状態定義
        /// </summary>
        public enum RunStatuses
        {
            Idle,           ///< 開始待ち
            Counting,       ///< 評価総数カウント中
            Importing,      ///< インポート実行中
            Evaluating,     ///< 評価実行中
            Exporting,      ///< エクスポート実行中
        }

        /// <summary>
        /// 実行状態構造体
        /// </summary>
        public struct RunStatus
        {
            public RunStatuses Status;              ///< 実行状態
            public int currentImportCount;          ///< 実行済みインポート処理数
            public int currentEvaluateCount;        ///< 実行済み評価処理数
            public int currentExportCount;          ///< 実行済みエクスポート処理数
            public int totalEvaluateCount;          ///< 評価総数
            public string PrefecturesName;          ///< 都道府県名
            public string RouteName;                ///< 路線名
            public string DrivingDatetime;          ///< 走行日時文字列
            public string BeaconDataVersion;        ///< ビーコンデータバージョン
        }

        /// <summary>
        /// 評価設定構造体
        /// </summary>
        public struct EvaluateSetting
        {
            public string InputPath;                ///< 入力情報フォルダパス
            public string OutputPath;               ///< 出力情報フォルダパス
        }

        /// <summary>
        /// 順序制御タスク実行結果定義
        /// </summary>
        public enum TaskResultCode
        {
            Success,        ///< 成功
            Cancel,         ///< キャンセル
            Failure,        ///< 失敗
        }

        private RunStatus runStatus;                ///< 実行状態
        private EvaluateSetting evaluateSetting;    ///< 評価設定

        private DataImporter dataImporter;          ///< データインポート処理クラス
        private DataEvaluator dataEvaluator;        ///< データ評価処理クラス
        private DataExporter dataExporter;          ///< データエクスポート処理クラス
        private DatabaseAccessor dataBaseAccessor;  ///< データベース通信クラス
        private CsvFileMaker csvfilemaker;          ///< csvファイル作成クラス

        private Task taskOrderdControl = null;              ///< 順序実行タスク
        private CancellationTokenSource cancelTokenSource;  ///< タスクキャンセル用トークン
        public Action<TaskResultCode> OnDone;               ///< 順序実行完了コールバック


        private StBasicTripInformation basicTripInfo;       ///< 走行基本情報
        private StRouteSignalInformation routeSignalInfo;   ///< 路線信号情報

        /// コンストラクタ
        public Controller(System.Windows.Threading.Dispatcher mainWindowDispatcher)
        {
            // データベース通信クラス
            dataBaseAccessor = new DatabaseAccessor();
            // データインポート処理クラスを生成
            dataImporter = new DataImporter(dataBaseAccessor);
            // データ評価処理クラスを生成
            dataEvaluator = new DataEvaluator(dataBaseAccessor);
            // データエクスポート処理クラスを生成
            dataExporter = new DataExporter(dataBaseAccessor, mainWindowDispatcher);
            // csvファイル作成クラスを生成
            csvfilemaker = new CsvFileMaker(dataBaseAccessor);
            // 実行状態を初期化(開始待ち)
            updateRunStatus(RunStatuses.Idle);
        }

        /// デストラクタ
        ~Controller()
        {
        }

        /// <summary>
        /// 解析開始
        /// </summary>
        /// <param name="inputPath">入力情報フォルダパス</param>
        /// <param name="outputPath">出力情報フォルダパス</param>
        public void Start(string inputPath, string outputPath)
        {
            // 評価設定を保持する
            evaluateSetting.InputPath = inputPath;
            evaluateSetting.OutputPath = outputPath;

            // タスクキャンセル用トークンを生成
            if (cancelTokenSource == null)
                cancelTokenSource = new CancellationTokenSource();

            // 順序実行タスクを開始する
            taskOrderdControl = Task.Run(() =>
            {
                executeOrderdControl();
            }, cancelTokenSource.Token).ContinueWith(t => {
                // 後始末
                cancelTokenSource.Dispose();
                cancelTokenSource = null;
            });
        }

        /// <summary>
        /// 解析中断
        /// </summary>
        public void Cancel()
        {
            // インポートを中断する
            dataImporter.Cancel();
            // 評価を中断する
            dataEvaluator.Cancel();
            // エクスポートを中断する
            dataExporter.Cancel();

            try
            {
                // キャンセル要求発行
                if (cancelTokenSource != null)
                    cancelTokenSource.Cancel();
            }
            catch (AggregateException)
            {
                // タスクがキャンセルされた
            }

            // 実行状態を更新(開始待ち)
            updateRunStatus(RunStatuses.Idle);
        }

        /// <summary>
        /// 実行状態を取得する
        /// </summary>
        public RunStatus GetStatus()
        {
            return runStatus;
        }

        /// <summary>
        /// 実行状態を更新する
        /// </summary>
        /// <param name="status">実行状態</param>
        private void updateRunStatus(RunStatuses status)
        {
            // 評価処理数をリセット
            switch (status)
            {
                case RunStatuses.Counting:      // 評価総数カウント中
                    runStatus.currentImportCount = 0;
                    runStatus.currentEvaluateCount = 0;
                    runStatus.currentExportCount = 0;
                    runStatus.totalEvaluateCount = 0;
                    runStatus.PrefecturesName = "";
                    runStatus.RouteName = "";
                    runStatus.DrivingDatetime = "";
                    runStatus.BeaconDataVersion = "";
                   break;
            }

            // 実行状態を更新
            runStatus.Status = status;

            // エクスポート実行中のみ、都道府県名と路線名を取得する
            if (status == RunStatuses.Exporting)
            {
                DatabaseAccessor.StDrivingInfo drivingInfo;
                var drivingInfoId = runStatus.currentExportCount;
                drivingInfo = new DatabaseAccessor.StDrivingInfo();
                dataBaseAccessor.GetDrivingInfo(drivingInfoId, out drivingInfo);
                runStatus.PrefecturesName = $"{drivingInfo.PrefectureId:00}_" + dataBaseAccessor.ReferencePrefectureName(drivingInfo.PrefectureId);
                runStatus.RouteName = $"路線{drivingInfo.RouteNum:000}";
                runStatus.DrivingDatetime = drivingInfo.DrivingDatetime.ToString();
                runStatus.BeaconDataVersion = $"版{(byte)drivingInfo.Version}";
                //runStatus.BeaconDataVersion = (drivingInfo.Version == DatabaseAccessor.EvaluationVersion.Version1 ? "版1" : "版2");
            }
        }

        /// <summary>
        /// 評価を順序実行する
        /// </summary>
        private void executeOrderdControl()
        {
            try
            {
                // 評価結果格納テーブルをクリアする(再構築する)
                clearEvaluateResultTables();

                // 評価総数カウントを実行する
                executeCounting();
                // 順序実行のキャンセル要求があれば、OperationCanceledException例外をスロー
                cancelTokenSource.Token.ThrowIfCancellationRequested();

                // 実行状態を更新(インポート実行中)
                updateRunStatus(RunStatuses.Importing);

                while (runStatus.currentImportCount < runStatus.totalEvaluateCount)
                {
                    // インポートを実行する
                    var importResult = executeImporting();
                    // 順序実行のキャンセル要求があれば、OperationCanceledException例外をスロー
                    cancelTokenSource.Token.ThrowIfCancellationRequested();
                    //Thread.Sleep(5);

                    // 評価を実行する
                    executeEvaluating(importResult);
                    // 順序実行のキャンセル要求があれば、OperationCanceledException例外をスロー
                    cancelTokenSource.Token.ThrowIfCancellationRequested();
                    //Thread.Sleep(5);
                }

                while (runStatus.currentExportCount < runStatus.totalEvaluateCount)
                {
                    // エクスポートを実行する
                    executeExporting();
                    // 順序実行のキャンセル要求があれば、OperationCanceledException例外をスロー
                    cancelTokenSource.Token.ThrowIfCancellationRequested();
                    Thread.Sleep(5);
                }
                string evaluationimplementationhistory_filename = csvfilemaker.EvaluationImplementationHistoryCsvStart(evaluateSetting.OutputPath);

                // 実行状態を更新(開始待ち)
                updateRunStatus(RunStatuses.Idle);

                // 評価成功をUIにコールバックする
                doneOrderdControl(TaskResultCode.Success);
            }
            catch (OperationCanceledException)
            {
                string evaluationimplementationhistory_filename = csvfilemaker.EvaluationImplementationHistoryCsvStart(evaluateSetting.OutputPath);
                // 評価キャンセルをUIにコールバックする
                doneOrderdControl(TaskResultCode.Cancel);
            }
            catch
            {
                string evaluationimplementationhistory_filename = csvfilemaker.EvaluationImplementationHistoryCsvStart(evaluateSetting.OutputPath);
                // 評価失敗をUIにコールバックする
                doneOrderdControl(TaskResultCode.Failure);
            }
        }

        /// <summary>
        /// 評価結果格納テーブルをクリアする(再構築する)
        /// </summary>
        private void clearEvaluateResultTables()
        {
            // 走行基本情報テーブルを生成する
            dataBaseAccessor.CreateDrivingInfo();
            // 路線信号基本情報テーブルを生成する
            dataBaseAccessor.CreateRouteSignalInfo();
            // 交差点路線信号情報テーブルを生成する
            dataBaseAccessor.CreateIntersectionRouteSignalInfo();
            // サイクル情報テーブルを生成する
            dataBaseAccessor.CreateCycleInfo();
            // 世代テーブルを生成する
            dataBaseAccessor.CreateGeneration();
            // UTMSリンクテーブルを生成する
            dataBaseAccessor.CreateUTMSLink();
            // 評価実施履歴テーブルを生成する
            dataBaseAccessor.CreateEvaluationImplementationHistory();
        }

        /// <summary>
        /// 評価総数カウントを実行する
        /// </summary>
        private void executeCounting()
        {
            // 実行状態を更新(評価総数カウント中)
            updateRunStatus(RunStatuses.Counting);

            // 評価対象のファイル数を数える
            runStatus.totalEvaluateCount = dataImporter.CountEvaluatedFiles(evaluateSetting.InputPath);
        }

        /// <summary>
        /// インポートを実行する
        /// </summary>
        private bool executeImporting()
        {
            runStatus.currentImportCount++;

            // 実行状態を更新(インポート実行中)
            updateRunStatus(RunStatuses.Importing);

            // インポートを実行する
            return dataImporter.Execute(out basicTripInfo, out routeSignalInfo);
        }

        /// <summary>
        ///  評価を実行する
        /// </summary>
        /// <param name="importResult">インポート実行結果</param>
        private void executeEvaluating(bool importResult)
        {
            runStatus.currentEvaluateCount++;

            // 実行状態を更新(評価実行中)
            updateRunStatus(RunStatuses.Evaluating);

            // インポートを実行する
            dataEvaluator.Execute(importResult, basicTripInfo, routeSignalInfo);
        }

        /// <summary>
        /// エクスポートを実行する
        /// </summary>
        private void executeExporting()
        {
            runStatus.currentExportCount++;

            // 実行状態を更新(エクスポート実行中)
            updateRunStatus(RunStatuses.Exporting);

            // エクスポートを実行する
            var drivingInfoId = runStatus.currentExportCount;
            dataExporter.Execute(drivingInfoId, evaluateSetting.InputPath, evaluateSetting.OutputPath);
        }

        /// <summary>
        /// 順序実行を完了する
        /// </summary>
        /// <param name="result">順序制御タスク実行結果</param>
        private void doneOrderdControl(TaskResultCode result)
        {
            // 評価完了コールバック
            OnDone(result);
        }

    }
}
