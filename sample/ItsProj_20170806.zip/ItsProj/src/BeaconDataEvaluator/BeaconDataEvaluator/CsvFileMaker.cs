﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CsvHelper;
using CsvHelper.Configuration;

namespace BeaconDataEvaluator
{
    class CsvFileMaker
    {
        private DatabaseAccessor dataBaseAccessor;  ///< データベース通信クラス
        private const string EVALUATRESULT_FILENAME_KEYWORD = "_評価結果_";                             ///< 評価結果ファイル名キーワード
        private const string CATEGORYNGCOUNT_FILENAME_KEYWORD = "_カテゴリ別NG件数カウント結果_";       ///< カテゴリ別NG件数カウント結果ファイル名キーワード
        private const string EVALUATRESULTNGITEM_FILENAME_KEYWORD = "_評価結果NG項目_";                 ///< 評価結果NG項目ファイル名キーワード
        private const string OFFSETSIGNALSYNC_FILENAME_KEYWORD = "_オフセット信号同期_";                ///< オフセット信号同期ファイル名キーワード
        private const string AREACHECK_ITEM = "範囲チェックNG件数";                                     ///< 範囲チェック出力文字列
        private const string VALUECHECK_ITEM = "値チェックNG件数";                                      ///< 値チェック出力文字列
        private const string BITCHECKNGCNT_ITEM = "BITチェックNG件数";                                  ///< BITチェック出力文字列
        private const string CONSISTENCYCHECK_ITEM = "整合性チェックNG件数";                            ///< 整合性チェック出力文字列

        /// <summary>
        /// 評価結果Csvファイル出力情報プロパティクラス
        /// </summary>
        public class CsvEvaluatResult
        {
            public string No { get; set; }                                  // No.
            public string Item { get; set; }                                // 項目
            public string Result1 { get; set; }                             // 光ビーコン規格仕様  
            public string Result2 { get; set; }                             // UTMS協会仕様
            public string Result3 { get; set; }                             // その他
            public string Specification { get; set; }                       // 仕様
            public string Category { get; set; }                            // チェック分類
            public string Value { get; set; }                               // 値
            public string Judge { get; set; }                               // 判定
            public long ItemId { get; set; }                                // 項目ID
        }

        /// <summary>
        /// 評価結果Csvファイル出力情報マッピングルールクラス
        /// </summary>
        public class CsvEvaluatResultMapper : CsvClassMap<CsvEvaluatResult>
        {
            public CsvEvaluatResultMapper()
            {
                Map(x => x.No).Index(0).Name("No.");
                Map(x => x.Item).Index(1).Name("項目");
                Map(x => x.Result1).Index(2).Name("光ビーコン規格仕様");
                Map(x => x.Result2).Index(3).Name("UTMS協会仕様");
                Map(x => x.Result3).Index(4).Name("その他");
                Map(x => x.Specification).Index(5).Name("仕様");
                Map(x => x.Category).Index(6).Name("チェック分類");
                Map(x => x.Value).Index(7).Name("値");
                Map(x => x.Judge).Index(8).Name("判定");
                Map(x => x.ItemId).Ignore();        // CVS出力しない
            }
        }

        /// <summary>
        /// カテゴリ別NG件数カウント結果Csvファイル出力情報プロパティクラス
        /// </summary>
        public class CsvCategoryNgCount
        {
            public string JudgementType { get; set; }
            public string NgCount { get; set; }
        }

        /// <summary>
        /// カテゴリ別NG件数カウント結果Csvファイル出力情報マッピングルールクラス
        /// </summary>
        public class CsvCategoryNgCountMapper : CsvClassMap<CsvCategoryNgCount>
        {
            public CsvCategoryNgCountMapper()
            {
                Map(x => x.JudgementType).Index(0).Name("判定種別");
                Map(x => x.NgCount).Index(1).Name("件数");
            }
        }

        /// <summary>
        /// 評価結果NG項目Csvファイル出力情報プロパティクラス
        /// </summary>
        public class CsvEvaluatResultNgItem
        {
            public string No { get; set; }                                  // No.
            public string Item { get; set; }                                // 項目
            public string Value { get; set; }                               // 値
            public string Category { get; set; }                            // チェック分類
            public string Result1 { get; set; }                             // 光ビーコン規格仕様  
            public string Result2 { get; set; }                             // UTMS協会仕様
            public string Result3 { get; set; }                             // その他
        }

        /// <summary>
        /// 評価結果NG項目Csvファイル出力情報マッピングルールクラス
        /// </summary>
        public class CsvEvaluatResultNgItemMapper : CsvClassMap<CsvEvaluatResultNgItem>
        {
            public CsvEvaluatResultNgItemMapper()
            {
                Map(x => x.No).Index(0).Name("No.");
                Map(x => x.Item).Index(1).Name("項目");
                Map(x => x.Value).Index(2).Name("値");
                Map(x => x.Category).Index(3).Name("チェック分類");
                Map(x => x.Result1).Index(4).Name("光ビーコン規格仕様");
                Map(x => x.Result2).Index(5).Name("UTMS協会仕様");
                Map(x => x.Result3).Index(6).Name("その他");
                
            }
        }


        /// <summary>
        /// オフセット信号同期Csvファイル出力情報プロパティクラス
        /// </summary>
        public class CsvOffsetSignalSync
        {
            public string OffsetSignalSyncValue { get; set; }
        }

        /// <summary>
        /// オフセット信号同期Csvファイル出力情報マッピングルールクラス
        /// </summary>
        public class CsvCsvOffsetSignalSyncMapper : CsvClassMap<CsvOffsetSignalSync>
        {
            public CsvCsvOffsetSignalSyncMapper()
            {
                Map(x => x.OffsetSignalSyncValue).Index(0).Name("オフセット信号同期(分)");
            }
        }

        /// <summary>
        /// 路線別位置情報CSVファイル出力情報プロパティクラス
        /// </summary>
        public class CsvLocationInfoByRoute
        {
            public string InterSectionOrder { get; set; }               // 交差点順序
            public string ControlManagementNum { get; set; }            // 管制管理番号
            public string IntersectionName { get; set; }                // 交差点名称
            public string SecondaryMeshCoordinates { get; set; }        // 2次メッシュ座標（10進）
            public string NormalizedCoordinateX { get; set; }           // 正規化座標X（10進）
            public string NormalizedCoordinateY { get; set; }           // 正規化座標Y（10進）
            public string SignalInfoProvision { get; set; }             // 信号情報提供有無
            public string LatitudeVics { get; set; }                    // 緯度（度）
            public string LongtudeVics { get; set; }                    // 経度（度）
            public string LatitudeTrue { get; set; }                    // 真値_緯度（度）
            public string LongtudeTrue { get; set; }                    // 真値_経度（度）
            public string DestinationDistanceTrue { get; set; }         // 真値_道程距離（m）
            public string DataPresence { get; set; }                    // データ有無
            public string LatitudeResult { get; set; }                  // 走行結果_緯度（度）
            public string LongtudeResult { get; set; }                  // 走行結果_経度（度）
            public string DestinationDistanceResult { get; set; }       // 走行結果_道程距離（m）
            public string CoordinateErrorRange { get; set; }            // 誤差_座標（m）
            public string DestinationDistanceErrorRange { get; set; }   // 誤差_道程距離（m）
        }

        /// <summary>
        /// 路線別位置情報CSVファイル出力情報マッピングルールクラス
        /// </summary>
        public class CsvLocationInfoByRouteMapper : CsvClassMap<CsvLocationInfoByRoute>
        {
            public CsvLocationInfoByRouteMapper()
            {
                Map(x => x.InterSectionOrder).Index(0).Name("交差点順序");
                Map(x => x.ControlManagementNum).Index(1).Name("管制管理番号");
                Map(x => x.IntersectionName).Index(2).Name("交差点名称");
                Map(x => x.SecondaryMeshCoordinates).Index(3).Name("2次メッシュ座標（10進）");
                Map(x => x.NormalizedCoordinateX).Index(4).Name("正規化座標X（10進）");
                Map(x => x.NormalizedCoordinateY).Index(5).Name("正規化座標Y（10進）");
                Map(x => x.SignalInfoProvision).Index(6).Name("信号情報提供有無");
                Map(x => x.LatitudeVics).Index(7).Name("緯度（度）");
                Map(x => x.LongtudeVics).Index(8).Name("経度（度）");
                Map(x => x.LatitudeTrue).Index(9).Name("真値_緯度（度）");
                Map(x => x.LongtudeTrue).Index(10).Name("真値_経度（度）");
                Map(x => x.DestinationDistanceTrue).Index(11).Name("真値_道程距離（m）");
                Map(x => x.DataPresence).Index(12).Name("データ有無");
                Map(x => x.LatitudeResult).Index(13).Name("走行結果_緯度（度）");
                Map(x => x.LongtudeResult).Index(14).Name("走行結果_経度（度）");
                Map(x => x.DestinationDistanceResult).Index(15).Name("走行結果_道程距離（m）");
                Map(x => x.CoordinateErrorRange).Index(16).Name("誤差_座標（m）");
                Map(x => x.DestinationDistanceErrorRange).Index(17).Name("誤差_道程距離（m）");
            }
        }

        /// <summary>
        /// 評価実施履歴Csvファイル出力情報プロパティクラス
        /// </summary>
        public class CsvEvaluationImplementationHistory
        {
            public string PrefectureName { get; set; }                                  // 都道府県名
            public string RouteNum { get; set; }                                // 路線番号
            public string DrivingDatetime { get; set; }                               // 走行時刻
            public string SpecificationVersion { get; set; }                            // 版
            public string EvaluationDatetime { get; set; }                             // 評価時刻  
            public string Status { get; set; }                             // ステータス
        }

        /// <summary>
        /// 評価実施履歴Csvファイル出力情報マッピングルールクラス
        /// </summary>
        public class CsvCsvEvaluationImplementationHistoryMapper : CsvClassMap<CsvEvaluationImplementationHistory>
        {
            public CsvCsvEvaluationImplementationHistoryMapper()
            {
                Map(x => x.PrefectureName).Index(0).Name("都道府県名");
                Map(x => x.RouteNum).Index(1).Name("路線番号");
                Map(x => x.DrivingDatetime).Index(2).Name("走行時刻");
                Map(x => x.SpecificationVersion).Index(3).Name("版");
                Map(x => x.EvaluationDatetime).Index(4).Name("評価時刻");
                Map(x => x.Status).Index(5).Name("ステータス");
            }
        }


        /// コンストラクタ
        public CsvFileMaker(DatabaseAccessor dbAccessor)
        {
            // データベース通信クラスを保持
            dataBaseAccessor = dbAccessor;
        }

        /// デストラクタ
        ~CsvFileMaker()
        {
        }

        /// <summary>
        /// 評価結果CSVファイル作成
        /// </summary>
        /// <param name="drivingInfoId">走行基本情報ID</param>
        /// <param name="han_ver">走行データの版</param>
        /// <param name="filepath">ファイルパス</param>
        /// <param name="outputCsvList">[out]評価結果CSVファイル出力データ</param>
        /// <returns> 評価結果CSVファイル名</returns>
        public string EvaluatResultCsvStart(int drivingInfoId, DatabaseAccessor.EvaluationVersion han_ver, string filepath, out List<CsvFileMaker.CsvEvaluatResult> outputCsvList)
        {
            string res = "";
            Boolean intersectionInfoData = false;
            Boolean cycleInfoData = false;
            Boolean generationData = false;
            Boolean utmsData = false;
            CsvEvaluatResult outputCsvgenerationRow;

            // 評価結果Csvファイル出力情報プロパティリスト(まとめて出力するためのリスト)を生成
            outputCsvList = new List<CsvEvaluatResult>();
            // 世代情報数の出力情報を格納しておく(通し番号のNoは世代情報出力時に格納)
            // 世代数情報は世代情報とDBの階層が違う、世代数は路線信号基本情報と同じ階層に格納されている
            // そのため路線信号基本情報を取得時に世代数の有無と世代数情報を格納しておき、後で世代情報と同じタイミングで出力情報に格納する
            outputCsvgenerationRow = new CsvEvaluatResult();

            try
            {
                // 評価結果Csvの「No」に格納する通し番号
                int no = 1;

                // ■■■■■■■■■■■■■■■■■■■■
                // 路線信号基本情報を出力リストへ格納
                // ■■■■■■■■■■■■■■■■■■■■
                // 路線信号基本情報用の評価結果Csvファイル出力情報リストを生成
                List<DatabaseAccessor.StCsvEvaluatResultInfo> csvRouteSignalInfos;
                // 路線信号基本情報を取得
                dataBaseAccessor.GetCsvEvaluatResultInfo(drivingInfoId, DatabaseAccessor.CsvEvalResGetDataType.RouteSignal_Info, out csvRouteSignalInfos);
                // 取得した情報から路線信号基本情報までを評価結果Csvファイル出力情報プロパティリストへ格納
                foreach (DatabaseAccessor.StCsvEvaluatResultInfo n in csvRouteSignalInfos)
                {
                    // 版1の場合、路線信号基本情報の出力完了(版1：評価ID16)でループを抜ける
                    if (han_ver == DatabaseAccessor.EvaluationVersion.Version1)
                    {
                        if (n.EvalSpecId == 16)
                        {
                            break;
                        }
                    }
                    else if (han_ver == DatabaseAccessor.EvaluationVersion.Version2)
                    {   //版2の場合、路線信号基本情報の出力完了(版2：評価ID139)の場合、次の項目である世代数(評価ID245)の有無を確認しループを抜ける
                        if ((n.EvalSpecId == 139) || (n.EvalSpecId == 244))
                        {
                            continue;
                        }
                        else if (n.EvalSpecId == 245)
                        { // 判定がOKの場合(世代数(評価ID245)が1～3)、UTMS情報有りに設定
                            if (n.Judge == true)
                            {
                                generationData = true;
                                // 項目(出力文字列)を出力データに格納
                                outputCsvgenerationRow.Item = n.Item;
                                // 仕様提供元に○を設定
                                outputCsvgenerationRow.Result1 = "○";
                                outputCsvgenerationRow.Result2 = "○";
                                outputCsvgenerationRow.Result3 = "--";
                                // 仕様(仕様項目)を出力データに格納
                                outputCsvgenerationRow.Specification = n.Specification;
                                // チェック分類を出力データに格納
                                if (n.Category != null)
                                {
                                    outputCsvgenerationRow.Category = n.Category;
                                }
                                else
                                {
                                    outputCsvgenerationRow.Category = "--";
                                }
                                // 値を出力データに格納
                                if (n.Value != null)
                                {
                                    outputCsvgenerationRow.Value = n.Value.ToString();
                                }
                                else
                                {
                                    outputCsvgenerationRow.Value = "--";
                                }

                                // 判定を出力データに格納
                                if (n.Judge == true)
                                {
                                    outputCsvgenerationRow.Judge = "OK";
                                }
                                else if (n.Judge == false)
                                {
                                    outputCsvgenerationRow.Judge = "NG";
                                }
                                else
                                {
                                    outputCsvgenerationRow.Judge = "--";
                                }
                                // 項目IDを出力データ格納
                                outputCsvgenerationRow.ItemId = n.ItemId;

                                break;
                            }
                        }
                    }

                    // 格納交差点数の有無を確認(版1：評価ID14、版2：評価ID137)
                    if ((n.EvalSpecId == 14) || (n.EvalSpecId == 137))
                    {
                        // 判定がOKの場合(格納交差点数が1～16)、交差点情報有りに設定
                        if (n.Judge == true)
                        {
                            intersectionInfoData = true;
                        }
                    }

                    // 評価結果Csvファイル出力情報1レコードを生成
                    var outputCsvRow = new CsvEvaluatResult();
                    outputCsvRow.Result1 = "--";
                    outputCsvRow.Result2 = "--";
                    outputCsvRow.Result3 = "--";

                    int listCnt = outputCsvList.Count();
                    // 前項目(一つ前の項目)を参照しながら進めるため、1項目目は無条件に格納
                    if (listCnt != 0)
                    {
                        /// 仕様提供元が違う場合でも、項目、仕様が同一の場合は同じ行に出力するため、
                        /// 項目、仕様が同一なら前項目の仕様提供元を「○」にする
                        bool same_line = false;
                        for (int ItemCnt = listCnt; ItemCnt > 0; ItemCnt--)
                        {
                            // 項目IDが同じ場合(仕様項目が同じ可能性が一つ前だけでないため、項目IDが同じ間は遡ってループ)
                            if (n.ItemId == outputCsvList[ItemCnt - 1].ItemId)
                            {
                                // 現在の項目が前項目と同一だった場合
                                if (n.Item == outputCsvList[ItemCnt - 1].Item)
                                {
                                    // 現在の仕様が前項目と同一だった場合
                                    if (n.Specification == outputCsvList[ItemCnt - 1].Specification)
                                    {
                                        // 前項目の仕様提供元出力データに現在の仕様提供元を格納
                                        if (n.SpecificationSource == "光ビーコン規格仕様")
                                        {
                                            outputCsvList[ItemCnt - 1].Result1 = "○";
                                        }
                                        else if (n.SpecificationSource == "UTMS協会データチェック内容")
                                        {
                                            outputCsvList[ItemCnt - 1].Result2 = "○";
                                        }
                                        else if (n.SpecificationSource == "その他")
                                        {
                                            outputCsvList[ItemCnt - 1].Result3 = "○";
                                        }
                                        same_line = true;
                                        break;
                                    }
                                }
                            }
                        }
                        // 同一項目で同じ行に出力したためnoを更新せず次項目へ進めるため
                        if (same_line == true) { continue; }
                    }

                    // 通し番号のNoを出力データに格納
                    outputCsvRow.No = no.ToString();
                    // 項目(出力文字列)を出力データに格納
                    outputCsvRow.Item = n.Item;
                    // 仕様提供元に○を設定
                    if (n.SpecificationSource == "光ビーコン規格仕様")
                    {
                        outputCsvRow.Result1 = "○";
                    }
                    else if (n.SpecificationSource == "UTMS協会データチェック内容")
                    {
                        outputCsvRow.Result2 = "○";
                    }
                    else if (n.SpecificationSource == "その他")
                    {
                        outputCsvRow.Result3 = "○";
                    }
                    // 仕様(仕様項目)を出力データに格納
                    outputCsvRow.Specification = n.Specification;
                    // チェック分類を出力データに格納
                    if (n.Category != null)
                    {
                        outputCsvRow.Category = n.Category;
                    }
                    else
                    {
                        outputCsvRow.Category = "--";
                    }
                    // 値を出力データに格納
                    if (n.Value != null)
                    {
                        outputCsvRow.Value = n.Value.ToString();
                    }
                    else
                    {
                        outputCsvRow.Value = "--";
                    }

                    // 判定を出力データに格納
                    if (n.Judge == true)
                    {
                        outputCsvRow.Judge = "OK";
                    }
                    else if (n.Judge == false)
                    {
                        outputCsvRow.Judge = "NG";
                    }
                    else
                    {
                        outputCsvRow.Judge = "--";
                    }
                    // 項目IDを出力データ格納
                    outputCsvRow.ItemId = n.ItemId;
                    outputCsvList.Add(outputCsvRow);
                    no++;
                }

                if (intersectionInfoData == true)
                {
                    // ■■■■■■■■■■■■■■■■■■■■
                    // 交差点路線信号情報を出力リストへ格納
                    // ■■■■■■■■■■■■■■■■■■■■
                    // 交差点路線信号情報用の評価結果Csvファイル出力情報リストを生成
                    List<DatabaseAccessor.StCsvEvaluatResultInfo> csvInterSectionInfos;
                    // 交差点路線信号情報を取得
                    dataBaseAccessor.GetCsvEvaluatResultInfo(drivingInfoId, DatabaseAccessor.CsvEvalResGetDataType.Intersection_Info, out csvInterSectionInfos);
                    // 取得した情報から交差点路線信号情報を評価結果Csvファイル出力情報プロパティリストへ格納
                    foreach (DatabaseAccessor.StCsvEvaluatResultInfo n in csvInterSectionInfos)
                    {
                        // 格納サイクル情報数の有無を確認(版1：評価ID87、版2：評価ID208)
                        if ((n.EvalSpecId == 87) || (n.EvalSpecId == 208))
                        {
                            // 判定がOKの場合(サイクル情報数が1～8)、サイクル情報有りに設定
                            if (n.Judge == true)
                            {
                                cycleInfoData = true;
                            }
                        }

                        // 評価結果Csvファイル出力情報1レコードを生成
                        var Intersection_outputCsvRow = new CsvEvaluatResult();
                        Intersection_outputCsvRow.Result1 = "--";
                        Intersection_outputCsvRow.Result2 = "--";
                        Intersection_outputCsvRow.Result3 = "--";

                        int listCnt = outputCsvList.Count();
                        // 前項目(一つ前の項目)を参照しながら進めるため、1項目目は無条件に格納
                        if (listCnt != 0)
                        {
                            /// 仕様提供元が違う場合でも、項目、仕様が同一の場合は同じ行に出力するため、項目、仕様が同一なら前項目の仕様提供元を「○」にする
                            /// 比較する前項目の文字列は交差点番号に置換されているため現在の項目も置換する(n.Itemは変更不可のため別変数)
                            // 項目の文字列内「(I)」を交差点番号に置換する
                            string cmp_nItem = n.Item.Replace("(I)", $"({n.BelongingId_1})");
                            bool same_line = false;
                            for (int ItemCnt = listCnt; ItemCnt > 0; ItemCnt--)
                            {
                                // 項目IDが同じ場合(仕様項目が同じ可能性が一つ前だけでないため、項目IDが同じ間は遡ってループ)
                                if (n.ItemId == outputCsvList[ItemCnt - 1].ItemId)
                                {
                                    // 現在の項目が前項目と同一だった場合
                                    if (cmp_nItem == outputCsvList[ItemCnt - 1].Item)
                                    {
                                        // 現在の仕様が前項目と同一だった場合
                                        if (n.Specification == outputCsvList[ItemCnt - 1].Specification)
                                        {
                                            // 前項目の仕様提供元出力データに現在の仕様提供元を格納
                                            if (n.SpecificationSource == "光ビーコン規格仕様")
                                            {
                                                outputCsvList[ItemCnt - 1].Result1 = "○";
                                            }
                                            else if (n.SpecificationSource == "UTMS協会データチェック内容")
                                            {
                                                outputCsvList[ItemCnt - 1].Result2 = "○";
                                            }
                                            else if (n.SpecificationSource == "その他")
                                            {
                                                outputCsvList[ItemCnt - 1].Result3 = "○";
                                            }
                                            same_line = true;
                                            break;
                                        }
                                    }
                                }
                            }
                            // 同一項目で同じ行に出力したためnoを更新せず次項目へ進めるため
                            if (same_line == true) { continue; }
                        }

                        // 通し番号のNoを出力データに格納
                        Intersection_outputCsvRow.No = no.ToString();
                        // 項目(出力文字列)を出力データに格納
                        Intersection_outputCsvRow.Item = n.Item;
                        // 項目の文字列内「(I)」を交差点番号に置換する
                        Intersection_outputCsvRow.Item = Intersection_outputCsvRow.Item.Replace("(I)", $"({n.BelongingId_1})");
                        // 仕様提供元に○を設定
                        if (n.SpecificationSource == "光ビーコン規格仕様")
                        {
                            Intersection_outputCsvRow.Result1 = "○";
                        }
                        else if (n.SpecificationSource == "UTMS協会データチェック内容")
                        {
                            Intersection_outputCsvRow.Result2 = "○";
                        }
                        else if (n.SpecificationSource == "その他")
                        {
                            Intersection_outputCsvRow.Result3 = "○";
                        }
                        // 仕様(仕様項目)を出力データに格納
                        Intersection_outputCsvRow.Specification = n.Specification;
                        // チェック分類を出力データに格納
                        if (n.Category != null)
                        {
                            Intersection_outputCsvRow.Category = n.Category;
                        }
                        else
                        {
                            Intersection_outputCsvRow.Category = "--";
                        }
                        // 値を出力データに格納
                        if (n.Value != null)
                        {
                            Intersection_outputCsvRow.Value = n.Value.ToString();
                        }
                        else
                        {
                            Intersection_outputCsvRow.Value = "--";
                        }
                        // 判定を出力データに格納
                        if (n.Judge == true)
                        {
                            Intersection_outputCsvRow.Judge = "OK";
                        }
                        else if (n.Judge == false)
                        {
                            Intersection_outputCsvRow.Judge = "NG";
                        }
                        else
                        {
                            Intersection_outputCsvRow.Judge = "--";
                        }
                        // 項目IDを出力データ格納
                        Intersection_outputCsvRow.ItemId = n.ItemId;
                        outputCsvList.Add(Intersection_outputCsvRow);
                        no++;

                        // 一つの交差点信号情報の区切り項目の場合(版1：評価ID90、版2：評価ID211)
                        if ((n.EvalSpecId == 90) || (n.EvalSpecId == 211))
                        {

                            if (cycleInfoData == true)
                            {
                                // ■■■■■■■■■■■■■■■■■■■■
                                // サイクル情報を出力リストへ格納
                                // ■■■■■■■■■■■■■■■■■■■■
                                // サイクル情報用の評価結果Csvファイル出力情報リストを生成
                                List<DatabaseAccessor.StCsvEvaluatResultInfo> csvCycleInfos;
                                // サイクル情報を取得
                                dataBaseAccessor.GetCsvEvaluatResultInfo(drivingInfoId, DatabaseAccessor.CsvEvalResGetDataType.Cycle_Info, out csvCycleInfos);
                                // 取得した情報からサイクル情報を評価結果Csvファイル出力情報プロパティリストへ格納
                                foreach (DatabaseAccessor.StCsvEvaluatResultInfo n_cycle in csvCycleInfos)
                                {
                                    // 出力中の交差点に属するサイクル情報でない場合、サイクル情報出力を終了
                                    if (n.BelongingId_1 != n_cycle.BelongingId_1)
                                    {
                                        continue;
                                    }

                                    // 評価結果Csvファイル出力情報1レコードを生成
                                    var cycle_outputCsvRow = new CsvEvaluatResult();
                                    cycle_outputCsvRow.Result1 = "--";
                                    cycle_outputCsvRow.Result2 = "--";
                                    cycle_outputCsvRow.Result3 = "--";

                                    int cycle_listCnt = outputCsvList.Count();
                                    // 前項目(一つ前の項目)を参照しながら進めるため、1項目目は無条件に格納
                                    if (cycle_listCnt != 0)
                                    {
                                        /// 仕様提供元が違う場合でも、項目、仕様が同一の場合は同じ行に出力するため、項目、仕様が同一なら前項目の仕様提供元を「○」にする
                                        /// 比較する前項目の文字列は交差点番号とサイクル番号に所属番号に置換されているため現在の項目も置換する(n_cycleは変更不可のため別変数)
                                        // 項目の文字列内「(I)」を交差点番号に置換する
                                        string cmp_cycleItem = n_cycle.Item.Replace("(I)", $"({n_cycle.BelongingId_1})");
                                        // 項目の文字列内「(J)」をサイクル番号に置換する
                                        cmp_cycleItem = cmp_cycleItem.Replace("(J)", $"({n_cycle.BelongingId_2})");
                                        bool same_line = false;
                                        for (int ItemCnt = cycle_listCnt; ItemCnt > 0; ItemCnt--)
                                        {
                                            // 項目IDが同じ場合(仕様項目が同じ可能性が一つ前だけでないため、項目IDが同じ間は遡ってループ)
                                            if (n_cycle.ItemId == outputCsvList[ItemCnt - 1].ItemId)
                                            {
                                                // 現在の項目が前項目と同一だった場合
                                                if (cmp_cycleItem == outputCsvList[ItemCnt - 1].Item)
                                                {
                                                    // 現在の仕様が前項目と同一だった場合
                                                    if (n_cycle.Specification == outputCsvList[ItemCnt - 1].Specification)
                                                    {
                                                        // 前項目の仕様提供元出力データに現在の仕様提供元を格納
                                                        if (n_cycle.SpecificationSource == "光ビーコン規格仕様")
                                                        {
                                                            outputCsvList[ItemCnt - 1].Result1 = "○";
                                                        }
                                                        else if (n_cycle.SpecificationSource == "UTMS協会データチェック内容")
                                                        {
                                                            outputCsvList[ItemCnt - 1].Result2 = "○";
                                                        }
                                                        else if (n_cycle.SpecificationSource == "その他")
                                                        {
                                                            outputCsvList[ItemCnt - 1].Result3 = "○";
                                                        }
                                                        same_line = true;
                                                        break;
                                                    }
                                                }
                                            }
                                        }
                                        // 同一項目で同じ行に出力したためnoを更新せず次項目へ進めるため
                                        if (same_line == true) { continue; }
                                    }
                                    // 通し番号のNoを出力データに格納
                                    cycle_outputCsvRow.No = no.ToString();
                                    // 項目(出力文字列)を出力データに格納
                                    cycle_outputCsvRow.Item = n_cycle.Item;
                                    // 項目の文字列内「(I)」を交差点番号に置換する
                                    cycle_outputCsvRow.Item = cycle_outputCsvRow.Item.Replace("(I)", $"({n_cycle.BelongingId_1})");
                                    // 項目の文字列内「(J)」を交差点番号に置換する
                                    cycle_outputCsvRow.Item = cycle_outputCsvRow.Item.Replace("(J)", $"({n_cycle.BelongingId_2})");
                                    // 仕様提供元に○を設定
                                    if (n_cycle.SpecificationSource == "光ビーコン規格仕様")
                                    {
                                        cycle_outputCsvRow.Result1 = "○";
                                    }
                                    else if (n_cycle.SpecificationSource == "UTMS協会データチェック内容")
                                    {
                                        cycle_outputCsvRow.Result2 = "○";
                                    }
                                    else if (n_cycle.SpecificationSource == "その他")
                                    {
                                        cycle_outputCsvRow.Result3 = "○";
                                    }
                                    // 仕様(仕様項目)を出力データに格納
                                    cycle_outputCsvRow.Specification = n_cycle.Specification;

                                    // チェック分類を出力データに格納
                                    if (n_cycle.Category != null)
                                    {
                                        cycle_outputCsvRow.Category = n_cycle.Category;
                                    }
                                    else
                                    {
                                        cycle_outputCsvRow.Category = "--";
                                    }
                                    // 値を出力データに格納
                                    if (n_cycle.Value != null)
                                    {
                                        cycle_outputCsvRow.Value = n_cycle.Value.ToString();
                                    }
                                    else
                                    {
                                        cycle_outputCsvRow.Value = "--";
                                    }
                                    // 判定を出力データに格納
                                    if (n_cycle.Judge == true)
                                    {
                                        cycle_outputCsvRow.Judge = "OK";
                                    }
                                    else if (n_cycle.Judge == false)
                                    {
                                        cycle_outputCsvRow.Judge = "NG";
                                    }
                                    else
                                    {
                                        cycle_outputCsvRow.Judge = "--";
                                    }
                                    // 項目IDを出力データ格納
                                    cycle_outputCsvRow.ItemId = n_cycle.ItemId;
                                    outputCsvList.Add(cycle_outputCsvRow);
                                    no++;
                                }
                            }
                        }
                    }
                }

                // 走行基本情報の版が2版の場合、UTMSリンク情報を表示
                if (han_ver == DatabaseAccessor.EvaluationVersion.Version2)
                {
                    // 世代数情報がある場合
                    if (generationData == true)
                    {

                        // ■■■■■■■■■■■■■■■■■■■■
                        // 世代情報数情報を出力リストへ格納
                        // ■■■■■■■■■■■■■■■■■■■■
                        // 通し番号のNoを出力データに格納
                        outputCsvgenerationRow.No = no.ToString();
                        outputCsvList.Add(outputCsvgenerationRow);
                        no++;

                        // ■■■■■■■■■■■■■■■■■■■■
                        // 世代情報を出力リストへ格納
                        // ■■■■■■■■■■■■■■■■■■■■
                        // 世代情報用の評価結果Csvファイル出力情報リストを生成
                        List<DatabaseAccessor.StCsvEvaluatResultInfo> csvGenerationInfos;
                        // 世代情報を取得
                        dataBaseAccessor.GetCsvEvaluatResultInfo(drivingInfoId, DatabaseAccessor.CsvEvalResGetDataType.Generation_Info, out csvGenerationInfos);
                        // 取得した情報から交差点路線信号情報を評価結果Csvファイル出力情報プロパティリストへ格納
                        foreach (DatabaseAccessor.StCsvEvaluatResultInfo n in csvGenerationInfos)
                        {
                            // UTMS情報数の有無を確認(版2：評価ID248)
                            if (n.EvalSpecId == 248)
                            {
                                // 判定がOKの場合(サイクル情報数が1～8)、サイクル情報有りに設定
                                if (n.Judge == true)
                                {
                                    utmsData = true;
                                }
                            }

                            // 評価結果Csvファイル出力情報1レコードを生成
                            var Generation_outputCsvRow = new CsvEvaluatResult();
                            Generation_outputCsvRow.Result1 = "--";
                            Generation_outputCsvRow.Result2 = "--";
                            Generation_outputCsvRow.Result3 = "--";

                            int listCnt = outputCsvList.Count();
                            // 前項目(一つ前の項目)を参照しながら進めるため、1項目目は無条件に格納
                            if (listCnt != 0)
                            {
                                /// 仕様提供元が違う場合でも、項目、仕様が同一の場合は同じ行に出力するため、項目、仕様が同一なら前項目の仕様提供元を「○」にする
                                /// 比較する前項目の文字列は世代数番号に置換されているため現在の項目も置換する(n.Itemは変更不可のため別変数)
                                // 項目の文字列内「第K世代」を世代数番号に置換する
                                string cmp_nItem = n.Item.Replace("第K世代", $"第{n.BelongingId_1}世代");
                                bool same_line = false;
                                for (int ItemCnt = listCnt; ItemCnt > 0; ItemCnt--)
                                {
                                    // 項目IDが同じ場合(仕様項目が同じ可能性が一つ前だけでないため、項目IDが同じ間は遡ってループ)
                                    if (n.ItemId == outputCsvList[ItemCnt - 1].ItemId)
                                    {
                                        // 現在の項目が前項目と同一だった場合
                                        if (cmp_nItem == outputCsvList[ItemCnt - 1].Item)
                                        {
                                            // 現在の仕様が前項目と同一だった場合
                                            if (n.Specification == outputCsvList[ItemCnt - 1].Specification)
                                            {
                                                // 前項目の仕様提供元出力データに現在の仕様提供元を格納
                                                if (n.SpecificationSource == "光ビーコン規格仕様")
                                                {
                                                    outputCsvList[ItemCnt - 1].Result1 = "○";
                                                }
                                                else if (n.SpecificationSource == "UTMS協会データチェック内容")
                                                {
                                                    outputCsvList[ItemCnt - 1].Result2 = "○";
                                                }
                                                else if (n.SpecificationSource == "その他")
                                                {
                                                    outputCsvList[ItemCnt - 1].Result3 = "○";
                                                }
                                                same_line = true;
                                                break;
                                            }
                                        }
                                    }
                                }
                                // 同一項目で同じ行に出力したためnoを更新せず次項目へ進めるため
                                if (same_line == true) { continue; }
                            }

                            // 通し番号のNoを出力データに格納
                            Generation_outputCsvRow.No = no.ToString();
                            // 項目(出力文字列)を出力データに格納
                            Generation_outputCsvRow.Item = n.Item;
                            // 項目の文字列内「第K世代」を世代数番号に置換する
                            Generation_outputCsvRow.Item = Generation_outputCsvRow.Item.Replace("第K世代", $"第{n.BelongingId_1}世代");

                            // 仕様提供元に○を設定
                            if (n.SpecificationSource == "光ビーコン規格仕様")
                            {
                                Generation_outputCsvRow.Result1 = "○";
                            }
                            else if (n.SpecificationSource == "UTMS協会データチェック内容")
                            {
                                Generation_outputCsvRow.Result2 = "○";
                            }
                            else if (n.SpecificationSource == "その他")
                            {
                                Generation_outputCsvRow.Result3 = "○";
                            }
                            // 仕様(仕様項目)を出力データに格納
                            Generation_outputCsvRow.Specification = n.Specification;

                            // チェック分類を出力データに格納
                            if (n.Category != null)
                            {
                                Generation_outputCsvRow.Category = n.Category;
                            }
                            else
                            {
                                Generation_outputCsvRow.Category = "--";
                            }
                            // 値を出力データに格納
                            if (n.Value != null)
                            {
                                Generation_outputCsvRow.Value = n.Value.ToString();
                            }
                            else
                            {
                                Generation_outputCsvRow.Value = "--";
                            }
                            // 判定を出力データに格納
                            if (n.Judge == true)
                            {
                                Generation_outputCsvRow.Judge = "OK";
                            }
                            else if (n.Judge == false)
                            {
                                Generation_outputCsvRow.Judge = "NG";
                            }
                            else
                            {
                                Generation_outputCsvRow.Judge = "--";
                            }

                            // チェック分類を出力データに格納
                            Generation_outputCsvRow.Category = n.Category;
                            // 値を出力データに格納
                            Generation_outputCsvRow.Value = n.Value.ToString();
                            // 判定を出力データに格納
                            if (n.Judge == true)
                            {
                                Generation_outputCsvRow.Judge = "OK";
                            }
                            else
                            {
                                Generation_outputCsvRow.Judge = "NG";
                            }
                            // 項目IDを出力データ格納
                            Generation_outputCsvRow.ItemId = n.ItemId;
                            outputCsvList.Add(Generation_outputCsvRow);
                            no++;

                            // 一つの世代情報の区切り項目の場合(版2：評価ID250)
                            if (n.EvalSpecId == 250)
                            {

                                if (utmsData == true)
                                {
                                    // ■■■■■■■■■■■■■■■■■■■■
                                    // UTMSリンク情報を出力リストへ格納
                                    // ■■■■■■■■■■■■■■■■■■■■
                                    // UTMSリンク情報用の評価結果Csvファイル出力情報リストを生成
                                    List<DatabaseAccessor.StCsvEvaluatResultInfo> csvUtmsInfos;
                                    // UTMSリンク情報を取得
                                    dataBaseAccessor.GetCsvEvaluatResultInfo(drivingInfoId, DatabaseAccessor.CsvEvalResGetDataType.UtmsLink_Info, out csvUtmsInfos);
                                    // 取得した情報からUTMSリンク情報を評価結果Csvファイル出力情報プロパティリストへ格納
                                    foreach (DatabaseAccessor.StCsvEvaluatResultInfo n_utms in csvUtmsInfos)
                                    {
                                        // 出力中の世代に属するUTMSリンク情報でない場合、UTMSリンク情報出力を終了
                                        if (n.BelongingId_1 != n_utms.BelongingId_1)
                                        {
                                            continue;
                                        }

                                        // 評価結果Csvファイル出力情報1レコードを生成
                                        var utmscycle_outputCsvRow = new CsvEvaluatResult();
                                        utmscycle_outputCsvRow.Result1 = "--";
                                        utmscycle_outputCsvRow.Result2 = "--";
                                        utmscycle_outputCsvRow.Result3 = "--";

                                        int utms_listCnt = outputCsvList.Count();
                                        // 前項目(一つ前の項目)を参照しながら進めるため、1項目目は無条件に格納
                                        if (utms_listCnt != 0)
                                        {
                                            /// 仕様提供元が違う場合でも、項目、仕様が同一の場合は同じ行に出力するため、項目、仕様が同一なら前項目の仕様提供元を「○」にする
                                            /// 比較する前項目の文字列は世代数番号とUTMSリンク番号が所属番号に置換されているため現在の項目も置換する(n_utmsは変更不可のため別変数)
                                            // 項目の文字列内「第K世代」を世代数番号に置換する
                                            string cmp_utmsItem = n_utms.Item.Replace("第K世代", $"第{n.BelongingId_1}世代");
                                            // 項目の文字列内「(L)」をUTMSリンク番号に置換する
                                            cmp_utmsItem = cmp_utmsItem.Replace("(L)", $"({n_utms.BelongingId_2})");
                                            bool same_line = false;
                                            for (int ItemCnt = utms_listCnt; ItemCnt > 0; ItemCnt--)
                                            {
                                                // 項目IDが同じ場合(仕様項目が同じ可能性が一つ前だけでないため、項目IDが同じ間は遡ってループ)
                                                if (n_utms.ItemId == outputCsvList[ItemCnt - 1].ItemId)
                                                {
                                                    // 現在の項目が前項目と同一だった場合
                                                    if (cmp_utmsItem == outputCsvList[ItemCnt - 1].Item)
                                                    {
                                                        // 現在の仕様が前項目と同一だった場合
                                                        if (n_utms.Specification == outputCsvList[ItemCnt - 1].Specification)
                                                        {
                                                            // 前項目の仕様提供元出力データに現在の仕様提供元を格納
                                                            if (n_utms.SpecificationSource == "光ビーコン規格仕様")
                                                            {
                                                                outputCsvList[ItemCnt - 1].Result1 = "○";
                                                            }
                                                            else if (n_utms.SpecificationSource == "UTMS協会データチェック内容")
                                                            {
                                                                outputCsvList[ItemCnt - 1].Result2 = "○";
                                                            }
                                                            else if (n_utms.SpecificationSource == "その他")
                                                            {
                                                                outputCsvList[ItemCnt - 1].Result3 = "○";
                                                            }
                                                            same_line = true;
                                                            break;
                                                        }
                                                    }
                                                }
                                            }
                                            // 同一項目で同じ行に出力したためnoを更新せず次項目へ進めるため
                                            if (same_line == true) { continue; }
                                        }

                                        // 通し番号のNoを出力データに格納
                                        utmscycle_outputCsvRow.No = no.ToString();
                                        // 項目(出力文字列)を出力データに格納
                                        utmscycle_outputCsvRow.Item = n_utms.Item;
                                        // 項目の文字列内「第K世代」を世代数番号に置換する
                                        utmscycle_outputCsvRow.Item = utmscycle_outputCsvRow.Item.Replace("第K世代", $"第{n.BelongingId_1}世代");
                                        // 項目の文字列内「(L)」をUTMSリンク番号に置換する
                                        utmscycle_outputCsvRow.Item = utmscycle_outputCsvRow.Item.Replace("(L)", $"({n_utms.BelongingId_2})");

                                        // 仕様提供元に○を設定
                                        if (n_utms.SpecificationSource == "光ビーコン規格仕様")
                                        {
                                            utmscycle_outputCsvRow.Result1 = "○";
                                        }
                                        else if (n_utms.SpecificationSource == "UTMS協会データチェック内容")
                                        {
                                            utmscycle_outputCsvRow.Result2 = "○";
                                        }
                                        else if (n_utms.SpecificationSource == "その他")
                                        {
                                            utmscycle_outputCsvRow.Result3 = "○";
                                        }

                                        // 仕様(仕様項目)を出力データに格納
                                        utmscycle_outputCsvRow.Specification = n_utms.Specification;

                                        // チェック分類を出力データに格納
                                        if (n_utms.Category != null)
                                        {
                                            utmscycle_outputCsvRow.Category = n_utms.Category;
                                        }
                                        else
                                        {
                                            utmscycle_outputCsvRow.Category = "--";
                                        }
                                        // 値を出力データに格納
                                        if (n_utms.Value != null)
                                        {
                                            utmscycle_outputCsvRow.Value = n_utms.Value.ToString();
                                        }
                                        else
                                        {
                                            utmscycle_outputCsvRow.Value = "--";
                                        }
                                        // 判定を出力データに格納
                                        if (n_utms.Judge == true)
                                        {
                                            utmscycle_outputCsvRow.Judge = "OK";
                                        }
                                        else if (n_utms.Judge == false)
                                        {
                                            utmscycle_outputCsvRow.Judge = "NG";
                                        }
                                        else
                                        {
                                            utmscycle_outputCsvRow.Judge = "--";
                                        }
                                        // 項目IDを出力データ格納
                                        utmscycle_outputCsvRow.ItemId = n_utms.ItemId;
                                        outputCsvList.Add(utmscycle_outputCsvRow);
                                        no++;
                                    }
                                }
                            }
                        }
                    }
                }


                // CSVファイル出力
                string cvsFilename_FullPath = filepath + @"\";
                string cvsFilename = DataExporter.makeExporteFilepath(drivingInfoId, dataBaseAccessor, DataExporter.ExportType.EvalResults);
                cvsFilename_FullPath += cvsFilename;
                using (var streamWriter = new StreamWriter(cvsFilename_FullPath, false, Encoding.Default))
                using (var csvWriter = new CsvWriter(streamWriter))
                {
                    csvWriter.Configuration.HasHeaderRecord = true;
                    csvWriter.Configuration.RegisterClassMap<CsvEvaluatResultMapper>();
                    csvWriter.WriteRecords(outputCsvList);
                }

                res = cvsFilename;
            }
            catch (Exception e)
            {
                // エラー処理
                Console.WriteLine(e);
                // 評価履歴テーブルにエラーコードを挿入
                csvErrInsertEvaluationHistory(drivingInfoId, DataExporter.ExportType.EvalResults);
            }
            return (res);
        }

        /// <summary>
        /// カテゴリ別NG件数カウント結果CSVファイル作成
        /// </summary>
        /// <param name="drivingInfoId">走行基本情報ID</param>
        /// <param name="filepath">ファイルパス</param>
        /// <returns>カテゴリ別NG件数カウント結果CSVファイル名</returns>
        public string CategoryNgCountCsvStart(int drivingInfoId, string filepath)
        {
            string res = "";

            try
            {
                List<CsvCategoryNgCount> outputCsvCategoryNgCount = new List<CsvCategoryNgCount>();
                int categoryNgCount = 0;

                // 全カテゴリのNG数を取得
                for (int typecnt = 1; typecnt <= 4; typecnt++)
                {
                    CsvCategoryNgCount CsvCategoryNgCountdata = new CsvCategoryNgCount();
                    // チェックカテゴリ毎のNGカウント数を取得する
                    categoryNgCount = dataBaseAccessor.GetCsvCategoryNgCountInfo(drivingInfoId, typecnt);
                    // チェックカテゴリ数を文字列にし設定
                    CsvCategoryNgCountdata.NgCount = categoryNgCount.ToString();

                    // チェックカテゴリ定義に変換
                    DatabaseAccessor.EvaluatCheckType checktype = (DatabaseAccessor.EvaluatCheckType)typecnt;
                    /// チェックカテゴリ出力文字列を設定
                    if (checktype == DatabaseAccessor.EvaluatCheckType.AreaCheck)
                    {   // 範囲チェック
                        CsvCategoryNgCountdata.JudgementType = AREACHECK_ITEM;
                    }
                    else if (checktype == DatabaseAccessor.EvaluatCheckType.ValueCheck)
                    {   // 値チェック
                        CsvCategoryNgCountdata.JudgementType = VALUECHECK_ITEM;
                    }
                    else if (checktype == DatabaseAccessor.EvaluatCheckType.ConsistencyCheck)
                    {   //  整合性チェック
                        CsvCategoryNgCountdata.JudgementType = CONSISTENCYCHECK_ITEM;
                    }
                    else if (checktype == DatabaseAccessor.EvaluatCheckType.BitCheckNgCnt)
                    {   // BITチェック
                        CsvCategoryNgCountdata.JudgementType = BITCHECKNGCNT_ITEM;
                    }


                    outputCsvCategoryNgCount.Add(CsvCategoryNgCountdata);
                }

                // CSVファイル出力
                string cvsFilename_FullPath = filepath + @"\";
                string cvsFilename = DataExporter.makeExporteFilepath(drivingInfoId, dataBaseAccessor, DataExporter.ExportType.NGCountByCategory);
                cvsFilename_FullPath += cvsFilename;
                using (var streamWriter = new StreamWriter(cvsFilename_FullPath, false, Encoding.Default))
                using (var csvWriter = new CsvWriter(streamWriter))
                {
                    csvWriter.Configuration.HasHeaderRecord = true;
                    csvWriter.Configuration.RegisterClassMap<CsvCategoryNgCountMapper>();
                    csvWriter.WriteRecords(outputCsvCategoryNgCount);
                }

                res = cvsFilename;
            }
            catch (Exception e)
            {
                // エラー処理
                Console.WriteLine(e);
                // 評価履歴テーブルにエラーコードを挿入
                csvErrInsertEvaluationHistory(drivingInfoId, DataExporter.ExportType.NGCountByCategory);
            }

            return (res);
        }

        /// <summary>
        /// 評価結果NG項目CSVファイル作成
        /// </summary>
        /// <param name="drivingInfoId">走行基本情報ID</param>
        /// <param name="filepath">ファイルパス</param>
        /// <param name="outputEvaluatResultCsvList">評価結果CSVファイル出力データ</param>
        /// <returns>評価結果NG項目CSVファイル名</returns>
        public string EvaluatResultNgItemCsvStart(int drivingInfoId, string filepath, List<CsvEvaluatResult> outputEvaluatResultCsvList)
        {
            string res = "";

            try
            {
                List<CsvEvaluatResultNgItem> outputEvaluatResultNgItemList = new List<CsvEvaluatResultNgItem>();
                List<CsvEvaluatResult> ngItemEvaluatResult = new List<CsvEvaluatResult>();

                foreach (CsvEvaluatResult n in outputEvaluatResultCsvList)
                {
                    CsvEvaluatResultNgItem CsvEvaluatResultNgItemdata = new CsvEvaluatResultNgItem();

                    if (n.Judge == "NG")
                    {
                        CsvEvaluatResultNgItemdata.No = n.No;
                        CsvEvaluatResultNgItemdata.Item = n.Item;
                        CsvEvaluatResultNgItemdata.Value = n.Value;
                        CsvEvaluatResultNgItemdata.Category = n.Category;
                        CsvEvaluatResultNgItemdata.Result1 = "--";
                        CsvEvaluatResultNgItemdata.Result2 = "--";
                        CsvEvaluatResultNgItemdata.Result3 = "--";

                        if (n.Result1 == "○")
                        {
                            CsvEvaluatResultNgItemdata.Result1 = "NG";
                        }
                        if (n.Result2 == "○")
                        {
                            CsvEvaluatResultNgItemdata.Result2 = "NG";
                        }
                        if (n.Result3 == "○")
                        {
                            CsvEvaluatResultNgItemdata.Result3 = "NG";
                        }

                        outputEvaluatResultNgItemList.Add(CsvEvaluatResultNgItemdata);
                    }
                }

                // CSVファイル出力
                string cvsFilename_FullPath = filepath + @"\";
                string cvsFilename = DataExporter.makeExporteFilepath(drivingInfoId, dataBaseAccessor, DataExporter.ExportType.EvalResultNGCount);
                cvsFilename_FullPath += cvsFilename;
                using (var streamWriter = new StreamWriter(cvsFilename_FullPath, false, Encoding.Default))
                using (var csvWriter = new CsvWriter(streamWriter))
                {
                    csvWriter.Configuration.HasHeaderRecord = true;
                    csvWriter.Configuration.RegisterClassMap<CsvEvaluatResultNgItemMapper>();
                    csvWriter.WriteRecords(outputEvaluatResultNgItemList);
                }

                res = cvsFilename;
            }
            catch (Exception e)
            {
                // エラー処理
                Console.WriteLine(e);
                // 評価履歴テーブルにエラーコードを挿入
                csvErrInsertEvaluationHistory(drivingInfoId, DataExporter.ExportType.EvalResultNGCount);
            }
            return (res);
        }

        /// <summary>
        /// オフセット信号同期CSVファイル作成
        /// </summary>
        /// <param name="drivingInfoId">走行基本情報ID</param>
        /// <param name="filepath">ファイルパス</param>
        /// <param name="outputEvaluatResultCsvList">評価結果CSVファイル出力データ</param>
        /// <returns>オフセット信号同期CSVファイル名</returns>
        public string OffsetSignalSyncCsvStart(int drivingInfoId, string filepath, List<CsvEvaluatResult> outputEvaluatResultCsvList)
        {
            string res = "";
            short offsetsignalsyncValue_1 = 0;
            short offsetsignalsyncValue_2 = 0;
            short outValue = 0;

            try
            {
                CsvOffsetSignalSync CsvOffsetSignalSyncdata = new CsvOffsetSignalSync();
                List<CsvOffsetSignalSync> outputOffsetSignalSyncList = new List<CsvOffsetSignalSync>();

                // 評価結果リストから情報有効時間１、２を取得
                foreach (CsvEvaluatResult n in outputEvaluatResultCsvList)
                {
                    if(n.Item == "情報有効時間/情報有効時間１")
                    {
                        offsetsignalsyncValue_1 = short.Parse(n.Value);
                    }else if(n.Item == "情報有効時間/情報有効時間２")
                    {
                        offsetsignalsyncValue_2 = short.Parse(n.Value);
                        break;
                    }
                }
                // 情報有効時間２から情報有効時間１を引き、秒を分に変換
                outValue = (short)((offsetsignalsyncValue_2 - offsetsignalsyncValue_1) / 600);
                // 分に変換した情報有効時間を出力データに格納
                CsvOffsetSignalSyncdata.OffsetSignalSyncValue = outValue.ToString();
                outputOffsetSignalSyncList.Add(CsvOffsetSignalSyncdata);

                // CSVファイル出力
                string cvsFilename_FullPath = filepath + @"\";
                string cvsFilename = DataExporter.makeExporteFilepath(drivingInfoId, dataBaseAccessor, DataExporter.ExportType.SyncOffsetSignal);
                cvsFilename_FullPath += cvsFilename;
                using (var streamWriter = new StreamWriter(cvsFilename_FullPath, false, Encoding.Default))
                using (var csvWriter = new CsvWriter(streamWriter))
                {
                    csvWriter.Configuration.HasHeaderRecord = true;
                    csvWriter.Configuration.RegisterClassMap<CsvCsvOffsetSignalSyncMapper>();
                    csvWriter.WriteRecords(outputOffsetSignalSyncList);
                }

                res = cvsFilename;
            }
            catch (Exception e)
            {
                // エラー処理
                Console.WriteLine(e);

                // 評価履歴テーブルにエラーコードを挿入
                csvErrInsertEvaluationHistory(drivingInfoId, DataExporter.ExportType.SyncOffsetSignal);
            }
            return (res);
        }

        /// <summary>
        /// 路線別位置情報を計算する
        /// </summary>
        /// <param name="drivingInfoId">走行基本情報ID</param>
        /// <param name="filepath">ファイルパス</param>
        /// <param name="locationInfo_filename">ファイル名</param>
        /// <param name="intersectionInfos">真値の座標リスト</param>
        /// <param name="importedCoordinates">インポートされた座標リスト</param>
        /// <returns>路線別位置情報出力ファイル名</returns>
        public string LocationInfoByRouteCsvStart(int drivingInfoId, string filepath, string locationInfo_filename, List<DatabaseAccessor.StIntersectionInfo> intersectionInfos, List<ImportedCoordinate> importedCoordinates)
        {
            string res = "";
            int index_cnt = 0;

            try
            {
                List<CsvLocationInfoByRoute> outputCsvLocationInfoByRoute = new List<CsvLocationInfoByRoute>();
                // 交差点の真値座標リスト分ループ
                foreach (DatabaseAccessor.StIntersectionInfo n_InterSections in intersectionInfos)
                {
                    CsvLocationInfoByRoute CsvLocationInfoByRoutedata = new CsvLocationInfoByRoute();

                    // 交差点順序が0(ビーコン)の場合
                    if (n_InterSections.IntersectionOrder == 0)
                    {
                        CsvLocationInfoByRoutedata.InterSectionOrder = "--";
                    }
                    else
                    {   // 交差点の場合
                        CsvLocationInfoByRoutedata.InterSectionOrder = n_InterSections.IntersectionOrder.ToString();
                    }

                    // 管制管理番号が0(ビーコン)の場合
                    if(n_InterSections.ControlManagementNum == 0)
                    {
                        CsvLocationInfoByRoutedata.ControlManagementNum = "--";
                    }
                    else
                    {   // 交差点の場合
                        CsvLocationInfoByRoutedata.ControlManagementNum = n_InterSections.ControlManagementNum.ToString();
                    }
                
                    // 交差点名称
                    CsvLocationInfoByRoutedata.IntersectionName = n_InterSections.IntersectionName;
                    // 2次メッシュ座標
                    CsvLocationInfoByRoutedata.SecondaryMeshCoordinates = n_InterSections.SecondaryMeshCoordinates.ToString();
                    // 正規化座標X（10進）
                    CsvLocationInfoByRoutedata.NormalizedCoordinateX = n_InterSections.NormalizedCoordinateX.ToString();
                    // 正規化座標Y（10進）
                    CsvLocationInfoByRoutedata.NormalizedCoordinateY = n_InterSections.NormalizedCoordinateY.ToString();
                    // 信号情報提供有無
                    if (n_InterSections.SignalInfoProvision == null)
                    {
                        CsvLocationInfoByRoutedata.SignalInfoProvision = "--";
                    }else
                    {
                        CsvLocationInfoByRoutedata.SignalInfoProvision = "有効";
                    }
                    // 緯度（度）
                    CsvLocationInfoByRoutedata.LatitudeVics = n_InterSections.LatitudeVics.ToString();
                    // 経度（度）
                    CsvLocationInfoByRoutedata.LongtudeVics = n_InterSections.LongitudeVics.ToString();
                    // 真値_緯度（度）
                    CsvLocationInfoByRoutedata.LatitudeTrue = n_InterSections.LatitudeTrueValue.ToString();
                    // 真値_経度（度）
                    CsvLocationInfoByRoutedata.LongtudeTrue = n_InterSections.LongitudeTrueValue.ToString();
                    // 真値_道程距離（m）
                    CsvLocationInfoByRoutedata.DestinationDistanceTrue = n_InterSections.DestinationDistanceTrueValue.ToString();

                    // データ有無、走行結果_緯度（度）、走行結果_経度（度）、走行結果_道程距離（m）、誤差_座標（m）、誤差_道程距離（m）は
                    // データ自体を取得できていない場合があるため初期値として無い表示を格納
                    // 版1の場合、ビーコンの座標はインポートされないので、走行データ部分を初期値で対応
                    CsvLocationInfoByRoutedata.DataPresence = "無";
                    CsvLocationInfoByRoutedata.LatitudeResult = "--";
                    CsvLocationInfoByRoutedata.LongtudeResult = "--";
                    CsvLocationInfoByRoutedata.DestinationDistanceResult = "--";
                    CsvLocationInfoByRoutedata.CoordinateErrorRange = "--";
                    CsvLocationInfoByRoutedata.DestinationDistanceErrorRange = "--";

                    // インポートされた座標リスト分ループ
                    foreach (ImportedCoordinate n_InportedCoordinate in importedCoordinates)
                    {
                        // 交差点の真値座標リストの交差点と一致したインポート交差点情報を格納
                        if (index_cnt == n_InportedCoordinate.OriginalCoordinateIndex)
                        {
                            CsvLocationInfoByRoutedata.DataPresence = "有";                                                                  // データ有無
                            CsvLocationInfoByRoutedata.LatitudeResult = n_InportedCoordinate.Coordinate.X.ToString();                        // 走行結果_緯度（度）
                            CsvLocationInfoByRoutedata.LongtudeResult = n_InportedCoordinate.Coordinate.Y.ToString();                        // 走行結果_経度（度）
                            CsvLocationInfoByRoutedata.DestinationDistanceResult = n_InportedCoordinate.Destination.ToString();              // 走行結果_道程距離（m）
                            CsvLocationInfoByRoutedata.CoordinateErrorRange = n_InportedCoordinate.DistanceCoordinate.ToString();            // 誤差_座標（m）
                            CsvLocationInfoByRoutedata.DestinationDistanceErrorRange = n_InportedCoordinate.DistanceDestination.ToString();  // 誤差_道程距離（m）
                            break;
                        }
                    }
                    // CSV出力リストに追加する
                    outputCsvLocationInfoByRoute.Add(CsvLocationInfoByRoutedata);
                    index_cnt++;
                }
                // CSVファイル出力
                string cvsFilename_FullPath = filepath + @"\" + locationInfo_filename;
                using (var streamWriter = new StreamWriter(cvsFilename_FullPath, false, Encoding.Default))
                using (var csvWriter = new CsvWriter(streamWriter))
                {
                    csvWriter.Configuration.HasHeaderRecord = true;
                    csvWriter.Configuration.RegisterClassMap<CsvLocationInfoByRouteMapper>();
                    csvWriter.WriteRecords(outputCsvLocationInfoByRoute);
                }

                res = locationInfo_filename;
            }
            catch (Exception e)
            {
                // エラー処理
                Console.WriteLine(e);
                // 評価履歴テーブルにエラーコードを挿入
                csvErrInsertEvaluationHistory(drivingInfoId, DataExporter.ExportType.LocationInfoByRoute);
            }
            return (res);
        }

        /// <summary>
        /// CSVファイル出力エラー時、評価履歴テーブルにエラーコードを挿入する
        /// </summary>
        /// <param name="drivingInfoId">走行情報ID</param>
        private void csvErrInsertEvaluationHistory(int drivingInfoId, DataExporter.ExportType exportCsvType)
        {
            // 評価実施履歴IDを採番(評価実施履歴の主キーを取得)
            int evaluationHistoryId = getEvaluationHistoryId(drivingInfoId);

            // 評価完了時点の時刻を取得して、評価実施日時とする
            var evaluatedTimestamp = DateTime.Now;

            // エラーコード取得
            var evalStatus = DatabaseAccessor.EvaluationStatus.EvaluateNormal_NoneNG;

            if(exportCsvType == DataExporter.ExportType.EvalResults)
            {
                evalStatus = DatabaseAccessor.EvaluationStatus.ExportError_EvaluationResultItemMakeError;
            }else if (exportCsvType == DataExporter.ExportType.NGCountByCategory)
            {
                evalStatus = DatabaseAccessor.EvaluationStatus.ExportError_CategoryCountResultMakeError;
            }else if (exportCsvType == DataExporter.ExportType.EvalResultNGCount)
            {
                evalStatus = DatabaseAccessor.EvaluationStatus.ExportError_EvaluationResultNgItemMakeError;
            }else if (exportCsvType == DataExporter.ExportType.SyncOffsetSignal)
            {
                evalStatus = DatabaseAccessor.EvaluationStatus.ExportError_OffsetSignalSyncValueMakeError;
            }else if (exportCsvType == DataExporter.ExportType.LocationInfoByRoute)
            {
                evalStatus = DatabaseAccessor.EvaluationStatus.ExportError_LocationInfoMakeError;
            }

            // エラーを評価履歴テーブルに書き込み
            dataBaseAccessor.InsertEvaluationImplementationHistory(drivingInfoId, evaluationHistoryId, evaluatedTimestamp, evalStatus);
        }
        /// <summary>
        /// 評価実施履歴IDを採番
        /// </summary>
        /// <returns>評価実施履歴ID</returns>
        /// <remarks>評価実施履歴の主キーを取得する</remarks>
        private int getEvaluationHistoryId(int drivingInfoId)
        {
            // DBから最新の評価実施履歴IDを取得して、インクリメントした値を返却する
            return dataBaseAccessor.GetLatestEvaluationHistoryId(drivingInfoId) + 1;
        }

        /// <summary>
        /// 評価実施履歴CSVファイル作成
        /// </summary>
        /// <param name="filepath">ファイルパス</param>
        /// <returns>評価実施履歴CSVファイル名</returns>
        public string EvaluationImplementationHistoryCsvStart(string filepath)
        {
            string res = "";

            try
            {
                // 評価実施履歴CSVファイル出力情報リストを生成
                List<DatabaseAccessor.StCsvEvaluationImplementationHistoryInfo> csvEvaluationImplementationHistoryInfos;
                // 評価実施履歴情報を取得
                dataBaseAccessor.GetCsvEvaluationImplementationHistoryInfo(out csvEvaluationImplementationHistoryInfos);
                List<CsvEvaluationImplementationHistory> outputCsvEvaluationImplementationHistory = new List<CsvEvaluationImplementationHistory>();

                // 評価実施履歴CSVファイル出力プロパティクラスに取得した評価実施履歴情報を格納
                foreach (DatabaseAccessor.StCsvEvaluationImplementationHistoryInfo n in csvEvaluationImplementationHistoryInfos)
                {
                    CsvEvaluationImplementationHistory CsvEvaluationImplementationHistorydata = new CsvEvaluationImplementationHistory();
                    CsvEvaluationImplementationHistorydata.PrefectureName = n.PrefectureName;
                    CsvEvaluationImplementationHistorydata.RouteNum = n.RouteNum.ToString();
                    CsvEvaluationImplementationHistorydata.DrivingDatetime = n.DrivingDatetime.ToString();
                    CsvEvaluationImplementationHistorydata.SpecificationVersion = n.SpecificationVersion.ToString();
                    CsvEvaluationImplementationHistorydata.EvaluationDatetime = n.EvaluationDatetime.ToString();
                    // ステータスによりエラー詳細を格納
                    if (n.Status == DatabaseAccessor.EvaluationStatus.EvaluateError_LengthError)
                    {
                        CsvEvaluationImplementationHistorydata.Status = "データ長エラー";
                    }
                    else if (n.Status == DatabaseAccessor.EvaluationStatus.ExportError_EvaluationResultItemMakeError)
                    {
                        CsvEvaluationImplementationHistorydata.Status = "評価結果CSVファイル作成失敗";
                    }
                    else if (n.Status == DatabaseAccessor.EvaluationStatus.ExportError_CategoryCountResultMakeError)
                    {
                        CsvEvaluationImplementationHistorydata.Status = "カテゴリ別NG件数カウント結果CSVファイル作成失敗";
                    }
                    else if (n.Status == DatabaseAccessor.EvaluationStatus.ExportError_EvaluationResultNgItemMakeError)
                    {
                        CsvEvaluationImplementationHistorydata.Status = "評価結果NG項目CSVファイル作成失敗";
                    }
                    else if (n.Status == DatabaseAccessor.EvaluationStatus.ExportError_OffsetSignalSyncValueMakeError)
                    {
                        CsvEvaluationImplementationHistorydata.Status = "オフセット信号同期CSVファイル作成失敗";
                    }
                    else if (n.Status == DatabaseAccessor.EvaluationStatus.ExportError_LocationInfoMakeError)
                    {
                        CsvEvaluationImplementationHistorydata.Status = "路線別位置情報CSVファイル作成失敗";
                    }
                    else if (n.Status == DatabaseAccessor.EvaluationStatus.ExportError_HtmlMakeError)
                    {
                        CsvEvaluationImplementationHistorydata.Status = "HTMLファイル作成失敗";
                    }
                    else if (n.Status == DatabaseAccessor.EvaluationStatus.ExportError_HtmlCaptureError)
                    {
                        CsvEvaluationImplementationHistorydata.Status = "JPEGファイル作成失敗";
                    }
                    else if (n.Status == DatabaseAccessor.EvaluationStatus.ExportError_SummaryMakeError)
                    {
                        CsvEvaluationImplementationHistorydata.Status = "サマリ作成失敗";
                    }

                    outputCsvEvaluationImplementationHistory.Add(CsvEvaluationImplementationHistorydata);
                }

                // CSVファイル出力
                string cvsFilename_FullPath = filepath + @"\";
                string cvsFilename = @"Tool_ErrorLog.csv";
                cvsFilename_FullPath += cvsFilename;
                using (var streamWriter = new StreamWriter(cvsFilename_FullPath, false, Encoding.Default))
                using (var csvWriter = new CsvWriter(streamWriter))
                {
                    csvWriter.Configuration.HasHeaderRecord = true;
                    csvWriter.Configuration.RegisterClassMap<CsvCsvEvaluationImplementationHistoryMapper>();
                    csvWriter.WriteRecords(outputCsvEvaluationImplementationHistory);
                }

                res = cvsFilename;
            }
            catch (Exception e)
            {
                // エラー処理
                Console.WriteLine(e);
            }

            return (res);
        }


    }
}
