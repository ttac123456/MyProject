﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BeaconDataEvaluator
{
    /// <summary>
    /// データ評価処理クラス
    /// </summary>
    /// <remarks>
    /// 下記のデータ評価処理を行う。
    ///  ・データ読み込み
    ///  ・データチェック
    /// </remarks>
    public partial class DataEvaluator
    {
        /// <summary>
        /// ビーコンデータバージョン定義
        /// </summary>
        /// <remarks>
        /// 本定義は「高度化光ビーコン 近赤外線式ＡＭＩＳ用 通信アプリケーション規格」に
        /// 記載されている数値を使用する。
        /// (DBの版定義「1:版１、2:版２」とは異なるため注意すること。)
        /// </remarks>
        private enum DataVersions : byte
        {
            V1 = 0,     // 版１
            V2,         // 版２
        }

        private DatabaseAccessor dataBaseAccessor;  ///< データベース通信クラス

        private DataVersions BeaconDataVersion;     ///< ビーコンデータバージョン

        private int BasicTripInformationId;         ///< 走行基本情報ID
        private int EvaluationHistoryId;            ///< 評価実施履歴ID
        private int IntersectionRouteSignalId;      ///< 交差点路線信号情報ID
        private int CycleInformationId;             ///< サイクル情報ID
        private int GenerationId;                   ///< 世代ID
        private int UTMSLinkId;                     ///< UTMSリンクID

        /// コンストラクタ
        public DataEvaluator(DatabaseAccessor dbAccessor)
        {
            // データベース通信クラスを保持
            dataBaseAccessor = dbAccessor;
        }

        /// デストラクタ
        ~DataEvaluator()
        {
        }

        /// <summary>
        /// 評価を実行する
        /// </summary>
        /// <param name="importResult">インポート実行結果</param>
        /// <param name="basicTripInfo">走行基本情報</param>
        /// <param name="routeSignalInfo">路線信号情報</param>
        public void Execute(bool importResult, StBasicTripInformation basicTripInfo, StRouteSignalInformation routeSignalInfo)
        {
            // 各種キーIDを初期化する
            BasicTripInformationId = 0;     // 走行基本情報ID
            EvaluationHistoryId = 0;        // 評価実施履歴ID
            IntersectionRouteSignalId = 0;  // 交差点路線信号情報ID
            CycleInformationId = 0;         // サイクル情報ID
            GenerationId = 0;               // 世代ID
            UTMSLinkId = 0;                 // UTMSリンクID

            // 走行基本情報をDBに登録する
            var drivingInfoId = registBasicTripInformation(basicTripInfo);

            // 評価実施履歴をDBに登録する
            // NOTE:評価開始時に[NGなし]or[Lengthエラー]を登録している。
            // TODO:[Lengthエラー]は、インポート処理でデータ長理論値算出時のエラー検出で実施したほうがよいかも。
            // TODO:[NGなし]は、エクスポート処理で評価NG件数検索時に実施したほうがよいかも。
            // TODO:[IEキャプチャ未取得]は登録できていない。IntersectionHtmlBrowserクラスでWebアクセス失敗時に登録がよい。
            // TODO:その他のエラーも、適宜DatabaseAccesor.EvaluationStatusに定義し、エラー検知時に登録がよい。
            registEvaluationHistory(importResult, drivingInfoId);

            if (importResult)
            {
                // インポート実行結果が成功時のみ、全ての評価対象項目を評価する
                var evaluateResult = evaluate(routeSignalInfo);
                // 評価結果で評価実施履歴をDB更新する
                updateEvaluationHistory(evaluateResult);
            }
        }

        /// <summary>
        /// 評価を中断する
        /// </summary>
        public void Cancel()
        {

        }

        /// <summary>
        /// 走行基本情報をDBに登録する
        /// </summary>
        /// <param name="basicTripInfo">走行基本情報</param>
        /// <remarks>走行基本情報ID</remarks>
        private int registBasicTripInformation(StBasicTripInformation basicTripInfo)
        {
            try
            {
                // 走行基本情報IDを採番 (走行基本情報の主キーを取得)
                BasicTripInformationId = getBasicTripInformationId();

                // 走行基本情報を取得
                BeaconDataVersion = (DataVersions)basicTripInfo.BeaconDataVersion;
                var dbDataVersion = BeaconDataVersion == DataVersions.V1 ? DatabaseAccessor.EvaluationVersion.Version1 : DatabaseAccessor.EvaluationVersion.Version2;
                var prefecturesId = basicTripInfo.PrefecturesId;
                var routeNumber = basicTripInfo.RouteNumber;
                var tripTimestamp = basicTripInfo.TripTimestamp;

                // 走行基本情報テーブルにデータを追加する
                DatabaseAccessor.EvaluationVersion evaluationVersion = (BeaconDataVersion == DataVersions.V1)
                                                                     ? DatabaseAccessor.EvaluationVersion.Version1
                                                                     : DatabaseAccessor.EvaluationVersion.Version2;
                dataBaseAccessor.InsertDrivingInfo(BasicTripInformationId, prefecturesId, routeNumber, tripTimestamp, evaluationVersion);
            }
            catch (Exception ex)
            {
                Console.WriteLine("registBasicTripInformation error");
                Console.WriteLine(ex.Message);
            }
            return BasicTripInformationId;
        }

        /// <summary>
        /// 走行基本情報IDを採番
        /// </summary>
        /// <returns>走行基本情報ID</returns>
        /// <remarks>走行基本情報の主キーを取得する</remarks>
        private int getBasicTripInformationId()
        {
            // DBから最新の走行基本情報IDを取得して、インクリメントした値を返却する
            return dataBaseAccessor.GetLatestDrivingInfoId() + 1;
        }

        /// <summary>
        /// 評価実施履歴をDBに登録する
        /// </summary>
        /// <param name="importResult">インポート結果</param>
        /// <param name="drivingInfoId">走行基本情報ID</param>
        private void registEvaluationHistory(bool importResult, int drivingInfoId)
        {
            try
            {
                // 評価実施履歴IDを採番(評価実施履歴の主キーを取得)
                EvaluationHistoryId = getEvaluationHistoryId(drivingInfoId);

                // 評価完了時点の時刻を取得して、評価実施日時とする
                var evaluatedTimestamp = DateTime.Now;

                // 評価実施履歴テーブルにデータを追加する
                var evalStatus = importResult ? DatabaseAccessor.EvaluationStatus.EvaluateNormal_NoneNG : DatabaseAccessor.EvaluationStatus.EvaluateError_LengthError;
                dataBaseAccessor.InsertEvaluationImplementationHistory(BasicTripInformationId, EvaluationHistoryId, evaluatedTimestamp, evalStatus);
            }
            catch (Exception ex)
            {
                Console.WriteLine("registEvaluationHistory error");
                Console.WriteLine(ex.Message);
            }
        }

        /// <summary>
        /// DBの評価実施履歴を更新する
        /// </summary>
        /// <param name="evaluateResult">評価結果</param>
        /// <remarks>
        /// 評価開始時に採番した走行基本情報IDと評価実施履歴IDを使用して評価実施履歴を探し出してして更新する。
        /// </remarks>
        private void updateEvaluationHistory(bool evaluateResult)
        {
            try
            {
                // 評価完了時点の時刻を取得して、評価実施日時とする
                var evaluatedTimestamp = DateTime.Now;

                // 評価結果がNGの場合のみ、評価実施履歴テーブルのデータを更新する
                if (!evaluateResult)
                {
                    dataBaseAccessor.UpdateEvaluationImplementationHistory(
                        BasicTripInformationId,
                        EvaluationHistoryId,
                        evaluatedTimestamp,
                        DatabaseAccessor.EvaluationStatus.EvaluateNormal_ExistNG);  // 評価可能(NGあり)
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("updateEvaluationHistory error");
                Console.WriteLine(ex.Message);
            }
        }

        /// <summary>
        /// 評価実施履歴IDを採番
        /// </summary>
        /// <param name="drivingInfoId">走行基本情報ID</param>
        /// <returns>評価実施履歴ID</returns>
        /// <remarks>評価実施履歴の主キーを取得する</remarks>
        private int getEvaluationHistoryId(int drivingInfoId)
        {
            // DBから最新の評価実施履歴IDを取得して、インクリメントした値を返却する
            return dataBaseAccessor.GetLatestEvaluationHistoryId(drivingInfoId) + 1;
        }

        /// <summary>
        /// DBから評価仕様を取得する
        /// </summary>
        /// <returns>評価仕様ID</returns>
        /// <remarks>[out]評価仕様</remarks>
        private bool getEvaluationSpecification(int evalSpecId, out DatabaseAccessor.StEvaluationSpecification evalSpec)
        {
            // 評価仕様データを生成
            evalSpec = new DatabaseAccessor.StEvaluationSpecification();

            // 指定された評価仕様IDの評価仕様データをDBから取得して返却する
            return dataBaseAccessor.GetEvaluationSpecification(evalSpecId, out evalSpec);
        }

        /// <summary>
        /// 評価仕様を評価する
        /// </summary>
        /// <param name="evalSpec">評価仕様</param>
        /// <param name="evalValue">評価値</param>
        /// <returns>評価結果</returns>
        private bool evaluateEvaluationSpecification(DatabaseAccessor.StEvaluationSpecification evalSpec, int evalValue)
        {
            bool evalResult = false;        // 評価結果

            // 通常評価時は、評価パターンを細分化するために、評価値の数を数えておく (max:3)
            int ValuesCount = 0;
            if (evalSpec.Value1.HasValue)
            {
                ValuesCount++;
                if (evalSpec.Value2.HasValue)
                {
                    ValuesCount++;
                    if (evalSpec.Value3.HasValue)
                    {
                        ValuesCount++;
                    }
                }
            }

            // 評価を実施する
            switch (ValuesCount)    // 評価値の数で評価パターンを細分化 (max:3)
            {
            case 1:         // 評価値の数が1個の場合
                            // 固定値と一致するかをチェック
                if (evalValue == evalSpec.Value1)
                    evalResult = true;
                break;
            case 2:         // 評価値の数が2個の場合
                            // 指定範囲内かをチェック
                if ((evalSpec.Value1 <= evalValue) && (evalValue <= evalSpec.Value2))
                    evalResult = true;
                break;
            case 3:         // 評価値の数が3個の場合
                            // 指定範囲内か、または固定値と一致するかをチェック
                if (((evalSpec.Value1 <= evalValue) && (evalValue <= evalSpec.Value2)) || (evalValue == evalSpec.Value3))
                    evalResult = true;
                break;
            }

            // 評価結果を返却する
            return evalResult;
        }

        /// <summary>
        /// 路線信号基本情報の評価結果をDBに登録する
        /// </summary>
        private void registEvaluationResultRouteSignalInformation(int evaluationSpecificationId, int? evalValue, bool? evalResult)
        {
            // 路線信号基本情報テーブルにデータを追加する
            dataBaseAccessor.InsertRouteSignalInfo(BasicTripInformationId, evaluationSpecificationId, evalValue, evalResult);
        }

        /// <summary>
        /// 交差点路線信号情報の評価結果をDBに登録する(整数)
        /// </summary>
        private void registEvaluationResultIntersectionRouteSignalInformation(int evaluationSpecificationId, int? evalValue, bool? evalResult)
        {
            // 交差点路線信号情報テーブルにデータを追加する
            var valueType = DatabaseAccessor.EvaluationValueType.Integer;   // 整数型
            dataBaseAccessor.InsertIntersectionRouteSignalInfo(BasicTripInformationId, IntersectionRouteSignalId, evaluationSpecificationId, valueType, evalValue, null, evalResult);
        }

        /// <summary>
        /// 交差点路線信号情報の評価結果をDBに登録する(実数)
        /// </summary>
        private void registEvaluationResultIntersectionRouteSignalInformation(int evaluationSpecificationId, double? evalValue, bool? evalResult)
        {
            // 交差点路線信号情報テーブルにデータを追加する
            var valueType = DatabaseAccessor.EvaluationValueType.Decimal;   // 小数型
            dataBaseAccessor.InsertIntersectionRouteSignalInfo(BasicTripInformationId, IntersectionRouteSignalId, evaluationSpecificationId, valueType, null, evalValue, evalResult);
        }

        /// <summary>
        /// サイクル情報の評価結果をDBに登録する
        /// </summary>
        private void registEvaluationResultCycleInformation(int evaluationSpecificationId, int? evalValue, bool? evalResult)
        {
            // サイクル情報テーブルにデータを追加する
            dataBaseAccessor.InsertCycleInfo(BasicTripInformationId, IntersectionRouteSignalId, CycleInformationId, evaluationSpecificationId, evalValue, evalResult);
        }

        /// <summary>
        /// 世代の評価結果をDBに登録する
        /// </summary>
        private void registEvaluationResultGeneration(int evaluationSpecificationId, int? evalValue, bool? evalResult)
        {
            // 世代テーブルにデータを追加する
            dataBaseAccessor.InsertGeneration(BasicTripInformationId, GenerationId, evaluationSpecificationId, evalValue, evalResult);
        }

        /// <summary>
        /// ＵＴＭＳリンクの評価結果をDBに登録する
        /// </summary>
        private void registEvaluationResultUTMSLink(int evaluationSpecificationId, int? evalValue, bool? evalResult)
        {
            // ＵＴＭＳリンクにデータを追加する
            dataBaseAccessor.InsertUTMSLink(BasicTripInformationId, GenerationId, UTMSLinkId, evaluationSpecificationId, evalValue, evalResult);
        }

        /// <summary>
        /// 全ての評価対象項目を評価する
        /// </summary>
        /// <param name="routeSignalInformation">路線信号情報</param>
        /// <returns>評価結果</returns>
        /// <remarks>1件以上の評価NG検出時には、評価実施履歴のステータスに「評価可能(NGあり)」を残したい。</remarks>
        private bool evaluate(StRouteSignalInformation routeSignalInformation)
        {
            bool evaluateFailed = false;    // 評価NG検出フラグ

            try
            {
                // 路線信号情報を評価する
                {
                    // 基準点からの経過時間を評価する
                    evaluateFailed |= evaluateElapsedTimeFromReferencePoint(routeSignalInformation);
                    // 路線信号情報の予備を評価する
                    evaluateFailed |= evaluateRSIReserved(routeSignalInformation);
                    // 基準点とデータ生成時刻の差を評価する
                    evaluateFailed |= evaluateDifferenceSinceDataGenerationTime(routeSignalInformation);

                    // 情報有効時間を評価する
                    {
                        var informationValidTime = routeSignalInformation.InformationValidTime;
                        // 情報有効時間を評価する
                        evaluateFailed |= evaluateInformationValidTime(informationValidTime);
                        // 情報有効時間１を評価する
                        evaluateFailed |= evaluateInformationValidTime1(informationValidTime);
                        // 情報有効時間２を評価する
                        evaluateFailed |= evaluateInformationValidTime2(informationValidTime);
                    }

                    // データ形式区分を評価する
                    evaluateFailed |= evaluateDataTypeIndicator(routeSignalInformation);
                    // 格納交差点数：Ｉを評価する
                    evaluateFailed |= evaluateNumberOfStorageIntersections(routeSignalInformation);

                    // 交差点路線信号情報を評価する
                    evaluateFailed |= evaluateIntersectionRouteSignalInformation(routeSignalInformation);
                    // 交差点路線信号情報リストを評価する（１～Ｉ）
                    foreach (var intersectionRouteSignalInformation in routeSignalInformation.IntersectionRouteSignalInformationList.Select((Value, Index) => new { Value, Index }))
                    {
                        var intersectionRouteSignalInformationValue = intersectionRouteSignalInformation.Value;     // 交差点位置情報の値
                        var intersectionRouteSignalInformationIndex = intersectionRouteSignalInformation.Index;     // 交差点位置情報のインデックス
                        IntersectionRouteSignalId = intersectionRouteSignalInformationIndex + 1;                    // 交差点路線信号情報ID(1オリジン)
                        // 交差点位置情報を評価する
                        {
                            var intersectionLocationInformationValue = intersectionRouteSignalInformationValue.IntersectionLocationInformation;
                            // 交差点位置情報を評価する
                            evaluateFailed |= evaluateIntersectionnLocationInformation(intersectionLocationInformationValue);
                            // 交差点参照座標を評価する
                            {
                                var intersectionReferenceCoordinates = intersectionLocationInformationValue.IntersectionReferenceCoordinates;
                                // 交差点参照座標を評価する
                                evaluateFailed |= evaluateIntersectionReferenceCoordinates(intersectionReferenceCoordinates);
                                // 交差点参照座標の２次メッシュ座標を評価する
                                evaluateFailed |= evaluateSecondaryMeshCoordinates(intersectionReferenceCoordinates);
                                // 交差点参照座標の２次メッシュ座標(緯度)を評価する
                                evaluateFailed |= evaluateSecondaryMeshCoordinatesLat(intersectionReferenceCoordinates);
                                // 交差点参照座標の２次メッシュ座標(経度)を評価する
                                evaluateFailed |= evaluateSecondaryMeshCoordinatesLon(intersectionReferenceCoordinates);
                                // 交差点参照座標の２次メッシュ座標(緯度:世界測地系)を評価する
                                evaluateFailed |= evaluateSecondaryMeshCoordinatesWGSLat(intersectionReferenceCoordinates);
                                // 交差点参照座標の２次メッシュ座標(経度:世界測地系)を評価する
                                evaluateFailed |= evaluateSecondaryMeshCoordinatesWGSLon(intersectionReferenceCoordinates);
                                // 交差点参照座標の正規化座標(X軸)を評価する
                                evaluateFailed |= evaluateNormalizedCoordinatesX(intersectionReferenceCoordinates);
                                // 交差点参照座標の正規化座標(Y軸)を評価する
                                evaluateFailed |= evaluateNormalizedCoordinatesY(intersectionReferenceCoordinates);
                                // 交差点参照座標の高度を評価する
                                evaluateFailed |= evaluateHeightCondition(intersectionReferenceCoordinates);
                            }
                            // 光ビーコンから当該停止線までの概算道程距離を評価する
                            evaluateFailed |= evaluateApproximateDistanceToStopLine(intersectionLocationInformationValue);
                            // 上流交差点参照座標を評価する
                            {
                                var upstreamIntersectionReferenceCoordinates = intersectionLocationInformationValue.UpstreamIntersectionReferenceCoordinates;
                                // 上流交差点参照座標を評価する
                                evaluateFailed |= evaluateUpstreamIntersectionReferenceCoordinates(upstreamIntersectionReferenceCoordinates);
                                // 上流交差点参照座標の２次メッシュ座標を評価する
                                evaluateFailed |= evaluateUpstreamSecondaryMeshCoordinates(upstreamIntersectionReferenceCoordinates, intersectionRouteSignalInformationIndex);
                                // 上流交差点参照座標の２次メッシュ座標(緯度)を評価する
                                evaluateFailed |= evaluateUpstreamSecondaryMeshCoordinatesLat(upstreamIntersectionReferenceCoordinates, intersectionRouteSignalInformationIndex);
                                // 上流交差点参照座標の２次メッシュ座標(経度)を評価する
                                evaluateFailed |= evaluateUpstreamSecondaryMeshCoordinatesLon(upstreamIntersectionReferenceCoordinates, intersectionRouteSignalInformationIndex);
                                // 上流交差点参照座標の２次メッシュ座標(緯度:世界測地系)を評価する
                                evaluateFailed |= evaluateUpstreamSecondaryMeshCoordinatesWGSLat(upstreamIntersectionReferenceCoordinates);
                                // 上流交差点参照座標の２次メッシュ座標(経度:世界測地系)を評価する
                                evaluateFailed |= evaluateUpstreamSecondaryMeshCoordinatesWGSLon(upstreamIntersectionReferenceCoordinates);
                                // 上流交差点参照座標の正規化座標(X軸)を評価する
                                evaluateFailed |= evaluateUpstreamNormalizedCoordinatesX(upstreamIntersectionReferenceCoordinates, intersectionRouteSignalInformationIndex);
                                // 上流交差点参照座標の正規化座標(Y軸)を評価する
                                evaluateFailed |= evaluateUpstreamNormalizedCoordinatesY(upstreamIntersectionReferenceCoordinates, intersectionRouteSignalInformationIndex);
                                // 上流交差点参照座標の高度を評価する
                                evaluateFailed |= evaluateUpstreamHeightCondition(upstreamIntersectionReferenceCoordinates, intersectionRouteSignalInformationIndex);
                            }
                            // 光ビーコンから当該停止線までの概算道程距離を評価する
                            evaluateFailed |= evaluateUpstreamApproximateDistanceToStopLine(intersectionLocationInformationValue, intersectionRouteSignalInformationIndex);
                        }

                        // 推奨速度情報を評価する
                        {
                            var recommendedSpeedInformation = intersectionRouteSignalInformationValue.RecommendedSpeedInformation;
                            // 推奨速度情報を評価する
                            evaluateFailed |= evaluateRecommendedSpeedInformation(recommendedSpeedInformation);
                            // 規制速度変動有無を評価する
                            evaluateFailed |= evaluatePresenceOrAbsenceOfRegulatedSpeedFluctuation(recommendedSpeedInformation);
                            // 区間の最小規制速度を評価する
                            evaluateFailed |= evaluateMinimumSpeedLimitOfSection(recommendedSpeedInformation);
                        }

                        // 信号制御補足情報を評価する
                        evaluateFailed |= evaluateSignalControlSupplementInformation(intersectionRouteSignalInformationValue);
                        // 信号制御補足情報(bit0:オフセット乗り換えタイミング)を評価する
                        evaluateFailed |= evaluateSCSIOffsetTransferTiming(intersectionRouteSignalInformationValue);
                        // 信号制御補足情報(bit1:スプリット制御実施状況)を評価する
                        evaluateFailed |= evaluateSCSISplitControlImplementationStatus(intersectionRouteSignalInformationValue);
                        // 信号制御補足情報(Bit2-7:予備)を評価する
                        evaluateFailed |= evaluateSCSIReserved(intersectionRouteSignalInformationValue);
                        // 交差点識別フラグを評価する(メッセージ区分「０」の場合は予備領域)
                        evaluateFailed |= evaluateIntersectionIdentificationFlag(intersectionRouteSignalInformationValue);
                        // 交差点識別フラグ(Bit15:路線信号情報提供対象)を評価する
                        evaluateFailed |= evaluateIIFProvidedRouteSignalInformation(intersectionRouteSignalInformationValue);
                        // 交差点識別フラグ(Bit14:提供状態)を評価する
                        evaluateFailed |= evaluateIIFProvidedStatus(intersectionRouteSignalInformationValue);
                        // 交差点識別フラグ(Bit13:予備)を評価する
                        evaluateFailed |= evaluateIIFReserved(intersectionRouteSignalInformationValue);
                        // 感応許可状態を評価する(メッセージ区分「０」の場合は予備領域)
                        evaluateFailed |= evaluateSensitivityEnabledState(intersectionRouteSignalInformationValue);
                        // 感応許可状態(Bit12:FAST感応)を評価する
                        evaluateFailed |= evaluateSESResponsiveFAST(intersectionRouteSignalInformationValue);
                        // 感応許可状態(Bit11:歩行者感応)を評価する
                        evaluateFailed |= evaluateSESResponsivePedestrian(intersectionRouteSignalInformationValue);
                        // 感応許可状態(Bit10:リコール制御)を評価する
                        evaluateFailed |= evaluateSESRecallControl(intersectionRouteSignalInformationValue);
                        // 感応許可状態(Bit9:ジレンマ感応)を評価する
                        evaluateFailed |= evaluateSESResponsiveDilemma(intersectionRouteSignalInformationValue);
                        // 感応許可状態(Bit8:高速感応)を評価する
                        evaluateFailed |= evaluateSESResponsiveHighway(intersectionRouteSignalInformationValue);
                        // 感応許可状態(Bit7:バス感応)を評価する
                        evaluateFailed |= evaluateSESResponsiveBus(intersectionRouteSignalInformationValue);
                        // 感応許可状態(Bit6:高齢者等感応)を評価する
                        evaluateFailed |= evaluateSESResponsiveSeniorCitizens(intersectionRouteSignalInformationValue);
                        // 感応許可状態(Bit5:ギャップ感応)を評価する
                        evaluateFailed |= evaluateSESResponsiveGap(intersectionRouteSignalInformationValue);
                        // 感応許可状態(Bit4:標準仕様外の感応制御)を評価する
                        evaluateFailed |= evaluateSESSensitiveControlOutsideStandardSpec(intersectionRouteSignalInformationValue);
                        // 感応許可状態(Bit3-0:予備)を評価する
                        evaluateFailed |= evaluateSESReserved(intersectionRouteSignalInformationValue);

                        // サイクル情報（１）開始までの経過時間を評価する
                        evaluateFailed |= evaluateElapsedTimeToStartCycleInformation(intersectionRouteSignalInformationValue);
                        // サイクル情報数：Ｊを評価する
                        evaluateFailed |= evaluateNumberOfCycleInformation(intersectionRouteSignalInformationValue);

                        // サイクル情報を評価する
                        evaluateFailed |= evaluateCycleInformation(intersectionRouteSignalInformationValue);
                        // サイクル情報を評価する（１～Ｊ）
                        CycleInformationId = 0;         // サイクル情報IDを初期化
                        foreach (var cycleInformation in intersectionRouteSignalInformationValue.CycleInformationList)
                        {
                            CycleInformationId++;       // サイクル情報IDをインクリメント(1オリジン)

                            // サイクル情報ヘッダを評価する
                            {
                                var cycleInformationHeader = cycleInformation.CycleInformationHeader;
                                // サイクル情報ヘッダを評価する
                                evaluateFailed |= evaluateCycleInformationHeader(cycleInformationHeader);
                                // 最終サイクル情報の利用区分を評価する
                                evaluateFailed |= evaluateUseClassification(cycleInformationHeader, intersectionRouteSignalInformationValue);
                                // 適用サイクル数を評価する
                                evaluateFailed |= evaluateNumberOfAppliedCycles(cycleInformationHeader, intersectionRouteSignalInformationValue);
                            }
                            // サイクル長を評価する
                            evaluateFailed |= evaluateCycleLength(cycleInformation);
                            // サイクル長（最小）を評価する
                            evaluateFailed |= evaluateCycleLengthMinimum(cycleInformation);
                            // サイクル長（最大）を評価する
                            evaluateFailed |= evaluateCycleLengthMaximum(cycleInformation);
                            // 青開始時間を評価する
                            evaluateFailed |= evaluateBlueStartTime(cycleInformation);
                            // 青開始時間（最小）を評価する
                            evaluateFailed |= evaluateBlueStartTimeMinimum(cycleInformation);
                            // 青開始時間（最大）を評価する
                            evaluateFailed |= evaluateBlueStartTimeMaximum(cycleInformation);
                            // 青終了時間を評価する
                            evaluateFailed |= evaluateBlueEndTime(cycleInformation);
                            // 青終了時間（最小）を評価する
                            evaluateFailed |= evaluateBlueEndTimeMinimum(cycleInformation);
                            // 青終了時間（最大）を評価する
                            evaluateFailed |= evaluateBlueEndTimeMaximum(cycleInformation);

                            // 指令サイクル長を評価する
                            evaluateFailed |= evaluateCommandCycleLength(cycleInformation);
                            // 黄時間を評価する
                            evaluateFailed |= evaluateYellowTime(cycleInformation);
                            // 赤開始時間（最大）を評価する
                            evaluateFailed |= evaluateRedStartTimeMaximum(cycleInformation);
                        }

                    }

                    // データ形式区分が「０」以外の場合のみ、ＵＴＭＳリンク情報を評価する
                    if (routeSignalInformation.DataTypeIndicator != 0)
                    {
                        // ＵＴＭＳリンク情報を評価する
                        evaluateFailed |= evaluateUTMSLinkInformation(routeSignalInformation);
                        // ＵＴＭＳリンク情報を評価する
                        var utmsLinkInformation = routeSignalInformation.UTMSLinkInformation;
                        {
                            // 世代数：Ｋを評価する
                            evaluateFailed |= evaluateNumberOfGenerations(utmsLinkInformation);
                            // 世代を評価する
                            evaluateFailed |= evaluateGeneration(utmsLinkInformation);
                            // 第１世代（最新世代）～第Ｋ世代 K
                            GenerationId = 0;               // 世代IDを初期化
                            foreach (var generation in utmsLinkInformation.GenerationList)
                            {
                                GenerationId++;             // 世代IDをインクリメント(1オリジン)
                                // 格納リンク数：Ｌを評価する
                                evaluateFailed |= evaluateNumberOfStoredLinks(generation);
                                // ＵＴＭＳリンクを評価する
                                evaluateFailed |= evaluateUTMSLink(generation);
                                // ＵＴＭＳリンク（１～Ｌ）
                                UTMSLinkId = 0;             // UTMSリンクIDを初期化
                                foreach (var utmsLink in generation.UTMSLinkList)
                                {
                                    UTMSLinkId++;           // UTMSリンクIDをインクリメント(1オリジン)
                                    // ＵＴＭＳリンクの２次メッシュ座標を評価する
                                    evaluateFailed |= evaluateUTMSLinkSecondaryMeshCoordinates(utmsLink);
                                    // ＵＴＭＳリンクの２次メッシュ座標(緯度)を評価する
                                    evaluateFailed |= evaluateUTMSLinkSecondaryMeshCoordinatesLat(utmsLink);
                                    // ＵＴＭＳリンクの２次メッシュ座標(経度)を評価する
                                    evaluateFailed |= evaluateUTMSLinkSecondaryMeshCoordinatesLon(utmsLink);
                                    // ＵＴＭＳリンクの予約領域を評価する
                                    evaluateFailed |= evaluateUTMSLinkReserved(utmsLink);
                                    // 道路種別を評価する
                                    evaluateFailed |= evaluateRoadClassification(utmsLink);
                                    // リンク番号を評価する
                                    evaluateFailed |= evaluateLinkNumber(utmsLink);
                                }
                            }
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine("evaluate error");
                Console.WriteLine(ex.Message);
            }

            // 評価結果を返却する
            return !evaluateFailed;     // 評価NG検出フラグの論理否定を返却
        }

    }
}
