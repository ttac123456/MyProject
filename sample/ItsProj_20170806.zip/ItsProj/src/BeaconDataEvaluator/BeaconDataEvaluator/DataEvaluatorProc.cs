﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BeaconDataEvaluator
{
    /// <summary>
    /// データ評価処理クラス(部分実装)
    /// </summary>
    /// <remarks>
    /// 各評価の実行メソッドのみ実装
    /// </remarks>
    public partial class DataEvaluator
    {
        /// <summary>
        /// 基準点からの経過時間を評価する
        /// </summary>
        /// <param name="routeSignalInformation">路線信号情報</param>
        /// <returns>評価結果</returns>
        private bool evaluateElapsedTimeFromReferencePoint(StRouteSignalInformation routeSignalInformation)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            bool evalResult = false;                                // 内部評価結果
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            int evalValue = routeSignalInformation.ElapsedTimeFromReferencePoint;   // 基準点からの経過時間

            // 版1は評価仕様ID「1」を評価 (版2は評価仕様ID「123」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 1 : 123;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 路線信号基本情報の評価結果をDBに登録する
                    registEvaluationResultRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 版1は評価仕様ID「2」を評価 (版2は評価仕様ID「124」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 2 : 124;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 路線信号基本情報の評価結果をDBに登録する
                    registEvaluationResultRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// 路線信号情報の予備を評価する
        /// </summary>
        /// <param name="routeSignalInformation">路線信号情報</param>
        /// <returns>評価結果</returns>
        private bool evaluateRSIReserved(StRouteSignalInformation routeSignalInformation)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            bool evalResult = false;                                // 内部評価結果
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            int evalValue = (int)routeSignalInformation.Reserved;   // 路線信号情報の予備

            // 版1は評価仕様ID「3」を評価 (版2は評価仕様ID「125」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 3 : 125;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 路線信号基本情報の評価結果をDBに登録する
                    registEvaluationResultRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 版1は評価仕様ID「4」を評価 (版2は評価仕様ID「126」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 4 : 126;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 路線信号基本情報の評価結果をDBに登録する
                    registEvaluationResultRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// 基準点とデータ生成時刻の差を評価する
        /// </summary>
        /// <param name="routeSignalInformation">路線信号情報</param>
        /// <returns>評価結果</returns>
        private bool evaluateDifferenceSinceDataGenerationTime(StRouteSignalInformation routeSignalInformation)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            bool evalResult = false;                                // 内部評価結果
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            int evalValue = (int)routeSignalInformation.DifferenceSinceDataGenerationTime;   // 基準点とデータ生成時刻の差

            // 版1は評価仕様ID「5」を評価 (版2は評価仕様ID「127」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 5 : 127;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 路線信号基本情報の評価結果をDBに登録する
                    registEvaluationResultRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 版1は評価仕様ID「6」を評価 (版2は評価仕様ID「128」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 6 : 128;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 路線信号基本情報の評価結果をDBに登録する
                    registEvaluationResultRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 版1は評価仕様ID「7」を評価 (版2は評価仕様ID「129」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 7 : 129;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 路線信号基本情報の評価結果をDBに登録する
                    registEvaluationResultRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// 情報有効時間を評価する
        /// </summary>
        /// <returns>評価結果</returns>
        private bool evaluateInformationValidTime(StInformationValidTime informationValidTime)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            bool evalResult = false;                                // 内部評価結果
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            int evalValue1 = informationValidTime.InformationValidTime1;   // 情報有効時間1
            int evalValue2 = informationValidTime.InformationValidTime2;   // 情報有効時間2

            // 版1は評価仕様ID「8」を評価 (版2は評価仕様ID「130」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 8 : 130;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.MultiItemReferenceCheck)  // 評価パターン:多項目参照評価 (他値との比較チェックなど)
                    {
                        // 多項目参照評価を行う (情報有効時間1 < 情報有効時間2)
                        evalResult = (evalValue1 < evalValue2);
                    }
                    // 路線信号基本情報の評価結果をDBに登録する
                    registEvaluationResultRouteSignalInformation(evalSpecId, null, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// 情報有効時間１を評価する
        /// </summary>
        /// <returns>評価結果</returns>
        private bool evaluateInformationValidTime1(StInformationValidTime informationValidTime)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            bool evalResult = false;                                // 内部評価結果
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            int evalValue = (int)informationValidTime.InformationValidTime1;   // 情報有効時間1

            // 版1は評価仕様ID「9」を評価 (版2は評価仕様ID「131」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 9 : 131;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 路線信号基本情報の評価結果をDBに登録する
                    registEvaluationResultRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 版1は評価仕様ID「10」を評価 (版2は評価仕様ID「132」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 10 : 132;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 路線信号基本情報の評価結果をDBに登録する
                    registEvaluationResultRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// 情報有効時間２を評価する
        /// </summary>
        /// <param name="routeSignalInformation">路線信号情報</param>
        /// <returns>評価結果</returns>
        private bool evaluateInformationValidTime2(StInformationValidTime informationValidTime)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            bool evalResult = false;                                // 内部評価結果
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            int evalValue = (int)informationValidTime.InformationValidTime2;   // 情報有効時間2

            // 版1は評価仕様ID「11」を評価 (版2は評価仕様ID「133」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 11 : 133;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 路線信号基本情報の評価結果をDBに登録する
                    registEvaluationResultRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 版1は評価仕様ID「12」を評価 (版2は評価仕様ID「134」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 12 : 134;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 路線信号基本情報の評価結果をDBに登録する
                    registEvaluationResultRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// データ形式区分を評価する
        /// </summary>
        /// <param name="routeSignalInformation">路線信号情報</param>
        /// <returns>評価結果</returns>
        private bool evaluateDataTypeIndicator(StRouteSignalInformation routeSignalInformation)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            bool evalResult = false;                                // 内部評価結果
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            int evalValue = (int)routeSignalInformation.DataTypeIndicator;   // データ形式区分

            // 版1は評価仕様ID「13」を評価
            if (BeaconDataVersion == DataVersions.V1)
            {
                int evalSpecId = 13;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NotCheck)  // 評価無し
                    {
                        // 評価をスキップする
                        Console.WriteLine("skip evaluateDataTypeIndicator");
                    }
                    // 路線信号基本情報の評価結果をDBに登録する
                    registEvaluationResultRouteSignalInformation(evalSpecId, null, null);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            //                             (版2は評価仕様ID「135」を評価)
            if (BeaconDataVersion == DataVersions.V2)
            {
                int evalSpecId = 135;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 路線信号基本情報の評価結果をDBに登録する
                    registEvaluationResultRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            //                             (版2は評価仕様ID「136」を評価)
            if (BeaconDataVersion == DataVersions.V2)
            {
                int evalSpecId = 136;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 路線信号基本情報の評価結果をDBに登録する
                    registEvaluationResultRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// 格納交差点数：Ｉを評価する
        /// </summary>
        /// <param name="routeSignalInformation">路線信号情報</param>
        /// <returns>評価結果</returns>
        private bool evaluateNumberOfStorageIntersections(StRouteSignalInformation routeSignalInformation)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            bool evalResult = false;                                // 内部評価結果
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            int evalValue = (int)routeSignalInformation.NumberOfStorageIntersections;   // 格納交差点数

            // 版1は評価仕様ID「14」を評価 (版2は評価仕様ID「137」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 14 : 137;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 路線信号基本情報の評価結果をDBに登録する
                    registEvaluationResultRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 版1は評価仕様ID「15」を評価 (版2は評価仕様ID「138」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 15 : 138;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 路線信号基本情報の評価結果をDBに登録する
                    registEvaluationResultRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// 交差点路線信号情報を評価する
        /// </summary>
        /// <param name="routeSignalInformation">路線信号情報</param>
        /// <returns>評価結果</returns>
        private bool evaluateIntersectionRouteSignalInformation(StRouteSignalInformation routeSignalInformation)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            bool evalResult = false;                                // 内部評価結果
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            int evalValue1 = (int)routeSignalInformation.NumberOfStorageIntersections;                      // 格納交差点数
            int evalValue2 = (int)routeSignalInformation.IntersectionRouteSignalInformationList.Count();    // 交差点路線信号情報リストの要素数

            // 版1は評価仕様ID「16」を評価 (版2は評価仕様ID「139」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 16 : 139;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.MultiItemReferenceCheck)  // 評価パターン:多項目参照評価 (他値との比較チェックなど)
                    {
                        // 多項目参照評価を行う (格納交差点数 == 交差点路線信号情報リストの要素数)
                        evalResult = (evalValue1 == evalValue2);
                    }
                    // 路線信号基本情報の評価結果をDBに登録する
                    registEvaluationResultRouteSignalInformation(evalSpecId, null, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// 交差点位置情報を評価する
        /// </summary>
        /// <param name="intersectionLocationInformation">交差点位置情報</param>
        /// <returns>評価結果</returns>
        private bool evaluateIntersectionnLocationInformation(StIntersectionLocationInformation intersectionLocationInformation)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 版1は評価仕様ID「17」を評価 (版2は評価仕様ID「140」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 17 : 140;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NotCheck)  // 評価無し
                    {
                        // 評価をスキップする
                        Console.WriteLine("skip evaluateIntersectionnLocationInformation");
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, null, null);
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// 交差点参照座標を評価する
        /// </summary>
        /// <param name="intersectionReferenceCoordinates">交差点参照座標情報</param>
        /// <returns>評価結果</returns>
        private bool evaluateIntersectionReferenceCoordinates(StIntersectionReferenceCoordinates intersectionReferenceCoordinates)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 版1は評価仕様ID「18」を評価 (版2は評価仕様ID「141」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 18 : 141;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NotCheck)  // 評価無し
                    {
                        // 評価をスキップする
                        Console.WriteLine("skip evaluateIntersectionReferenceCoordinates");
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, null, null);
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// 交差点参照座標の２次メッシュ座標を評価する
        /// </summary>
        /// <param name="intersectionReferenceCoordinates">交差点参照座標情報</param>
        /// <returns>評価結果</returns>
        private bool evaluateSecondaryMeshCoordinates(StIntersectionReferenceCoordinates intersectionReferenceCoordinates)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            bool evalResult = false;                                // 内部評価結果
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            int evalValue = (int)intersectionReferenceCoordinates.SecondaryMeshCoordinates;   // ２次メッシュ座標

            // 版1は評価仕様ID「19」を評価 (版2は評価仕様ID「142」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 19 : 142;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// 交差点参照座標の２次メッシュ座標(緯度)を評価する
        /// </summary>
        /// <param name="intersectionReferenceCoordinates">交差点参照座標情報</param>
        /// <returns>評価結果</returns>
        private bool evaluateSecondaryMeshCoordinatesLat(StIntersectionReferenceCoordinates intersectionReferenceCoordinates)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            bool evalResult = false;                                // 内部評価結果
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            int evalValue = (int)intersectionReferenceCoordinates.SecondaryMeshCoordinatesLat;   // ２次メッシュ座標(緯度)

            // 版1は評価仕様ID「20」を評価 (版2は評価仕様ID「143」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 20 : 143;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// 交差点参照座標の２次メッシュ座標(経度)を評価する
        /// </summary>
        /// <param name="intersectionReferenceCoordinates">交差点参照座標情報</param>
        /// <returns>評価結果</returns>
        private bool evaluateSecondaryMeshCoordinatesLon(StIntersectionReferenceCoordinates intersectionReferenceCoordinates)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            bool evalResult = false;                                // 内部評価結果
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            int evalValue = (int)intersectionReferenceCoordinates.SecondaryMeshCoordinatesLon;   // ２次メッシュ座標(経度)

            // 版1は評価仕様ID「21」を評価 (版2は評価仕様ID「144」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 21 : 144;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// 交差点参照座標の２次メッシュ座標(緯度:世界測地系)を評価する
        /// </summary>
        /// <param name="intersectionReferenceCoordinates">交差点参照座標情報</param>
        /// <returns>評価結果</returns>
        private bool evaluateSecondaryMeshCoordinatesWGSLat(StIntersectionReferenceCoordinates intersectionReferenceCoordinates)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            double evalValue = intersectionReferenceCoordinates.SecondaryMeshCoordinatesWGSLat;   // ２次メッシュ座標(緯度:世界測地系)

            // 版1は評価仕様ID「22」を評価 (版2は評価仕様ID「145」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 22 : 145;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NotCheck)  // 評価無し
                    {
                        // 評価をスキップする
                        Console.WriteLine("skip evaluateSecondaryMeshCoordinatesWGSLat");
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する(緯度/経度の値のみを保存する)
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, null);
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// 交差点参照座標の２次メッシュ座標(経度:世界測地系)を評価する
        /// </summary>
        /// <param name="intersectionReferenceCoordinates">交差点参照座標情報</param>
        /// <returns>評価結果</returns>
        private bool evaluateSecondaryMeshCoordinatesWGSLon(StIntersectionReferenceCoordinates intersectionReferenceCoordinates)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            double evalValue = intersectionReferenceCoordinates.SecondaryMeshCoordinatesWGSLon;   // ２次メッシュ座標(経度:世界測地系)

            // 版1は評価仕様ID「23」を評価 (版2は評価仕様ID「146」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 23 : 146;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NotCheck)  // 評価無し
                    {
                        // 評価をスキップする
                        Console.WriteLine("skip evaluateSecondaryMeshCoordinatesWGSLon");
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する(緯度/経度の値のみを保存する)
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, null);
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// 交差点参照座標の正規化座標(X軸)を評価する
        /// </summary>
        /// <param name="intersectionReferenceCoordinates">交差点参照座標情報</param>
        /// <returns>評価結果</returns>
        private bool evaluateNormalizedCoordinatesX(StIntersectionReferenceCoordinates intersectionReferenceCoordinates)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            bool evalResult = false;                                // 内部評価結果
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            int evalValue = (int)intersectionReferenceCoordinates.NormalizedCoordinatesX;   // 正規化座標(X軸)

            // 版1は評価仕様ID「24」を評価 (版2は評価仕様ID「147」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 24 : 147;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 版1は評価仕様ID「25」を評価 (版2は評価仕様ID「148」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 25 : 148;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// 交差点参照座標の正規化座標(Y軸)を評価する
        /// </summary>
        /// <param name="intersectionReferenceCoordinates">交差点参照座標情報</param>
        /// <returns>評価結果</returns>
        private bool evaluateNormalizedCoordinatesY(StIntersectionReferenceCoordinates intersectionReferenceCoordinates)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            bool evalResult = false;                                // 内部評価結果
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            int evalValue = (int)intersectionReferenceCoordinates.NormalizedCoordinatesY;   // 正規化座標(Y軸)

            // 版1は評価仕様ID「26」を評価 (版2は評価仕様ID「149」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 26 : 149;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 版1は評価仕様ID「27」を評価 (版2は評価仕様ID「150」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 27 : 150;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// 交差点参照座標の高度を評価する
        /// </summary>
        /// <param name="intersectionReferenceCoordinates">交差点参照座標情報</param>
        /// <returns>評価結果</returns>
        private bool evaluateHeightCondition(StIntersectionReferenceCoordinates intersectionReferenceCoordinates)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            bool evalResult = false;                                // 内部評価結果
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            int evalValue = (int)intersectionReferenceCoordinates.HeightCondition;   // 高度

            // 版1は評価仕様ID「28」を評価 (版2は評価仕様ID「151」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 28 : 151;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 版1は評価仕様ID「29」を評価 (版2は評価仕様ID「152」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 29 : 152;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// 光ビーコンから当該停止線までの概算道程距離を評価する
        /// </summary>
        /// <param name="intersectionLocationInformation">交差点位置情報</param>
        /// <returns>評価結果</returns>
        private bool evaluateApproximateDistanceToStopLine(StIntersectionLocationInformation intersectionLocationInformation)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            bool evalResult = false;                                // 内部評価結果
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            int evalValue = (int)intersectionLocationInformation.ApproximateDistanceToStopLine;   // 光ビーコンから当該停止線までの概算道程距離

            // 版1は評価仕様ID「30」を評価 (版2は評価仕様ID「153」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 30 : 153;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 版1は評価仕様ID「31」を評価 (版2は評価仕様ID「154」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 31 : 154;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// 上流交差点参照座標を評価する
        /// </summary>
        /// <param name="intersectionReferenceCoordinates">交差点参照座標情報</param>
        /// <returns>評価結果</returns>
        private bool evaluateUpstreamIntersectionReferenceCoordinates(StIntersectionReferenceCoordinates upstreamIntersectionReferenceCoordinates)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 版1は評価仕様ID「32」を評価 (版2は評価仕様ID「155」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 32 : 155;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NotCheck)  // 評価無し
                    {
                        // 評価をスキップする
                        Console.WriteLine("skip evaluateUpstreamIntersectionReferenceCoordinates");
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, null, null);
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// 上流交差点参照座標の２次メッシュ座標を評価する
        /// </summary>
        /// <param name="intersectionReferenceCoordinates">交差点参照座標情報</param>
        /// <param name="intersectionRouteSignalInformationIndex">交差点位置情報のインデックス</param>
        /// <returns>評価結果</returns>
        private bool evaluateUpstreamSecondaryMeshCoordinates(StIntersectionReferenceCoordinates upstreamIntersectionReferenceCoordinates, int intersectionRouteSignalInformationIndex)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            bool evalResult = false;                                // 内部評価結果
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            int evalValue = (int)upstreamIntersectionReferenceCoordinates.SecondaryMeshCoordinates;   // ２次メッシュ座標

            // 版1は評価仕様ID「33」を評価
            if (BeaconDataVersion == DataVersions.V1)
            {
                int evalSpecId = 33;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            //                             (版2は、交差点(1)の場合のみ、評価仕様ID「156」を評価)
            if ((BeaconDataVersion == DataVersions.V2) && (intersectionRouteSignalInformationIndex == 0))
            {
                int evalSpecId = 156;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.CaseDivisionCheck)  // 評価パターン:多項目参照評価 (複数値の比較チェックなど)
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            //                             (版2は、交差点(2)以降の場合のみ、評価仕様ID「157」を評価)
            if ((BeaconDataVersion == DataVersions.V2) && (intersectionRouteSignalInformationIndex > 0))
            {
                int evalSpecId = 157;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.CaseDivisionCheck)  // 評価パターン:多項目参照評価 (複数値の比較チェックなど)
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// 上流交差点参照座標の２次メッシュ座標(緯度)を評価する
        /// </summary>
        /// <param name="intersectionReferenceCoordinates">交差点参照座標情報</param>
        /// <param name="intersectionRouteSignalInformationIndex">交差点位置情報のインデックス</param>
        /// <returns>評価結果</returns>
        private bool evaluateUpstreamSecondaryMeshCoordinatesLat(StIntersectionReferenceCoordinates upstreamIntersectionReferenceCoordinates, int intersectionRouteSignalInformationIndex)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            bool evalResult = false;                                // 内部評価結果
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            int evalValue = (int)upstreamIntersectionReferenceCoordinates.SecondaryMeshCoordinatesLat;   // ２次メッシュ座標(緯度)

            // 版1は評価仕様ID「34」を評価
            if (BeaconDataVersion == DataVersions.V1)
            {
                int evalSpecId = 34;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            //                             (版2は、交差点(1)の場合のみ、評価仕様ID「158」を評価)
            if ((BeaconDataVersion == DataVersions.V2) && (intersectionRouteSignalInformationIndex == 0))
            {
                int evalSpecId = 158;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.CaseDivisionCheck)  // 評価パターン:ケース分け有りの評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            //                             (版2は、交差点(2)以降の場合のみ、評価仕様ID「159」を評価)
            if ((BeaconDataVersion == DataVersions.V2) && (intersectionRouteSignalInformationIndex > 0))
            {
                int evalSpecId = 159;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.CaseDivisionCheck)  // 評価パターン:ケース分け有りの評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// 上流交差点参照座標の２次メッシュ座標(経度)を評価する
        /// </summary>
        /// <param name="intersectionReferenceCoordinates">交差点参照座標情報</param>
        /// <param name="intersectionRouteSignalInformationIndex">交差点位置情報のインデックス</param>
        /// <returns>評価結果</returns>
        private bool evaluateUpstreamSecondaryMeshCoordinatesLon(StIntersectionReferenceCoordinates upstreamIntersectionReferenceCoordinates, int intersectionRouteSignalInformationIndex)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            bool evalResult = false;                                // 内部評価結果
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            int evalValue = (int)upstreamIntersectionReferenceCoordinates.SecondaryMeshCoordinatesLon;   // ２次メッシュ座標(経度)

            // 版1は評価仕様ID「35」を評価
            if (BeaconDataVersion == DataVersions.V1)
            {
                int evalSpecId = 35;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            //                             (版2は、交差点(1)の場合のみ、評価仕様ID「160」を評価)
            if ((BeaconDataVersion == DataVersions.V2) && (intersectionRouteSignalInformationIndex == 0))
            {
                int evalSpecId = 160;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.CaseDivisionCheck)  // 評価パターン:ケース分け有りの評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            //                             (版2は、交差点(2)以降の場合のみ、評価仕様ID「161」を評価)
            if ((BeaconDataVersion == DataVersions.V2) && (intersectionRouteSignalInformationIndex > 0))
            {
                int evalSpecId = 161;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.CaseDivisionCheck)  // 評価パターン:ケース分け有りの評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// 上流交差点参照座標の２次メッシュ座標(緯度:世界測地系)を評価する
        /// </summary>
        /// <param name="intersectionReferenceCoordinates">交差点参照座標情報</param>
        /// <returns>評価結果</returns>
        private bool evaluateUpstreamSecondaryMeshCoordinatesWGSLat(StIntersectionReferenceCoordinates upstreamIntersectionReferenceCoordinates)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            double evalValue = upstreamIntersectionReferenceCoordinates.SecondaryMeshCoordinatesWGSLat;   // ２次メッシュ座標(緯度:世界測地系)

            // 版1は評価仕様ID「36」を評価 (版2は評価仕様ID「162」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 36 : 162;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NotCheck)  // 評価無し
                    {
                        // 評価をスキップする
                        Console.WriteLine("skip evaluateSecondaryMeshCoordinatesWGSLat");
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する(緯度/経度の値のみを保存する)
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, null);
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// 上流交差点参照座標の２次メッシュ座標(経度:世界測地系)を評価する
        /// </summary>
        /// <param name="intersectionReferenceCoordinates">交差点参照座標情報</param>
        /// <returns>評価結果</returns>
        private bool evaluateUpstreamSecondaryMeshCoordinatesWGSLon(StIntersectionReferenceCoordinates upstreamIntersectionReferenceCoordinates)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            double evalValue = upstreamIntersectionReferenceCoordinates.SecondaryMeshCoordinatesWGSLon;   // ２次メッシュ座標(経度:世界測地系)

            // 版1は評価仕様ID「37」を評価 (版2は評価仕様ID「163」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 37 : 163;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NotCheck)  // 評価無し
                    {
                        // 評価をスキップする
                        Console.WriteLine("skip evaluateSecondaryMeshCoordinatesWGSLon");
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する(緯度/経度の値のみを保存する)
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, null);
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// 上流交差点参照座標の正規化座標(X軸)を評価する
        /// </summary>
        /// <param name="intersectionReferenceCoordinates">交差点参照座標情報</param>
        /// <param name="intersectionRouteSignalInformationIndex">交差点位置情報のインデックス</param>
        /// <returns>評価結果</returns>
        private bool evaluateUpstreamNormalizedCoordinatesX(StIntersectionReferenceCoordinates upstreamIntersectionReferenceCoordinates, int intersectionRouteSignalInformationIndex)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            bool evalResult = false;                                // 内部評価結果
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            int evalValue = (int)upstreamIntersectionReferenceCoordinates.NormalizedCoordinatesX;   // 正規化座標(X軸)

            // 版1は評価仕様ID「38」を評価
            if (BeaconDataVersion == DataVersions.V1)
            {
                int evalSpecId = 38;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            //                             (版2は、交差点(1)の場合のみ、評価仕様ID「164」を評価)
            if ((BeaconDataVersion == DataVersions.V2) && (intersectionRouteSignalInformationIndex == 0))
            {
                int evalSpecId = 164;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.CaseDivisionCheck)  // 評価パターン:ケース分け有りの評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 版1は評価仕様ID「39」を評価
            if (BeaconDataVersion == DataVersions.V1)
            {
                int evalSpecId = 39;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            //                             (版2は、交差点(1)の場合のみ、評価仕様ID「165」を評価)
            if ((BeaconDataVersion == DataVersions.V2) && (intersectionRouteSignalInformationIndex == 0))
            {
                int evalSpecId = 165;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.CaseDivisionCheck)  // 評価パターン:ケース分け有りの評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            //                             (版2は、交差点(2)以降の場合のみ、評価仕様ID「166」を評価)
            if ((BeaconDataVersion == DataVersions.V2) && (intersectionRouteSignalInformationIndex > 0))
            {
                int evalSpecId = 166;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.CaseDivisionCheck)  // 評価パターン:ケース分け有りの評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            //                             (版2は、交差点(2)以降の場合のみ、評価仕様ID「167」を評価)
            if ((BeaconDataVersion == DataVersions.V2) && (intersectionRouteSignalInformationIndex > 0))
            {
                int evalSpecId = 167;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.CaseDivisionCheck)  // 評価パターン:ケース分け有りの評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// 上流交差点参照座標の正規化座標(Y軸)を評価する
        /// </summary>
        /// <param name="intersectionReferenceCoordinates">交差点参照座標情報</param>
        /// <param name="intersectionRouteSignalInformationIndex">交差点位置情報のインデックス</param>
        /// <returns>評価結果</returns>
        private bool evaluateUpstreamNormalizedCoordinatesY(StIntersectionReferenceCoordinates upstreamIntersectionReferenceCoordinates, int intersectionRouteSignalInformationIndex)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            bool evalResult = false;                                // 内部評価結果
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            int evalValue = (int)upstreamIntersectionReferenceCoordinates.NormalizedCoordinatesY;   // 正規化座標(Y軸)

            // 版1は評価仕様ID「40」を評価
            if (BeaconDataVersion == DataVersions.V1)
            {
                int evalSpecId = 40;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            //                             (版2は、交差点(1)の場合のみ、評価仕様ID「168」を評価)
            if ((BeaconDataVersion == DataVersions.V2) && (intersectionRouteSignalInformationIndex == 0))
            {
                int evalSpecId = 168;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.CaseDivisionCheck)  // 評価パターン:ケース分け有りの評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 版1は評価仕様ID「41」を評価
            if (BeaconDataVersion == DataVersions.V1)
            {
                int evalSpecId = 41;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            //                             (版2は、交差点(1)の場合のみ、評価仕様ID「169」を評価)
            if ((BeaconDataVersion == DataVersions.V2) && (intersectionRouteSignalInformationIndex == 0))
            {
                int evalSpecId = 169;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.CaseDivisionCheck)  // 評価パターン:ケース分け有りの評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            //                             (版2は、交差点(2)以降の場合のみ、評価仕様ID「170」を評価)
            if ((BeaconDataVersion == DataVersions.V2) && (intersectionRouteSignalInformationIndex > 0))
            {
                int evalSpecId = 170;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.CaseDivisionCheck)  // 評価パターン:ケース分け有りの評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            //                             (版2は、交差点(2)以降の場合のみ、評価仕様ID「171」を評価)
            if ((BeaconDataVersion == DataVersions.V2) && (intersectionRouteSignalInformationIndex > 0))
            {
                int evalSpecId = 171;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.CaseDivisionCheck)  // 評価パターン:ケース分け有りの評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// 上流交差点参照座標の高度を評価する
        /// </summary>
        /// <param name="intersectionReferenceCoordinates">交差点参照座標情報</param>
        /// <param name="intersectionRouteSignalInformationIndex">交差点位置情報のインデックス</param>
        /// <returns>評価結果</returns>
        private bool evaluateUpstreamHeightCondition(StIntersectionReferenceCoordinates upstreamIntersectionReferenceCoordinates, int intersectionRouteSignalInformationIndex)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            bool evalResult = false;                                // 内部評価結果
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            int evalValue = (int)upstreamIntersectionReferenceCoordinates.HeightCondition;   // 高度

            // 版1は評価仕様ID「42」を評価
            if (BeaconDataVersion == DataVersions.V1)
            {
                int evalSpecId = 42;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            //                             (版2は、交差点(1)の場合のみ、評価仕様ID「172」を評価)
            if ((BeaconDataVersion == DataVersions.V2) && (intersectionRouteSignalInformationIndex == 0))
            {
                int evalSpecId = 172;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.CaseDivisionCheck)  // 評価パターン:ケース分け有りの評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 版1は評価仕様ID「43」を評価
            if (BeaconDataVersion == DataVersions.V1)
            {
                int evalSpecId = 43;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            //                             (版2は、交差点(1)の場合のみ、評価仕様ID「173」を評価)
            if ((BeaconDataVersion == DataVersions.V2) && (intersectionRouteSignalInformationIndex == 0))
            {
                int evalSpecId = 173;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.CaseDivisionCheck)  // 評価パターン:ケース分け有りの評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            //                             (版2は、交差点(2)以降の場合のみ、評価仕様ID「174」を評価)
            if ((BeaconDataVersion == DataVersions.V2) && (intersectionRouteSignalInformationIndex > 0))
            {
                int evalSpecId = 174;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.CaseDivisionCheck)  // 評価パターン:ケース分け有りの評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            //                             (版2は、交差点(2)以降の場合のみ、評価仕様ID「175」を評価)
            if ((BeaconDataVersion == DataVersions.V2) && (intersectionRouteSignalInformationIndex > 0))
            {
                int evalSpecId = 175;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.CaseDivisionCheck)  // 評価パターン:ケース分け有りの評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// 光ビーコンから当該停止線までの概算道程距離を評価する
        /// </summary>
        /// <param name="intersectionLocationInformation">交差点位置情報</param>
        /// <param name="intersectionRouteSignalInformationIndex">交差点位置情報のインデックス</param>
        /// <returns>評価結果</returns>
        private bool evaluateUpstreamApproximateDistanceToStopLine(StIntersectionLocationInformation intersectionLocationInformation, int intersectionRouteSignalInformationIndex)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            bool evalResult = false;                                // 内部評価結果
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            int evalValue = (int)intersectionLocationInformation.UpstreamApproximateDistanceToStopLine;   // 光ビーコンから当該停止線までの概算道程距離

            // 版1は、交差点(1)の場合のみ、評価仕様ID「44」を評価
            if ((BeaconDataVersion == DataVersions.V1) && (intersectionRouteSignalInformationIndex == 0))
            {
                int evalSpecId = 44;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.CaseDivisionCheck)  // 評価パターン:ケース分け有りの評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 版1は、交差点(2)以降の場合のみ、評価仕様ID「259」を評価
            if ((BeaconDataVersion == DataVersions.V1) && (intersectionRouteSignalInformationIndex > 0))
            {
                int evalSpecId = 259;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.CaseDivisionCheck)  // 評価パターン:ケース分け有りの評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            //                             (版2は評価仕様ID「176」を評価)
            if (BeaconDataVersion == DataVersions.V2)
            {
                int evalSpecId = 176;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 版1は、交差点(1)の場合のみ、評価仕様ID「45」を評価
            if ((BeaconDataVersion == DataVersions.V1) && (intersectionRouteSignalInformationIndex == 0))
            {
                int evalSpecId = 45;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.CaseDivisionCheck)  // 評価パターン:ケース分け有りの評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 版1は、交差点(2)以降の場合のみ、評価仕様ID「260」を評価
            if ((BeaconDataVersion == DataVersions.V1) && (intersectionRouteSignalInformationIndex > 0))
            {
                int evalSpecId = 260;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.CaseDivisionCheck)  // 評価パターン:ケース分け有りの評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            //                             (版2は、交差点(1)の場合のみ、評価仕様ID「177」を評価)
            if ((BeaconDataVersion == DataVersions.V2) && (intersectionRouteSignalInformationIndex == 0))
            {
                int evalSpecId = 177;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.CaseDivisionCheck)  // 評価パターン:ケース分け有りの評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            //                             (版2は、交差点(2)以降の場合のみ、評価仕様ID「178」を評価)
            if ((BeaconDataVersion == DataVersions.V2) && (intersectionRouteSignalInformationIndex > 0))
            {
                int evalSpecId = 178;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.CaseDivisionCheck)  // 評価パターン:ケース分け有りの評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// 推奨速度情報を評価する
        /// </summary>
        /// <param name="recommendedSpeedInformation">推奨速度情報</param>
        /// <returns>評価結果</returns>
        private bool evaluateRecommendedSpeedInformation(StRecommendedSpeedInformation recommendedSpeedInformation)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 版1は評価仕様ID「46」を評価 (版2は評価仕様ID「179」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 46 : 179;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NotCheck)  // 評価無し
                    {
                        // 評価をスキップする
                        Console.WriteLine("skip evaluateRecommendedSpeedInformation");
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, null, null);
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// 規制速度変動有無を評価する
        /// </summary>
        /// <param name="recommendedSpeedInformation">推奨速度情報</param>
        /// <returns>評価結果</returns>
        private bool evaluatePresenceOrAbsenceOfRegulatedSpeedFluctuation(StRecommendedSpeedInformation recommendedSpeedInformation)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            bool evalResult = false;                                // 内部評価結果
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            int evalValue = (int)recommendedSpeedInformation.PresenceOrAbsenceOfRegulatedSpeedFluctuation;   // 規制速度変動有無

            // 版1は評価仕様ID「47」を評価 (版2は評価仕様ID「180」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 47 : 180;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// 区間の最小規制速度を評価する
        /// </summary>
        /// <param name="recommendedSpeedInformation">推奨速度情報</param>
        /// <returns>評価結果</returns>
        private bool evaluateMinimumSpeedLimitOfSection(StRecommendedSpeedInformation recommendedSpeedInformation)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            bool evalResult = false;                                // 内部評価結果
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            int evalValue = (int)recommendedSpeedInformation.MinimumSpeedLimitOfSection;   // 区間の最小規制速度

            // 版1は評価仕様ID「48」を評価 (版2は評価仕様ID「181」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 48 : 181;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 版1は評価仕様ID「49」を評価 (版2は評価仕様ID「182」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 49 : 182;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// 信号制御補足情報を評価する
        /// </summary>
        /// <param name="intersectionRouteSignalInformation">交差点路線信号情報</param>
        /// <returns>評価結果</returns>
        private bool evaluateSignalControlSupplementInformation(StIntersectionRouteSignalInformation intersectionRouteSignalInformation)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 版1は評価仕様ID「50」を評価 (版2は評価仕様ID「183」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 50 : 183;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NotCheck)  // 評価無し
                    {
                        // 評価をスキップする
                        Console.WriteLine("skip evaluateSignalControlSupplementInformation");
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, null, null);
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// 信号制御補足情報(bit0:オフセット乗り換えタイミング)を評価する
        /// </summary>
        /// <param name="intersectionRouteSignalInformation">交差点路線信号情報</param>
        /// <returns>評価結果</returns>
        private bool evaluateSCSIOffsetTransferTiming(StIntersectionRouteSignalInformation intersectionRouteSignalInformation)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            bool evalResult = false;                                // 内部評価結果
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            int evalValue = (int)intersectionRouteSignalInformation.SCSI_OffsetTransferTiming;   // 信号制御補足情報(bit0:オフセット乗り換えタイミング)

            // 版1は評価仕様ID「51」を評価 (版2は評価仕様ID「184」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 51 : 184;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// 信号制御補足情報(bit1:スプリット制御実施状況)を評価する
        /// </summary>
        /// <param name="intersectionRouteSignalInformation">交差点路線信号情報</param>
        /// <returns>評価結果</returns>
        private bool evaluateSCSISplitControlImplementationStatus(StIntersectionRouteSignalInformation intersectionRouteSignalInformation)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            bool evalResult = false;                                // 内部評価結果
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            int evalValue = (int)intersectionRouteSignalInformation.SCSI_SplitControlImplementationStatus;   // 信号制御補足情報(bit1:スプリット制御実施状況)

            // 版1は評価仕様ID「52」を評価 (版2は評価仕様ID「185」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 52 : 185;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// 信号制御補足情報(Bit2-7:予備)を評価する
        /// </summary>
        /// <param name="intersectionRouteSignalInformation">交差点路線信号情報</param>
        /// <returns>評価結果</returns>
        private bool evaluateSCSIReserved(StIntersectionRouteSignalInformation intersectionRouteSignalInformation)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            bool evalResult = false;                                // 内部評価結果
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            int evalValue = (int)intersectionRouteSignalInformation.SCSI_Reserved;   // 信号制御補足情報(Bit2-7:予備)

            // 版1は評価仕様ID「53」を評価 (版2は評価仕様ID「186」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 53 : 186;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 版1は評価仕様ID「54」を評価 (版2は評価仕様ID「187」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 54 : 187;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// 交差点識別フラグを評価する(メッセージ区分「０」の場合は予備領域)
        /// </summary>
        /// <param name="intersectionRouteSignalInformation">交差点路線信号情報</param>
        /// <returns>評価結果</returns>
        private bool evaluateIntersectionIdentificationFlag(StIntersectionRouteSignalInformation intersectionRouteSignalInformation)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 版1は評価仕様ID「55」を評価 (版2は評価仕様ID「188」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 55 : 188;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NotCheck)  // 評価無し
                    {
                        // 評価をスキップする
                        Console.WriteLine("skip evaluateIntersectionIdentificationFlag");
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, null, null);
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// 交差点識別フラグ(Bit15:路線信号情報提供対象)を評価する
        /// </summary>
        /// <param name="intersectionRouteSignalInformation">交差点路線信号情報</param>
        /// <returns>評価結果</returns>
        private bool evaluateIIFProvidedRouteSignalInformation(StIntersectionRouteSignalInformation intersectionRouteSignalInformation)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            bool evalResult = false;                                // 内部評価結果
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            int evalValue1 = intersectionRouteSignalInformation.IIF_ProvidedRouteSignalInformation; // 交差点識別フラグ(Bit15:路線信号情報提供対象)
            int evalValue2 = intersectionRouteSignalInformation.IIF_ProvidedStatus;                 // 交差点識別フラグ(Bit14:提供状態)
            int evalValue3 = intersectionRouteSignalInformation.IIF_Reserved;                       // 交差点識別フラグ(Bit13:予備)

            // 版1は評価仕様ID「56」を評価 (版2は評価仕様ID「189」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 56 : 189;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue1);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue1, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 版1は評価仕様ID「57」を評価 (版2は評価仕様ID「190」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 57 : 190;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.MultiItemReferenceCheck)  // 評価パターン:多項目参照評価 (他値との比較チェックなど)
                    {
                        // Bit13=0かつ（(Bit15=0かつBit14=1)以外）を評価する
                        evalResult = ((evalValue3 == 0) && !((evalValue1 == 0) && (evalValue2 == 1)));
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue1, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// 交差点識別フラグ(Bit14:提供状態)を評価する
        /// </summary>
        /// <param name="intersectionRouteSignalInformation">交差点路線信号情報</param>
        /// <returns>評価結果</returns>
        private bool evaluateIIFProvidedStatus(StIntersectionRouteSignalInformation intersectionRouteSignalInformation)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            bool evalResult = false;                                // 内部評価結果
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            int evalValue = (int)intersectionRouteSignalInformation.IIF_ProvidedStatus;   // 交差点識別フラグ(Bit14:提供状態)

            // 版1は評価仕様ID「58」を評価 (版2は評価仕様ID「191」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 58 : 191;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 版1は評価仕様ID「59」を評価
            if (BeaconDataVersion == DataVersions.V1)
            {
                int evalSpecId = 59;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// 交差点識別フラグ(Bit13:予備)を評価する
        /// </summary>
        /// <param name="intersectionRouteSignalInformation">交差点路線信号情報</param>
        /// <returns>評価結果</returns>
        private bool evaluateIIFReserved(StIntersectionRouteSignalInformation intersectionRouteSignalInformation)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            bool evalResult = false;                                // 内部評価結果
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            int evalValue = (int)intersectionRouteSignalInformation.IIF_Reserved;   // 交差点識別フラグ(Bit13:予備)

            // 版1は評価仕様ID「60」を評価 (版2は評価仕様ID「192」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 60 : 192;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 版1は評価仕様ID「61」を評価
            if (BeaconDataVersion == DataVersions.V1)
            {
                int evalSpecId = 61;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// 感応許可状態を評価する(メッセージ区分「０」の場合は予備領域)
        /// </summary>
        /// <param name="intersectionRouteSignalInformation">交差点路線信号情報</param>
        /// <returns>評価結果</returns>
        private bool evaluateSensitivityEnabledState(StIntersectionRouteSignalInformation intersectionRouteSignalInformation)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            int evalValue = (int)intersectionRouteSignalInformation.SensitivityEnabledState;   // 感応許可状態

            // 版1は評価仕様ID「62」を評価 (版2は評価仕様ID「193」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 62 : 193;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NotCheck)  // 評価無し
                    {
                        // 評価をスキップする
                        Console.WriteLine("skip evaluateIntersectionIdentificationFlag");
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, null, null);
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// 感応許可状態(Bit12:FAST感応)を評価する
        /// </summary>
        /// <param name="intersectionRouteSignalInformation">交差点路線信号情報</param>
        /// <returns>評価結果</returns>
        private bool evaluateSESResponsiveFAST(StIntersectionRouteSignalInformation intersectionRouteSignalInformation)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            bool evalResult = false;                                // 内部評価結果
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            int evalValue = (int)intersectionRouteSignalInformation.SES_ResponsiveFAST;   // 感応許可状態(Bit12:FAST感応)

            // 版1は評価仕様ID「63」を評価 (版2は評価仕様ID「194」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 63 : 194;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 版1は評価仕様ID「64」を評価
            if (BeaconDataVersion == DataVersions.V1)
            {
                int evalSpecId = 64;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// 感応許可状態(Bit11:歩行者感応)を評価する
        /// </summary>
        /// <param name="intersectionRouteSignalInformation">交差点路線信号情報</param>
        /// <returns>評価結果</returns>
        private bool evaluateSESResponsivePedestrian(StIntersectionRouteSignalInformation intersectionRouteSignalInformation)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            bool evalResult = false;                                // 内部評価結果
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            int evalValue = (int)intersectionRouteSignalInformation.SES_ResponsivePedestrian;   // 感応許可状態(Bit11:歩行者感応)

            // 版1は評価仕様ID「65」を評価 (版2は評価仕様ID「195」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 65 : 195;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 版1は評価仕様ID「66」を評価
            if (BeaconDataVersion == DataVersions.V1)
            {
                int evalSpecId = 66;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// 感応許可状態(Bit10:リコール制御)を評価する
        /// </summary>
        /// <param name="intersectionRouteSignalInformation">交差点路線信号情報</param>
        /// <returns>評価結果</returns>
        private bool evaluateSESRecallControl(StIntersectionRouteSignalInformation intersectionRouteSignalInformation)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            bool evalResult = false;                                // 内部評価結果
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            int evalValue = (int)intersectionRouteSignalInformation.SES_RecallControl;   // 感応許可状態(Bit10:リコール制御)

            // 版1は評価仕様ID「67」を評価 (版2は評価仕様ID「196」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 67 : 196;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 版1は評価仕様ID「68」を評価
            if (BeaconDataVersion == DataVersions.V1)
            {
                int evalSpecId = 68;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// 感応許可状態(Bit9:ジレンマ感応)を評価する
        /// </summary>
        /// <param name="intersectionRouteSignalInformation">交差点路線信号情報</param>
        /// <returns>評価結果</returns>
        private bool evaluateSESResponsiveDilemma(StIntersectionRouteSignalInformation intersectionRouteSignalInformation)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            bool evalResult = false;                                // 内部評価結果
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            int evalValue = (int)intersectionRouteSignalInformation.SES_ResponsiveDilemma;   // 感応許可状態(Bit9:ジレンマ感応)

            // 版1は評価仕様ID「69」を評価 (版2は評価仕様ID「197」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 69 : 197;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 版1は評価仕様ID「70」を評価
            if (BeaconDataVersion == DataVersions.V1)
            {
                int evalSpecId = 70;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// 感応許可状態(Bit8:高速感応)を評価する
        /// </summary>
        /// <param name="intersectionRouteSignalInformation">交差点路線信号情報</param>
        /// <returns>評価結果</returns>
        private bool evaluateSESResponsiveHighway(StIntersectionRouteSignalInformation intersectionRouteSignalInformation)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            bool evalResult = false;                                // 内部評価結果
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            int evalValue = (int)intersectionRouteSignalInformation.SES_ResponsiveHighway;   // 感応許可状態(Bit8:高速感応)

            // 版1は評価仕様ID「71」を評価 (版2は評価仕様ID「198」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 71 : 198;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 版1は評価仕様ID「72」を評価
            if (BeaconDataVersion == DataVersions.V1)
            {
                int evalSpecId = 72;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <returns>評価結果</returns>
        /// <summary>
        /// 感応許可状態(Bit7:バス感応)を評価する
        /// </summary>
        /// <param name="intersectionRouteSignalInformation">交差点路線信号情報</param>
        private bool evaluateSESResponsiveBus(StIntersectionRouteSignalInformation intersectionRouteSignalInformation)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            bool evalResult = false;                                // 内部評価結果
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            int evalValue = (int)intersectionRouteSignalInformation.SES_ResponsiveBus;   // 感応許可状態(Bit7:バス感応)

            // 版1は評価仕様ID「73」を評価 (版2は評価仕様ID「199」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 73 : 199;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 版1は評価仕様ID「74」を評価
            if (BeaconDataVersion == DataVersions.V1)
            {
                int evalSpecId = 74;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// 感応許可状態(Bit6:高齢者等感応)を評価する
        /// </summary>
        /// <param name="intersectionRouteSignalInformation">交差点路線信号情報</param>
        /// <returns>評価結果</returns>
        private bool evaluateSESResponsiveSeniorCitizens(StIntersectionRouteSignalInformation intersectionRouteSignalInformation)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            bool evalResult = false;                                // 内部評価結果
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            int evalValue = (int)intersectionRouteSignalInformation.SES_ResponsiveSeniorCitizens;   // 感応許可状態(Bit6:高齢者等感応)

            // 版1は評価仕様ID「75」を評価 (版2は評価仕様ID「200」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 75 : 200;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 版1は評価仕様ID「76」を評価
            if (BeaconDataVersion == DataVersions.V1)
            {
                int evalSpecId = 76;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// 感応許可状態(Bit5:ギャップ感応)を評価する
        /// </summary>
        /// <param name="intersectionRouteSignalInformation">交差点路線信号情報</param>
        /// <returns>評価結果</returns>
        private bool evaluateSESResponsiveGap(StIntersectionRouteSignalInformation intersectionRouteSignalInformation)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            bool evalResult = false;                                // 内部評価結果
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            int evalValue = (int)intersectionRouteSignalInformation.SES_ResponsiveGap;   // 感応許可状態(Bit5:ギャップ感応)

            // 版1は評価仕様ID「77」を評価 (版2は評価仕様ID「201」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 77 : 201;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 版1は評価仕様ID「78」を評価
            if (BeaconDataVersion == DataVersions.V1)
            {
                int evalSpecId = 78;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// 感応許可状態(Bit4:標準仕様外の感応制御)を評価する
        /// </summary>
        /// <param name="intersectionRouteSignalInformation">交差点路線信号情報</param>
        /// <returns>評価結果</returns>
        private bool evaluateSESSensitiveControlOutsideStandardSpec(StIntersectionRouteSignalInformation intersectionRouteSignalInformation)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            bool evalResult = false;                                // 内部評価結果
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            int evalValue = (int)intersectionRouteSignalInformation.SES_SensitiveControlOutsideStandardSpec;   // 感応許可状態(Bit4:標準仕様外の感応制御)

            // 版1は評価仕様ID「79」を評価 (版2は評価仕様ID「202」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 79 : 202;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 版1は評価仕様ID「80」を評価
            if (BeaconDataVersion == DataVersions.V1)
            {
                int evalSpecId = 80;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// 感応許可状態(Bit3-0:予備)を評価する
        /// </summary>
        /// <param name="intersectionRouteSignalInformation">交差点路線信号情報</param>
        /// <returns>評価結果</returns>
        private bool evaluateSESReserved(StIntersectionRouteSignalInformation intersectionRouteSignalInformation)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            bool evalResult = false;                                // 内部評価結果
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            int evalValue = (int)intersectionRouteSignalInformation.SES_Reserved;   // 感応許可状態(Bit3-0:予備)

            // 版1は評価仕様ID「81」を評価 (版2は評価仕様ID「203」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 81 : 203;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 版1は評価仕様ID「82」を評価
            if (BeaconDataVersion == DataVersions.V1)
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 82 : 204;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// サイクル情報（１）開始までの経過時間を評価する
        /// </summary>
        /// <param name="intersectionRouteSignalInformation">交差点路線信号情報</param>
        /// <returns>評価結果</returns>
        private bool evaluateElapsedTimeToStartCycleInformation(StIntersectionRouteSignalInformation intersectionRouteSignalInformation)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            bool evalResult = false;                                // 内部評価結果
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            int evalValue = (int)intersectionRouteSignalInformation.ElapsedTimeToStartCycleInformation;   // サイクル情報（１）開始までの経過時間
            int evalValueBit15 = (int)intersectionRouteSignalInformation.IIF_ProvidedRouteSignalInformation;    // 交差点識別フラグ(Bit15:路線信号情報提供対象)
            int evalValueBit14 = (int)intersectionRouteSignalInformation.IIF_ProvidedStatus;                    // 交差点識別フラグ(Bit14:提供状態)

            // 版1は評価仕様ID「83」を評価 (版2は評価仕様ID「204」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 83 : 204;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 版1は評価仕様ID「84」を評価 (版2は評価仕様ID「205」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 84 : 205;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.MultiItemReferenceCheck)  // 評価パターン:多項目参照評価 (他値との比較チェックなど)
                    {
                        evalResult = false;
                        // bit15＝０またはbit14＝０の場合
                        if ((evalValueBit15 == 0) || (evalValueBit14 == 0))
                        {
                            // 通常評価を行う
                            evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                            // 交差点路線信号情報の評価結果をDBに登録する (bit15＝０またはbit14＝０の場合のみDB登録する)
                            registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                            // 評価失敗時には、評価NG検出フラグをONする
                            if (!evalResult)
                            {
                                evalFailed |= true;
                                Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                            }
                        }
                    }
                }
            }

            // 版1は評価仕様ID「85」を評価 (版2は評価仕様ID「206」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 85 : 206;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.MultiItemReferenceCheck)  // 評価パターン:多項目参照評価 (他値との比較チェックなど)
                    {
                        evalResult = false;
                        // bit15＝０またはbit14＝０以外の場合
                        if (!((evalValueBit15 == 0) || (evalValueBit14 == 0)))
                        {
                            // 通常評価を行う
                            evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                            // 交差点路線信号情報の評価結果をDBに登録する (bit15＝０またはbit14＝０以外の場合のみDB登録する)
                            registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                            // 評価失敗時には、評価NG検出フラグをONする
                            if (!evalResult)
                            {
                                evalFailed |= true;
                                Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                            }
                        }
                    }
                }
            }

            // 版1は評価仕様ID「86」を評価 (版2は評価仕様ID「207」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 86 : 207;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.MultiItemReferenceCheck)  // 評価パターン:多項目参照評価 (他値との比較チェックなど)
                    {
                        evalResult = false;
                        // bit15＝０またはbit14＝０以外の場合
                        if (!((evalValueBit15 == 0) || (evalValueBit14 == 0)))
                        {
                            // 評価値≦評価パターン値１を確認する
                            evalResult = (evalValue <= evalSpec.Value1);
                            // 交差点路線信号情報の評価結果をDBに登録する (bit15＝０またはbit14＝０以外の場合のみDB登録する)
                            registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                            // 評価失敗時には、評価NG検出フラグをONする
                            if (!evalResult)
                            {
                                evalFailed |= true;
                                Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                            }
                        }
                    }
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// サイクル情報数：Ｊを評価する
        /// </summary>
        /// <param name="intersectionRouteSignalInformation">交差点路線信号情報</param>
        /// <returns>評価結果</returns>
        private bool evaluateNumberOfCycleInformation(StIntersectionRouteSignalInformation intersectionRouteSignalInformation)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            bool evalResult = false;                                // 内部評価結果
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            int evalValue = (int)intersectionRouteSignalInformation.NumberOfCycleInformation;   // サイクル情報数：Ｊ
            int evalValueBit15 = (int)intersectionRouteSignalInformation.IIF_ProvidedRouteSignalInformation;    // 交差点識別フラグ(Bit15:路線信号情報提供対象)
            int evalValueBit14 = (int)intersectionRouteSignalInformation.IIF_ProvidedStatus;                    // 交差点識別フラグ(Bit14:提供状態)

            // 版1は評価仕様ID「87」を評価 (版2は評価仕様ID「208」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 87 : 208;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 版1は評価仕様ID「88」を評価 (版2は評価仕様ID「209」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 88 : 209;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.MultiItemReferenceCheck)  // 評価パターン:多項目参照評価 (他値との比較チェックなど)
                    {
                        evalResult = false;
                        // bit15＝０またはbit14＝０の場合
                        if ((evalValueBit15 == 0) || (evalValueBit14 == 0))
                        {
                            // 通常評価を行う
                            evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                            // 交差点路線信号情報の評価結果をDBに登録する (bit15＝０またはbit14＝０の場合のみDB登録する)
                            registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                            // 評価失敗時には、評価NG検出フラグをONする
                            if (!evalResult)
                            {
                                evalFailed |= true;
                                Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                            }
                        }
                    }
                }
            }

            // 版1は評価仕様ID「89」を評価 (版2は評価仕様ID「210」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 89 : 210;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.MultiItemReferenceCheck)  // 評価パターン:多項目参照評価 (他値との比較チェックなど)
                    {
                        evalResult = false;
                        // bit15＝０またはbit14＝０以外の場合
                        if (!((evalValueBit15 == 0) || (evalValueBit14 == 0)))
                        {
                            // 通常評価を行う
                            evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                            // 交差点路線信号情報の評価結果をDBに登録する (bit15＝０またはbit14＝０以外の場合のみDB登録する)
                            registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, evalValue, evalResult);
                            // 評価失敗時には、評価NG検出フラグをONする
                            if (!evalResult)
                            {
                                evalFailed |= true;
                                Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                            }
                        }
                    }
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// サイクル情報を評価する
        /// </summary>
        /// <param name="intersectionRouteSignalInformation">交差点路線信号情報</param>
        /// <returns>評価結果</returns>
        private bool evaluateCycleInformation(StIntersectionRouteSignalInformation intersectionRouteSignalInformation)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            bool evalResult = false;                                // 内部評価結果
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            int evalValue1 = (int)intersectionRouteSignalInformation.NumberOfCycleInformation;      // サイクル情報数：Ｊ
            int evalValue2 = (int)intersectionRouteSignalInformation.CycleInformationList.Count();  // サイクル情報リストの要素数

            // 版1は評価仕様ID「90」を評価 (版2は評価仕様ID「211」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 90 : 211;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.MultiItemReferenceCheck)  // 評価パターン:多項目参照評価 (他値との比較チェックなど)
                    {
                        // 多項目参照評価を行う (サイクル情報数 == サイクル情報リストの要素数)
                        evalResult = (evalValue1 == evalValue2);
                    }
                    // 交差点路線信号情報の評価結果をDBに登録する
                    registEvaluationResultIntersectionRouteSignalInformation(evalSpecId, null, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// サイクル情報ヘッダを評価する
        /// </summary>
        /// <param name="cycleInformationHeader">サイクル情報ヘッダ</param>
        /// <returns>評価結果</returns>
        private bool evaluateCycleInformationHeader(StCycleInformationHeader cycleInformationHeader)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 版1は評価仕様ID「91」を評価 (版2は評価仕様ID「212」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 91 : 212;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NotCheck)  // 評価無し
                    {
                        // 評価をスキップする
                        Console.WriteLine("skip evaluateCycleInformationHeader");
                    }
                    // サイクル情報の評価結果をDBに登録する
                    registEvaluationResultCycleInformation(evalSpecId, null, null);
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// 最終サイクル情報の利用区分を評価する
        /// </summary>
        /// <param name="cycleInformationHeader">サイクル情報ヘッダ</param>
        /// <param name="intersectionRouteSignalInformation">交差点路線信号情報</param>
        /// <returns>評価結果</returns>
        private bool evaluateUseClassification(StCycleInformationHeader cycleInformationHeader, StIntersectionRouteSignalInformation intersectionRouteSignalInformation)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            bool evalResult = false;                                // 内部評価結果
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            int evalValue1 = cycleInformationHeader.UseClassification;                                 // 最終サイクル情報の利用区分
            int evalValue2 = intersectionRouteSignalInformation.NumberOfCycleInformation;              // サイクル情報数：Ｊ
            int evalValue3 = intersectionRouteSignalInformation.SCSI_SplitControlImplementationStatus; // 信号制御補足情報(bit1:スプリット制御実施状況)

            // 版1は評価仕様ID「92」を評価 (版2は評価仕様ID「213」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 92 : 213;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.MultiItemReferenceCheck)  // 評価パターン:多項目参照評価 (他値との比較チェックなど)
                    {
                        // 最終サイクル以外の場合 (サイクル情報ID＜サイクル情報数)
                        if (CycleInformationId < evalValue2)
                        {
                            // 通常評価を行う (最終サイクル情報の利用区分＝０を確認)
                            evalResult = evaluateEvaluationSpecification(evalSpec, evalValue1);
                            // サイクル情報の評価結果をDBに登録する (最終サイクル以外の場合のみDB登録する)
                            registEvaluationResultCycleInformation(evalSpecId, evalValue1, evalResult);
                            // 評価失敗時には、評価NG検出フラグをONする
                            if (!evalResult)
                            {
                                evalFailed |= true;
                                Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                            }
                        }
                    }
                }
            }

            // 版1は評価仕様ID「93」を評価 (版2は評価仕様ID「215」を評価)
            // NOTE:2017/08/05:t-yamanaka:版1の評価仕様ID「93」に対応する版2の評価仕様ID「215」が正しい。評価番号を214から215に入れ替える修正を行う。
            // NOTE:2017/08/05:t-yamanaka:版2の評価仕様ID「214」では、条件「スプリット制御実施状況＝１」で評価する仕様となっている。
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 93 : 215;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.MultiItemReferenceCheck)  // 評価パターン:多項目参照評価 (他値との比較チェックなど)
                    {
                        // 最終サイクル且つスプリット制御実施状況＝０の場合
                        if ((CycleInformationId == evalValue2) && (evalValue3 == 0))
                        {
                            // 通常評価を行う (最終サイクル情報の利用区分＝１or２を確認)
                            evalResult = evaluateEvaluationSpecification(evalSpec, evalValue1);
                            // サイクル情報の評価結果をDBに登録する (最終サイクル且つスプリット制御実施状況＝０の場合のみDB登録する)
                            registEvaluationResultCycleInformation(evalSpecId, evalValue1, evalResult);
                            // 評価失敗時には、評価NG検出フラグをONする
                            if (!evalResult)
                            {
                                evalFailed |= true;
                                Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                            }
                        }
                    }
                }
            }

            // 版1は評価仕様ID「94」を評価 (版2は評価仕様ID「215」を評価)
            // NOTE:2017/08/05:t-yamanaka:版1の評価仕様ID「94」に対応する版2の評価仕様ID「214」が正しい。評価番号を215から214に入れ替える修正を行う。
            // NOTE:2017/08/05:t-yamanaka:版2の評価仕様ID「215」では、条件「スプリット制御実施状況＝０」で評価する仕様となっている。
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 94 : 214;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.MultiItemReferenceCheck)  // 評価パターン:多項目参照評価 (他値との比較チェックなど)
                    {
                        // 最終サイクル且つスプリット制御実施状況＝１の場合
                        if ((CycleInformationId == evalValue2) && (evalValue3 == 1))
                        {
                            // 通常評価を行う (最終サイクル情報の利用区分＝２を確認)
                            evalResult = evaluateEvaluationSpecification(evalSpec, evalValue1);
                            // サイクル情報の評価結果をDBに登録する (最終サイクル且つスプリット制御実施状況＝１の場合のみDB登録する)
                            registEvaluationResultCycleInformation(evalSpecId, evalValue1, evalResult);
                            // 評価失敗時には、評価NG検出フラグをONする
                            if (!evalResult)
                            {
                                evalFailed |= true;
                                Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                            }
                        }
                    }
                }
            }

            // 版1は評価仕様ID「95」を評価 (版2は評価仕様ID「216」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 95 : 216;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う (最終サイクル情報の利用区分＝０～２を確認)
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue1);
                    }
                    // サイクル情報の評価結果をDBに登録する
                    registEvaluationResultCycleInformation(evalSpecId, evalValue1, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 版1は評価仕様ID「96」を評価 (版2は評価仕様ID「217」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 96 : 217;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.MultiItemReferenceCheck)  // 評価パターン:多項目参照評価 (他値との比較チェックなど)
                    {
                        // 最終サイクル且つスプリット制御実施状況＝１の場合
                        if ((CycleInformationId == evalValue2) && (evalValue3 == 1))
                        {
                            // 通常評価を行う (最終サイクル情報の利用区分＝２を確認)
                            evalResult = evaluateEvaluationSpecification(evalSpec, evalValue1);
                            // サイクル情報の評価結果をDBに登録する (最終サイクル且つスプリット制御実施状況＝１の場合のみDB登録する)
                            registEvaluationResultCycleInformation(evalSpecId, evalValue1, evalResult);
                            // 評価失敗時には、評価NG検出フラグをONする
                            if (!evalResult)
                            {
                                evalFailed |= true;
                                Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                            }
                        }
                    }
                }
            }

            // 版1は評価仕様ID「97」を評価 (版2は評価仕様ID「218」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 97 : 218;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う (最終サイクル情報の利用区分＝０～２を確認)
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue1);
                        // サイクル情報の評価結果をDBに登録する (最終サイクル且つスプリット制御実施状況＝１の場合のみDB登録する)
                        registEvaluationResultCycleInformation(evalSpecId, evalValue1, evalResult);
                        // 評価失敗時には、評価NG検出フラグをONする
                        if (!evalResult)
                        {
                            evalFailed |= true;
                            Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                        }
                    }
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// 適用サイクル数を評価する
        /// </summary>
        /// <param name="cycleInformationHeader">サイクル情報ヘッダ</param>
        /// <param name="intersectionRouteSignalInformation">交差点路線信号情報</param>
        /// <returns>評価結果</returns>
        private bool evaluateNumberOfAppliedCycles(StCycleInformationHeader cycleInformationHeader, StIntersectionRouteSignalInformation intersectionRouteSignalInformation)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            bool evalResult = false;                                // 内部評価結果
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            int evalValue1 = cycleInformationHeader.NumberOfAppliedCycles;                             // 適用サイクル数
            int evalValue2 = intersectionRouteSignalInformation.NumberOfCycleInformation;              // サイクル情報数：Ｊ
            int evalValue3 = cycleInformationHeader.UseClassification;                                 // 最終サイクル情報の利用区分

            // 版1は評価仕様ID「98」を評価 (版2は評価仕様ID「219」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 98 : 219;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.MultiItemReferenceCheck)  // 評価パターン:多項目参照評価 (他値との比較チェックなど)
                    {
                        // 最終サイクル以外の場合 (サイクル情報ID＜サイクル情報数)
                        if (CycleInformationId < evalValue2)
                        {
                            // 通常評価を行う (適用サイクル数＝１～６３を確認)
                            evalResult = evaluateEvaluationSpecification(evalSpec, evalValue1);
                            // サイクル情報の評価結果をDBに登録する (最終サイクル以外の場合のみDB登録する)
                            registEvaluationResultCycleInformation(evalSpecId, evalValue1, evalResult);
                            // 評価失敗時には、評価NG検出フラグをONする
                            if (!evalResult)
                            {
                                evalFailed |= true;
                                Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                            }
                        }
                    }
                }
            }

            // 版1は評価仕様ID「99」を評価 (版2は評価仕様ID「220」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 99 : 220;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.MultiItemReferenceCheck)  // 評価パターン:多項目参照評価 (他値との比較チェックなど)
                    {
                        // 最終サイクルの場合
                        if (CycleInformationId == evalValue2)
                        {
                            // 通常評価を行う (適用サイクル数＝１を確認)
                            evalResult = evaluateEvaluationSpecification(evalSpec, evalValue1);
                            // サイクル情報の評価結果をDBに登録する (最終サイクルの場合のみDB登録する)
                            registEvaluationResultCycleInformation(evalSpecId, evalValue1, evalResult);
                            // 評価失敗時には、評価NG検出フラグをONする
                            if (!evalResult)
                            {
                                evalFailed |= true;
                                Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                            }
                        }
                    }
                }
            }

            // 版1は評価仕様ID「100」を評価 (版2は評価仕様ID「221」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 100 : 221;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.MultiItemReferenceCheck)  // 評価パターン:多項目参照評価 (他値との比較チェックなど)
                    {
                        // 最終サイクル情報の利用区分が０の場合
                        if (evalValue3 == 0)
                        {
                            // 通常評価を行う (適用サイクル数＝１～６３を確認)
                            evalResult = evaluateEvaluationSpecification(evalSpec, evalValue1);
                            // サイクル情報の評価結果をDBに登録する (最終サイクル情報の利用区分が０の場合のみDB登録する)
                            registEvaluationResultCycleInformation(evalSpecId, evalValue1, evalResult);
                            // 評価失敗時には、評価NG検出フラグをONする
                            if (!evalResult)
                            {
                                evalFailed |= true;
                                Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                            }
                        }
                    }
                }
            }

            // 版1は評価仕様ID「101」を評価 (版2は評価仕様ID「222」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 101 : 222;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.MultiItemReferenceCheck)  // 評価パターン:多項目参照評価 (他値との比較チェックなど)
                    {
                        // 最終サイクル情報の利用区分が０以外の場合
                        if (evalValue3 != 0)
                        {
                            // 通常評価を行う (適用サイクル数＝１を確認)
                            evalResult = evaluateEvaluationSpecification(evalSpec, evalValue1);
                            // サイクル情報の評価結果をDBに登録する (最終サイクル情報の利用区分が０以外の場合のみDB登録する)
                            registEvaluationResultCycleInformation(evalSpecId, evalValue1, evalResult);
                            // 評価失敗時には、評価NG検出フラグをONする
                            if (!evalResult)
                            {
                                evalFailed |= true;
                                Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                            }
                        }
                    }
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// サイクル長を評価する
        /// </summary>
        /// <param name="cycleInformation">サイクル情報</param>
        /// <returns>評価結果</returns>
        private bool evaluateCycleLength(StCycleInformation cycleInformation)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            bool evalResult = false;                                // 内部評価結果
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            int evalValue1 = (int)cycleInformation.CycleLengthMinimum;              // サイクル長（最小）
            int evalValue2 = (int)cycleInformation.CycleLengthMaximum;              // サイクル長（最大）

            // 版1は評価仕様ID「102」を評価 (版2は評価仕様ID「223」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 102 : 223;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.MultiItemReferenceCheck)  // 評価パターン:多項目参照評価 (他値との比較チェックなど)
                    {
                        // 多項目参照評価を行う (サイクル長（最小）≦サイクル長（最大）を確認)
                        evalResult = (evalValue1 <= evalValue2);
                    }
                    // サイクル情報の評価結果をDBに登録する
                    registEvaluationResultCycleInformation(evalSpecId, null, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// サイクル長（最小）を評価する
        /// </summary>
        /// <param name="cycleInformation">サイクル情報</param>
        /// <returns>評価結果</returns>
        private bool evaluateCycleLengthMinimum(StCycleInformation cycleInformation)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            bool evalResult = false;                                // 内部評価結果
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            int evalValue = (int)cycleInformation.CycleLengthMinimum;      // サイクル長（最小）

            // 版1は評価仕様ID「103」を評価 (版2は評価仕様ID「224」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 103 : 224;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // サイクル情報の評価結果をDBに登録する
                    registEvaluationResultCycleInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 版1は評価仕様ID「104」を評価 (版2は評価仕様ID「225」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 104 : 225;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // サイクル情報の評価結果をDBに登録する
                    registEvaluationResultCycleInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// サイクル長（最大）を評価する
        /// </summary>
        /// <param name="cycleInformation">サイクル情報</param>
        /// <returns>評価結果</returns>
        private bool evaluateCycleLengthMaximum(StCycleInformation cycleInformation)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            bool evalResult = false;                                // 内部評価結果
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            int evalValue = (int)cycleInformation.CycleLengthMaximum;      // サイクル長（最大）

            // 版1は評価仕様ID「105」を評価 (版2は評価仕様ID「226」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 105 : 226;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // サイクル情報の評価結果をDBに登録する
                    registEvaluationResultCycleInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 版1は評価仕様ID「106」を評価 (版2は評価仕様ID「227」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 106 : 227;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // サイクル情報の評価結果をDBに登録する
                    registEvaluationResultCycleInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// 青開始時間を評価する
        /// </summary>
        /// <param name="cycleInformation">サイクル情報</param>
        /// <returns>評価結果</returns>
        private bool evaluateBlueStartTime(StCycleInformation cycleInformation)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            bool evalResult = false;                                // 内部評価結果
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            int evalValue1 = (int)cycleInformation.BlueStartTimeMinimum;              // 青開始時間（最小）
            int evalValue2 = (int)cycleInformation.BlueStartTimeMaximum;              // 青開始時間（最大）

            // 版1は評価仕様ID「107」を評価 (版2は評価仕様ID「228」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 107 : 228;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.MultiItemReferenceCheck)  // 評価パターン:多項目参照評価 (他値との比較チェックなど)
                    {
                        // 多項目参照評価を行う (青開始時間（最小）≦青開始時間（最大）を確認)
                        evalResult = (evalValue1 <= evalValue2);
                    }
                    // サイクル情報の評価結果をDBに登録する
                    registEvaluationResultCycleInformation(evalSpecId, null, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// 青開始時間（最小）を評価する
        /// </summary>
        /// <param name="cycleInformation">サイクル情報</param>
        /// <returns>評価結果</returns>
        private bool evaluateBlueStartTimeMinimum(StCycleInformation cycleInformation)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            bool evalResult = false;                                // 内部評価結果
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            int evalValue = (int)cycleInformation.BlueStartTimeMinimum;              // 青開始時間（最小）

            // 版1は評価仕様ID「108」を評価 (版2は評価仕様ID「229」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 108 : 229;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // サイクル情報の評価結果をDBに登録する
                    registEvaluationResultCycleInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 版1は評価仕様ID「109」を評価 (版2は評価仕様ID「230」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 109 : 230;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // サイクル情報の評価結果をDBに登録する
                    registEvaluationResultCycleInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// 青開始時間（最大）を評価する
        /// </summary>
        /// <param name="cycleInformation">サイクル情報</param>
        /// <returns>評価結果</returns>
        private bool evaluateBlueStartTimeMaximum(StCycleInformation cycleInformation)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            bool evalResult = false;                                // 内部評価結果
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            int evalValue = (int)cycleInformation.BlueStartTimeMaximum;              // 青開始時間（最大）

            // 版1は評価仕様ID「110」を評価 (版2は評価仕様ID「231」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 110 : 231;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // サイクル情報の評価結果をDBに登録する
                    registEvaluationResultCycleInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 版1は評価仕様ID「111」を評価 (版2は評価仕様ID「232」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 111 : 232;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // サイクル情報の評価結果をDBに登録する
                    registEvaluationResultCycleInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// 青終了時間を評価する
        /// </summary>
        /// <param name="cycleInformation">サイクル情報</param>
        /// <returns>評価結果</returns>
        private bool evaluateBlueEndTime(StCycleInformation cycleInformation)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            bool evalResult = false;                                // 内部評価結果
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            int evalValue1 = (int)cycleInformation.BlueEndTimeMinimum;              // 青終了時間（最小）
            int evalValue2 = (int)cycleInformation.BlueEndTimeMaximum;              // 青終了時間（最大）

            // 版1は評価仕様ID「112」を評価 (版2は評価仕様ID「233」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 112 : 233;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.MultiItemReferenceCheck)  // 評価パターン:多項目参照評価 (他値との比較チェックなど)
                    {
                        // 多項目参照評価を行う (サイクル長（最小）≦サイクル長（最大）を確認)
                        evalResult = (evalValue1 <= evalValue2);
                    }
                    // サイクル情報の評価結果をDBに登録する
                    registEvaluationResultCycleInformation(evalSpecId, null, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// 青終了時間（最小）を評価する
        /// </summary>
        /// <param name="cycleInformation">サイクル情報</param>
        /// <returns>評価結果</returns>
        private bool evaluateBlueEndTimeMinimum(StCycleInformation cycleInformation)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            bool evalResult = false;                                // 内部評価結果
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            int evalValue = (int)cycleInformation.BlueEndTimeMinimum;              // 青終了時間（最小）

            // 版1は評価仕様ID「113」を評価 (版2は評価仕様ID「234」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 113 : 234;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // サイクル情報の評価結果をDBに登録する
                    registEvaluationResultCycleInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 版1は評価仕様ID「114」を評価 (版2は評価仕様ID「235」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 114 : 235;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // サイクル情報の評価結果をDBに登録する
                    registEvaluationResultCycleInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// 青終了時間（最大）を評価する
        /// </summary>
        /// <param name="cycleInformation">サイクル情報</param>
        /// <returns>評価結果</returns>
        private bool evaluateBlueEndTimeMaximum(StCycleInformation cycleInformation)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            bool evalResult = false;                                // 内部評価結果
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            int evalValue = (int)cycleInformation.BlueEndTimeMaximum;              // 青終了時間（最大）

            // 版1は評価仕様ID「115」を評価 (版2は評価仕様ID「236」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 115 : 236;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // サイクル情報の評価結果をDBに登録する
                    registEvaluationResultCycleInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 版1は評価仕様ID「116」を評価 (版2は評価仕様ID「237」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 116 : 237;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // サイクル情報の評価結果をDBに登録する
                    registEvaluationResultCycleInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// 指令サイクル長を評価する
        /// </summary>
        /// <param name="cycleInformation">サイクル情報</param>
        /// <returns>評価結果</returns>
        private bool evaluateCommandCycleLength(StCycleInformation cycleInformation)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            bool evalResult = false;                                // 内部評価結果
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            int evalValue = (int)cycleInformation.CommandCycleLength;              // 指令サイクル長

            // 版1は評価仕様ID「117」を評価 (版2は評価仕様ID「238」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 117 : 238;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // サイクル情報の評価結果をDBに登録する
                    registEvaluationResultCycleInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 版1は評価仕様ID「118」を評価 (版2は評価仕様ID「239」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 118 : 239;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // サイクル情報の評価結果をDBに登録する
                    registEvaluationResultCycleInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// 黄時間を評価する
        /// </summary>
        /// <param name="cycleInformation">サイクル情報</param>
        /// <returns>評価結果</returns>
        private bool evaluateYellowTime(StCycleInformation cycleInformation)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            bool evalResult = false;                                // 内部評価結果
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            int evalValue = (int)cycleInformation.YellowTime;              // 黄時間

            // 版1は評価仕様ID「119」を評価 (版2は評価仕様ID「240」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 119 : 240;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // サイクル情報の評価結果をDBに登録する
                    registEvaluationResultCycleInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 版1は評価仕様ID「120」を評価 (版2は評価仕様ID「241」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 120 : 241;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // サイクル情報の評価結果をDBに登録する
                    registEvaluationResultCycleInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// 赤開始時間（最大）を評価する
        /// </summary>
        /// <param name="cycleInformation">サイクル情報</param>
        /// <returns>評価結果</returns>
        private bool evaluateRedStartTimeMaximum(StCycleInformation cycleInformation)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            bool evalResult = false;                                // 内部評価結果
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            int evalValue = (int)cycleInformation.RedStartTimeMaximum;              // 赤開始時間（最大）

            // 版1は評価仕様ID「121」を評価 (版2は評価仕様ID「242」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 121 : 242;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // サイクル情報の評価結果をDBに登録する
                    registEvaluationResultCycleInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 版1は評価仕様ID「122」を評価 (版2は評価仕様ID「243」を評価)
            if ((BeaconDataVersion == DataVersions.V1) || (BeaconDataVersion == DataVersions.V2))
            {
                int evalSpecId = (BeaconDataVersion == DataVersions.V1) ? 122 : 243;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // サイクル情報の評価結果をDBに登録する
                    registEvaluationResultCycleInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// ＵＴＭＳリンク情報を評価する
        /// </summary>
        /// <param name="routeSignalInformation">路線信号情報</param>
        /// <returns>評価結果</returns>
        private bool evaluateUTMSLinkInformation(StRouteSignalInformation routeSignalInformation)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            //                              (版2は評価仕様ID「244」を評価)
            if (BeaconDataVersion == DataVersions.V2)
            {
                int evalSpecId = 244;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NotCheck)  // 評価無し
                    {
                        // 評価をスキップする
                        Console.WriteLine("skip evaluateUTMSLinkInformation");
                    }
                    // 路線信号基本情報の評価結果をDBに登録する
                    registEvaluationResultRouteSignalInformation(evalSpecId, null, null);
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// 世代数：Ｋを評価する
        /// </summary>
        /// <param name="utmsLinkInformation">ＵＴＭＳリンク情報</param>
        /// <returns>評価結果</returns>
        private bool evaluateNumberOfGenerations(StUTMSLinkInformation utmsLinkInformation)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            bool evalResult = false;                                // 内部評価結果
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            int evalValue = (int)utmsLinkInformation.NumberOfGenerations;              // 世代数：Ｋ

            //                              (版2は評価仕様ID「245」を評価)
            if (BeaconDataVersion == DataVersions.V2)
            {
                int evalSpecId = 245;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 路線信号基本情報の評価結果をDBに登録する
                    registEvaluationResultRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            //                              (版2は評価仕様ID「246」を評価)
            if (BeaconDataVersion == DataVersions.V2)
            {
                int evalSpecId = 246;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 路線信号基本情報の評価結果をDBに登録する
                    registEvaluationResultRouteSignalInformation(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// 世代を評価する
        /// </summary>
        /// <param name="utmsLinkInformation">ＵＴＭＳリンク情報</param>
        /// <returns>評価結果</returns>
        private bool evaluateGeneration(StUTMSLinkInformation utmsLinkInformation)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            bool evalResult = false;                                // 内部評価結果
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            int evalValue1 = (int)utmsLinkInformation.NumberOfGenerations;      // 世代数：Ｋ
            int evalValue2 = (int)utmsLinkInformation.GenerationList.Count();   // 世代リストの要素数

            //                              (版2は評価仕様ID「247」を評価)
            if (BeaconDataVersion == DataVersions.V2)
            {
                int evalSpecId = 247;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.MultiItemReferenceCheck)  // 評価パターン:多項目参照評価 (他値との比較チェックなど)
                    {
                        // 多項目参照評価を行う (世代数 == 世代リストの要素数)
                        evalResult = (evalValue1 == evalValue2);
                    }
                    // 路線信号基本情報の評価結果をDBに登録する
                    registEvaluationResultRouteSignalInformation(evalSpecId, null, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// 格納リンク数：Ｌを評価する
        /// </summary>
        /// <param name="generation">世代</param>
        /// <returns>評価結果</returns>
        private bool evaluateNumberOfStoredLinks(StGeneration generation)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            bool evalResult = false;                                // 内部評価結果
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            int evalValue = (int)generation.NumberOfStoredLinks;              // 格納リンク数：Ｌ

            //                              (版2は評価仕様ID「248」を評価)
            if (BeaconDataVersion == DataVersions.V2)
            {
                int evalSpecId = 248;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 世代の評価結果をDBに登録する
                    registEvaluationResultGeneration(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            //                              (版2は評価仕様ID「249」を評価)
            if (BeaconDataVersion == DataVersions.V2)
            {
                int evalSpecId = 249;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // 世代の評価結果をDBに登録する
                    registEvaluationResultGeneration(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// ＵＴＭＳリンクを評価する
        /// </summary>
        /// <param name="generation">世代</param>
        /// <returns>評価結果</returns>
        private bool evaluateUTMSLink(StGeneration generation)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            bool evalResult = false;                                // 内部評価結果
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            int evalValue1 = (int)generation.NumberOfStoredLinks;       // 格納リンク数：Ｌ
            int evalValue2 = (int)generation.UTMSLinkList.Count();      // ＵＴＭＳリンクリストの要素数

            //                              (版2は評価仕様ID「250」を評価)
            if (BeaconDataVersion == DataVersions.V2)
            {
                int evalSpecId = 250;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.MultiItemReferenceCheck)  // 評価パターン:多項目参照評価 (他値との比較チェックなど)
                    {
                        // 多項目参照評価を行う (格納リンク数 == ＵＴＭＳリンクリストの要素数)
                        evalResult = (evalValue1 == evalValue2);
                    }
                    // 世代の評価結果をDBに登録する
                    registEvaluationResultGeneration(evalSpecId, null, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// ＵＴＭＳリンクの２次メッシュ座標を評価する
        /// </summary>
        /// <param name="utmsLink">ＵＴＭＳリンク</param>
        /// <returns>評価結果</returns>
        private bool evaluateUTMSLinkSecondaryMeshCoordinates(StUTMSLink utmsLink)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            bool evalResult = false;                                // 内部評価結果
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            int evalValue = (int)utmsLink.SecondaryMeshCoordinates;              // ２次メッシュ座標

            //                              (版2は評価仕様ID「251」を評価)
            if (BeaconDataVersion == DataVersions.V2)
            {
                int evalSpecId = 251;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // ＵＴＭＳリンクの評価結果をDBに登録する
                    registEvaluationResultUTMSLink(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// ＵＴＭＳリンクの２次メッシュ座標(緯度)を評価する
        /// </summary>
        /// <param name="utmsLink">ＵＴＭＳリンク</param>
        /// <returns>評価結果</returns>
        private bool evaluateUTMSLinkSecondaryMeshCoordinatesLat(StUTMSLink utmsLink)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            bool evalResult = false;                                // 内部評価結果
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            int evalValue = (int)utmsLink.SecondaryMeshCoordinatesLat;              // ２次メッシュ座標(緯度)

            //                              (版2は評価仕様ID「252」を評価)
            if (BeaconDataVersion == DataVersions.V2)
            {
                int evalSpecId = 252;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // ＵＴＭＳリンクの評価結果をDBに登録する
                    registEvaluationResultUTMSLink(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// ＵＴＭＳリンクの２次メッシュ座標(経度)を評価する
        /// </summary>
        /// <param name="utmsLink">ＵＴＭＳリンク</param>
        /// <returns>評価結果</returns>
        private bool evaluateUTMSLinkSecondaryMeshCoordinatesLon(StUTMSLink utmsLink)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            bool evalResult = false;                                // 内部評価結果
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            int evalValue = (int)utmsLink.SecondaryMeshCoordinatesLon;              // ２次メッシュ座標(経度)

            //                              (版2は評価仕様ID「253」を評価)
            if (BeaconDataVersion == DataVersions.V2)
            {
                int evalSpecId = 253;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // ＵＴＭＳリンクの評価結果をDBに登録する
                    registEvaluationResultUTMSLink(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// ＵＴＭＳリンクの予約領域を評価する
        /// </summary>
        /// <param name="utmsLink">ＵＴＭＳリンク</param>
        /// <returns>評価結果</returns>
        private bool evaluateUTMSLinkReserved(StUTMSLink utmsLink)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            bool evalResult = false;                                // 内部評価結果
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            int evalValue = (int)utmsLink.Reserved;              // 予約領域

            //                              (版2は評価仕様ID「254」を評価)
            if (BeaconDataVersion == DataVersions.V2)
            {
                int evalSpecId = 254;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // ＵＴＭＳリンクの評価結果をDBに登録する
                    registEvaluationResultUTMSLink(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// 道路種別を評価する
        /// </summary>
        /// <param name="utmsLink">ＵＴＭＳリンク</param>
        /// <returns>評価結果</returns>
        private bool evaluateRoadClassification(StUTMSLink utmsLink)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            bool evalResult = false;                                // 内部評価結果
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            int evalValue = (int)utmsLink.RoadClassification;              // 道路種別

            //                              (版2は評価仕様ID「255」を評価)
            if (BeaconDataVersion == DataVersions.V2)
            {
                int evalSpecId = 255;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // ＵＴＭＳリンクの評価結果をDBに登録する
                    registEvaluationResultUTMSLink(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            //                              (版2は評価仕様ID「256」を評価)
            if (BeaconDataVersion == DataVersions.V2)
            {
                int evalSpecId = 256;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // ＵＴＭＳリンクの評価結果をDBに登録する
                    registEvaluationResultUTMSLink(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

        /// <summary>
        /// リンク番号を評価する
        /// </summary>
        /// <param name="utmsLink">ＵＴＭＳリンク</param>
        /// <returns>評価結果</returns>
        private bool evaluateLinkNumber(StUTMSLink utmsLink)
        {
            bool evalFailed = false;                                // 評価NG検出フラグ
            bool evalResult = false;                                // 内部評価結果
            DatabaseAccessor.StEvaluationSpecification evalSpec;    // 評価仕様

            // 評価値を取得
            int evalValue = (int)utmsLink.LinkNumber;              // リンク番号

            //                              (版2は評価仕様ID「257」を評価)
            if (BeaconDataVersion == DataVersions.V2)
            {
                int evalSpecId = 257;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // ＵＴＭＳリンクの評価結果をDBに登録する
                    registEvaluationResultUTMSLink(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            //                              (版2は評価仕様ID「258」を評価)
            if (BeaconDataVersion == DataVersions.V2)
            {
                int evalSpecId = 258;
                // DBから評価仕様を取得する
                getEvaluationSpecification(evalSpecId, out evalSpec);
                // 評価を実施する (論理削除:FALSE時のみ評価)
                if (evalSpec.LogicalDelete == false)
                {
                    if (evalSpec.pattern == DatabaseAccessor.EvaluationPattern.NormalCheck)  // 評価パターン:通常評価
                    {
                        // 通常評価を行う
                        evalResult = evaluateEvaluationSpecification(evalSpec, evalValue);
                    }
                    // ＵＴＭＳリンクの評価結果をDBに登録する
                    registEvaluationResultUTMSLink(evalSpecId, evalValue, evalResult);
                    // 評価失敗時には、評価NG検出フラグをONする
                    if (!evalResult)
                    {
                        evalFailed |= true;
                        Console.WriteLine($"error detect evalSpecId ={evalSpecId}");
                    }
                }
            }

            // 評価結果を返却する
            return !evalFailed;     // 評価NG検出フラグの論理否定を返却
        }

    }
}
