﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;


namespace BeaconDataEvaluator
{
    /// <summary>
    /// データエクスポート処理クラス
    /// </summary>
    /// <remarks>
    /// 下記のデータ評価処理を行う。
    ///  ・評価結果(詳細)出力
    ///  ・カテゴリ別NG件数カウント結果出力
    ///  ・評価結果(NG項目のみ)出力
    ///  ・オフセット信号同期出力
    ///  ・路線別MAP出力
    ///  ・路線別位置情報出力
    /// </remarks>
    public class DataExporter
    {
        /// <summary>
        /// エクスポート対象定義
        /// </summary>
        public enum ExportType
        {
            EvalResults,            ///< 評価結果
            NGCountByCategory,      ///< カテゴリ別NG件数カウント結果
            EvalResultNGCount,      ///< 評価結果NG項目
            SyncOffsetSignal,       ///< オフセット信号同期
            MapHTML,                ///< 地図HTML
            MapImage,               ///< 地図画像
            LocationInfoByRoute,    ///< 路線別位置情報
        }

        private DatabaseAccessor dataBaseAccessor;                              ///< データベース通信クラス
        private System.Windows.Threading.Dispatcher mainWindowDispatcher;       ///< メインウィンドウのディスパッチャ

        private const string RESULT_MAKE_SUMMRYFOLDER_STRING = @"\00_サマリ";  ///< サマリフォルダ名
        private const string RESULT_MAKE_DETAILFOLDER_STRING = @"\01_詳細";    ///< 詳細フォルダ名
        private string summryfloder;                                           ///< サマリフォルダ名パス
        private string detailfloder;                                           ///< 詳細フォルダ名パス
        private CsvFileMaker csvfilemaker;                                     ///< csvファイル作成クラス
        private StSummaryData summraydata;                                      ///< サマリデータ構造体
        private const string ROUTE_NAME_BASE = @"路線";                        ///< 路線HTMLファイル名のベース文字列(路線番号を後から付与する)

        // エクスポート名称文字列
        private const string EXPORT_NAME_EVAL_RESULTS = @"評価結果";                                ///< 評価結果
        private const string EXPORT_NAME_NG_COUNT_BY_CATEGORY = @"カテゴリ別NG件数カウント結果";    ///< カテゴリ別NG件数カウント結果
        private const string EXPORT_NAME_EVAL_RESULT_NG_COUNT = @"評価結果NG項目";                  ///< 評価結果NG項目
        private const string EXPORT_NAME_SYNC_OFFSET_SIGNAL = @"オフセット信号同期";                ///< オフセット信号同期
        private const string EXPORT_NAME_MAP_HTML = @"MAP";                                         ///< 地図HTML
        private const string EXPORT_NAME_MAP_IMAGE = @"MAP";                                        ///< 地図画像
        private const string EXPORT_NAME_LOCATION_INFO_BY_ROUTE = @"路線別位置情報";                ///< 路線別位置情報

        // 拡張子文字列
        private const string EXTENSION_NAME_CSV = @"csv";       ///< CSVファイルの拡張子
        private const string EXTENSION_NAME_HTML = @"htm";      ///< HTMLファイルの拡張子
        private const string EXTENSION_NAME_IMAGE = @"jpg";     ///< 画像ファイルの拡張子

        /// コンストラクタ
        public DataExporter(DatabaseAccessor dbAccessor, System.Windows.Threading.Dispatcher mwDispatcher)
        {
            // データベース通信クラスを保持
            dataBaseAccessor = dbAccessor;
            // メインウィンドウのディスパッチャを保持
            mainWindowDispatcher = mwDispatcher;
        }

        /// デストラクタ
        ~DataExporter()
        {
        }

        /// <summary>
        /// エクスポートを実行する
        /// </summary>
        public void Execute(int drivingInfoId, string inputPath, string outputPath)
        {
            // drivingInfoIdを基に、評価履歴テーブルを検索し、Lengthエラーがあれば以降の処理を行わない
            var lengthErrorRec = dataBaseAccessor.GetLengthErrorCount(drivingInfoId);
            if (lengthErrorRec > 0)
            {
                return;
            }

            try
            {
                /// 指定されたOUTPUTフォルダ下に「サマリ」「詳細」フォルダを作成する
                summryfloder = outputPath + RESULT_MAKE_SUMMRYFOLDER_STRING;
                detailfloder = outputPath + RESULT_MAKE_DETAILFOLDER_STRING;
                Directory.CreateDirectory(summryfloder);
                Directory.CreateDirectory(detailfloder);


                csvfilemaker = new CsvFileMaker(dataBaseAccessor);                      /// csvファイル作成クラス

                string filepath = detailfloder;
                DatabaseAccessor.StDrivingInfo drivingInfo;    /// 走行基本情報

                /// 走行基本情報を取得
                getDrivingInfo(drivingInfoId, out drivingInfo);

                // 都道府県名を取得する
                var prefectureName = dataBaseAccessor.ReferencePrefectureName(drivingInfo.PrefectureId);
                prefectureName = $"{drivingInfo.PrefectureId:00}_" + prefectureName;

                // 路線名を取得する
                var routeName = $"路線{drivingInfo.RouteNum:000}";

                /// csvファイル格納ファイルパス
                filepath = filepath + "\\" + prefectureName.ToString() + "\\" + routeName.ToString();
                Directory.CreateDirectory(filepath);
                /// 詳細ファイルパスをサマリーデータ構造体に格納
                summraydata.FilePath = filepath;

                // 評価結果Csvファイル出力情報プロパティリスト(まとめて出力するためのリスト)を生成
                List<CsvFileMaker.CsvEvaluatResult> EvaluatResultCsvList;

                /// 評価結果CSVファイル作成
                summraydata.EvaluationResultItemFileName = csvfilemaker.EvaluatResultCsvStart(drivingInfoId, drivingInfo.Version, filepath, out EvaluatResultCsvList);

                /// カテゴリ別NG件数カウント結果CSVファイル作成
                summraydata.CategoryCountResultFileName = csvfilemaker.CategoryNgCountCsvStart(drivingInfoId, filepath);

                /// 評価結果NG項目CSVファイル作成
                summraydata.EvaluationResultNgItemFileName = csvfilemaker.EvaluatResultNgItemCsvStart(drivingInfoId, filepath, EvaluatResultCsvList);

                /// オフセット信号同期CSVファイル作成
                summraydata.OffsetSignalSyncValueFileName = csvfilemaker.OffsetSignalSyncCsvStart(drivingInfoId, filepath, EvaluatResultCsvList);

                // 路線別位置情報CSVファイル作成
                List<DatabaseAccessor.StIntersectionInfo> intersectionInfos;
                List<ImportedCoordinate> importedCoordinates;
                var evaluationVersion = drivingInfo.Version;
                string locationInfo_filename = calculateLocationInfoByRoute(drivingInfoId, evaluationVersion, out intersectionInfos, out importedCoordinates);    // 路線別位置情報を計算する
                summraydata.LocationInfoFileName = csvfilemaker.LocationInfoByRouteCsvStart(drivingInfoId, filepath, locationInfo_filename, intersectionInfos, importedCoordinates);    // 路線別位置情報CSVファイル出力

                // HTML&JPEGファイル作成
                summraydata.MapImageFileName = makeIntersectionImage(drivingInfoId, inputPath, detailfloder, intersectionInfos, importedCoordinates); // 交差点HTML画像を作成する

                /// サマリ作成
                SummaryFileMaker summaryFileMaker = new SummaryFileMaker();
                summaryFileMaker.Start(drivingInfoId, summraydata);
                summaryFileMaker.Dispose();
            }
            catch
            {

            }
        }

        /// <summary>
        /// DBから走行基本情報を取得する
        /// </summary>
        /// <returns>走行基本情報ID</returns>
        /// <remarks>[out]走行基本情報</remarks>
        private bool getDrivingInfo(int drivingInfoId, out DatabaseAccessor.StDrivingInfo drivingInfo)
        {
            // 走行基本情報データを生成
            drivingInfo = new DatabaseAccessor.StDrivingInfo();

            // 指定された走行基本情報IDの走行基本情報データをDBから取得して返却する
            return dataBaseAccessor.GetDrivingInfo(drivingInfoId, out drivingInfo);
        }

        /// <summary>
        /// エクスポートを中断する
        /// </summary>
        public void Cancel()
        {

        }

        /// <summary>
        /// 路線別位置情報を計算する
        /// </summary>
        /// <param name="drivingInfoId">走行基本情報ID</param>
        /// <param name="evaluationVersion">版</param>
        /// <param name="intersectionInfos">真値の座標リスト</param>
        /// <param name="importedCoordinates">インポートされた座標リスト</param>
        /// <returns>路線別位置情報出力ファイル名</returns>
        private string calculateLocationInfoByRoute(int drivingInfoId, DatabaseAccessor.EvaluationVersion evaluationVersion, out List<DatabaseAccessor.StIntersectionInfo> intersectionInfos, out List<ImportedCoordinate> importedCoordinates)
        {
            string locationInfoByRouteFilename = @"";

            // 路線別位置情報を計算する
            var intersectionHtmlMaker = new IntersectionHtmlMaker(dataBaseAccessor, mainWindowDispatcher);
            intersectionHtmlMaker.CalculateLocationInformationByRoute(drivingInfoId, evaluationVersion, out intersectionInfos, out importedCoordinates);
            // 路線別位置情報出力ファイル名
            locationInfoByRouteFilename = makeExporteFilepath(drivingInfoId, dataBaseAccessor, DataExporter.ExportType.LocationInfoByRoute);

            // 路線別位置情報出力ファイル名を返却する
            return locationInfoByRouteFilename;
        }

        /// <summary>
        /// 交差点HTML画像を作成する
        /// </summary>
        /// <returns>走行基本情報ID</returns>
        /// <param name="inputPath">入力情報フォルダパス</param>
        /// <param name="outputPath">出力情報フォルダパス</param>
        /// <param name="intersectionInfos">真値の座標リスト</param>
        /// <param name="importedCoordinates">インポートされた座標リスト</param>
        /// <returns>交差点HTML画像のファイル名</returns>
        private string makeIntersectionImage(int drivingInfoId, string inputPath, string outputPath, List<DatabaseAccessor.StIntersectionInfo> intersectionInfos, List<ImportedCoordinate> importedCoordinates)
        {
            string imageFilepath = @"";

            // 交差点HTML画像を作成する
            var intersectionHtmlMaker = new IntersectionHtmlMaker(dataBaseAccessor, mainWindowDispatcher);
            imageFilepath = intersectionHtmlMaker.Start(drivingInfoId, inputPath, outputPath, intersectionInfos, importedCoordinates);

            // 交差点HTML画像のファイル名を返却する
            return imageFilepath;
        }

        /// <summary>
        /// エクスポート対象ファイルパスを作成する
        /// </summary>
        /// <param name="dbAccessor">データベースアクセサ</param>
        /// <param name="exportType">エクスポート対象</param>
        /// <returns>エクスポート対象ファイルパス文字列</returns>
        public static string makeExporteFilepath(int drivingInfoId, DatabaseAccessor dbAccessor, ExportType exportType)
        {
            string exporteFilepath = "";        // 作成するエクスポート対象ファイルパス文字列

            // DBから最新の走行基本情報を取得する
            DatabaseAccessor.StDrivingInfo drivingInfo;
            dbAccessor.GetDrivingInfo(drivingInfoId, out drivingInfo);

            // 走行日時を取得する
            var drivingDateTime = drivingInfo.DrivingDatetime;
            string drivingDateTimeName = $@"{drivingDateTime:yyyyMMdd-HHmmssfff}";

            // エクスポート名称と拡張子を取得する
            var exportName = $@"";
            var extensionName = $@"";
            switch (exportType) {
            case ExportType.EvalResults:            // 評価結果
                exportName = EXPORT_NAME_EVAL_RESULTS;
                extensionName = EXTENSION_NAME_CSV;
                break;
            case ExportType.NGCountByCategory:      // カテゴリ別NG件数カウント結果
                exportName = EXPORT_NAME_NG_COUNT_BY_CATEGORY;
                extensionName = EXTENSION_NAME_CSV;
                break;
            case ExportType.EvalResultNGCount:      // 評価結果NG項目
                exportName = EXPORT_NAME_EVAL_RESULT_NG_COUNT;
                extensionName = EXTENSION_NAME_CSV;
                break;
            case ExportType.SyncOffsetSignal:       // オフセット信号同期
                exportName = EXPORT_NAME_SYNC_OFFSET_SIGNAL;
                extensionName = EXTENSION_NAME_CSV;
                break;
            case ExportType.MapHTML:                // 地図HTML
                exportName = EXPORT_NAME_MAP_HTML;
                extensionName = EXTENSION_NAME_HTML;
                break;
            case ExportType.MapImage:               // 地図画像
                exportName = EXPORT_NAME_MAP_IMAGE;
                extensionName = EXTENSION_NAME_IMAGE;
                break;
            case ExportType.LocationInfoByRoute:    // 路線別位置情報
                exportName = EXPORT_NAME_LOCATION_INFO_BY_ROUTE;
                extensionName = EXTENSION_NAME_CSV;
                break;
            }

            // 都道府県名と路線番号を取得する
            short prefectureId = drivingInfo.PrefectureId;                                      // 都道府県ID
            string prefectureName = dbAccessor.ReferencePrefectureName(prefectureId);
            prefectureName = $@"{prefectureId:00}-" + prefectureName;                           // 都道府県名
            short routeNum = drivingInfo.RouteNum;                          // 路線番号
            string routeName = ROUTE_NAME_BASE + $@"{routeNum:000}";    // 路線名

            // 版を取得する
            var version = drivingInfo.Version;
            var versionName = $@"版{(short)version:0}";

            // 評価日時を取得する
            //var latestEvaluationHistoryId = dbAccessor.GetLatestEvaluationHistoryId();// 最新の評価実施履歴IDを参照
            var oldestEvaluationHistoryId = dbAccessor.GetOldestEvaluationHistoryId(drivingInfoId);// 最新の評価実施履歴IDを参照
            DatabaseAccessor.StEvaluationHistory evaluationHistory;
            //dbAccessor.GetRouteSignalInfo(drivingInfoId, latestEvaluationHistoryId, out evaluationHistory);//評価実施履歴を取得する
            dbAccessor.GetRouteSignalInfo(drivingInfoId, oldestEvaluationHistoryId, out evaluationHistory);//評価実施履歴を取得する
            var evaluationDatetime = evaluationHistory.EvaluationDatetime;
            string evaluationDatetimeName = $@"{evaluationDatetime:yyyyMMdd-HHmmss}";

            // エクスポート対象ファイルパス文字列を作成する
            exporteFilepath = $@"{drivingDateTimeName}_{exportName}_{prefectureName}_{routeName}_{versionName}_{evaluationDatetimeName}.{extensionName}";

            // 作成されたエクスポート対象ファイルパス文字列を返却
            return exporteFilepath;
        }

    }
}
