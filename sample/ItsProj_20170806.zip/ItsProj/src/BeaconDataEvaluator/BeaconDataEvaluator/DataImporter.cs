﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace BeaconDataEvaluator
{
    /// <summary>
    /// データインポート処理クラス
    /// </summary>
    /// <remarks>
    /// 下記のデータインポート処理を行う。
    ///  ・ビーコン情報変換
    ///  ・光ビーコン番号変換
    ///  ・チェックカテゴリ変換
    /// </remarks>
    public class DataImporter
    {
        private const int EVALUATED_PREFECTURE_NAME_PREFIX_WIDTH = 3;                   ///< 評価対象都道府県名の接頭語文字数(3文字)
        private const string EVALUATED_FILES_SEARCH_STRING = @"ir_id31*.dat";           ///< 評価対象ファイル検索用文字列
        private const string EVALUATED_FILE_PREFIX_STRING = @"ir_id31_";                ///< 評価対象ファイル先頭文字列
        private const string EVALUATED_FILE_TIME_FIELD_STRING = @"yyyyMMdd-HHmmssfff";  ///< 評価対象ファイル時刻フィールド文字列
        private const string EVALUATED_DIRECTORY_ROUTE_NAME_STRING = @"路線";           ///< 評価対象ディレクトリ路線名文字列

        private const int LENGTH_BEACON_DATA_HEADER = 5;                        ///< ビーコンデータのヘッダ部データサイズ (5バイト)
        private const int LENGTH_ROUTE_SIGNAL_INFORMATION = 10;                 ///< 路線信号情報の固定長部データサイズ (10バイト)
        private const int LENGTH_INTERSECTION_ROUTE_SIGNAL_INFORMATION = 27;    ///< 交差点路線信号情報の固定長部データサイズ (27バイト)
        private const int LENGTH_CYCLE_INFORMATION = 13;                        ///< サイクル情報のデータサイズ (13バイト)
        private const int LENGTH_UTMS_LINK_INFORMATION = 1;                     ///< ＵＴＭＳリンク情報の固定長部データサイズ (1バイト)
        private const int LENGTH_GENERATION = 1;                                ///< 世代のデータサイズ (1バイト)
        private const int LENGTH_UTMS_LINK = 4;                                 ///< ＵＴＭＳリンクのデータサイズ (4バイト)

        private BeaconDataReader beaconDataReader;  ///< ビーコンデータ読み込みクラス
        private DatabaseAccessor dataBaseAccessor;  ///< データベース通信クラス

        private string[] evaluatedFiles;            ///< 評価対象ファイルテーブル
        private int evaluatedCount;                 ///< 評価済みファイル数

        /// コンストラクタ
        public DataImporter(DatabaseAccessor dbAccessor)
        {
            // データベース通信クラスを保持
            dataBaseAccessor = dbAccessor;

            // ビーコンデータ読み込みクラスを生成
            beaconDataReader = new BeaconDataReader();

            // 評価対象ファイルテーブルを初期化
            evaluatedFiles = null;
            evaluatedCount = 0;
        }

        /// デストラクタ
        ~DataImporter()
        {
        }

        /// <summary>
        /// 評価対象のファイル数を数える
        /// </summary>
        /// <returns>インポート対象ファイル数</returns>
        public int CountEvaluatedFiles(string inputPath)
        {
            // inputPathで指定されたフォルダ配下の評価対象ファイルをすべて取得する。
            // ワイルドカードEVALUATED_FILES_SEARCH_STRINGは、本評価対象のファイルを意味する。
            evaluatedFiles = System.IO.Directory.GetFiles(
                inputPath, EVALUATED_FILES_SEARCH_STRING, System.IO.SearchOption.AllDirectories);

            // forDEBUG：インポート対象ファイル数とファイル名一覧をコンソール出力する
            Console.WriteLine($"evaluateTargetFileCount={evaluatedFiles.Count()}");
            int count = 0;
            foreach (var evalueateFile in evaluatedFiles)
            {
                Console.WriteLine($"evaluateFile[{count++}]={evalueateFile}");
            }

            // 評価済みファイル数を初期化
            evaluatedCount = 0;

            // 評価対象のファイル数を返却
            return evaluatedFiles.Count();
        }

        /// <summary>
        /// インポートを実行する
        /// </summary>
        /// <param name="basicTripInfo">[out]走行基本情報</param>
        /// <param name="routeSignalInfo">[out]路線信号情報</param>
        /// <returns>成功/失敗</returns>
        public bool Execute(out StBasicTripInformation basicTripInfo, out StRouteSignalInformation routeSignalInfo)
        {
            int readPos = 0;                        // バッファ読み込み位置
            
            // ビーコンデータをファイルから読み込む
            byte[] readBuf;                                         // ビーコンデータ読み込みバッファ
            string filepath = evaluatedFiles[evaluatedCount++];     // 評価対象ファイルパス
            var readResult = beaconDataReader.Read(filepath, out readBuf);

            // 読み込んだビーコンデータから、ビーコンデータヘッダ部を読み飛ばす
            StBeaconDataHeader beaconDataHeader;
            getBeaconDataHeader(readBuf, ref readPos, out beaconDataHeader);

            // 読み込んだビーコンデータから、路線信号情報を取得する
            var getResult = getRouteSignalInformation(readBuf, ref readPos, out routeSignalInfo);

            // 基本走行情報を取得する
            getBasicTripInformation(filepath, routeSignalInfo, out basicTripInfo);

            // 路線信号情報取得がエラー終了した場合、または
            // インポート対象データ長の理論値を算出して、実際にファイルから読み出したサイズと一致しない場合は、
            if (!getResult || getImportedDataSize(routeSignalInfo) != readBuf.Count())
            {
                // エラーを返却
                return false;
            }

            // 成功を返却
            return true;
        }

        /// <summary>
        /// インポートを中断する
        /// </summary>
        public void Cancel()
        {

        }

        /// <summary>
        /// インポート対象データのデータ長理論値を算出する
        /// </summary>
        /// <param name="routeSignalInfo">路線信号情報</param>
        /// <returns>算出したデータ長理論値</returns>
        private int getImportedDataSize(StRouteSignalInformation routeSignalInfo)
        {
            // インポート対象データ長
            int importedDataSize = 0;

            // NOTE: ■路線信号ビーコンデータのデータ構成
            // NOTE: 
            // NOTE: 路線信号ビーコンデータ ＝ ビーコンデータヘッダ部                 [ 5バイト]
            // NOTE:                        ＋ 路線信号情報構造体の固定長部           [10バイト]
            // NOTE:                            ＋ I * ( 交差点路線信号情報の固定長部 [27バイト]
            // NOTE:                                ＋ J * サイクル情報               [13バイト] )
            // NOTE:                            ＋ ＵＴＭＳリンク情報の固定長部       [ 1バイト]
            // NOTE:                                ＋ K * ( 世代                     [ 1バイト]
            // NOTE:                                    ＋ L * ＵＴＭＳリンク         [ 4バイト] )

            try
            {
                // ヘッダ部データサイズを加算                                               [ 5バイト]
                importedDataSize += LENGTH_BEACON_DATA_HEADER;
                // 路線信号情報の固定長部データサイズを加算                                 [10バイト]
                importedDataSize += LENGTH_ROUTE_SIGNAL_INFORMATION;
                foreach (var intersectionRouteSignalInfo in routeSignalInfo.IntersectionRouteSignalInformationList)
                {
                    // 交差点路線信号情報の固定長部データサイズを加算 (I個)                 [27バイト]
                    importedDataSize += LENGTH_INTERSECTION_ROUTE_SIGNAL_INFORMATION;
                    foreach (var cycleInfo in intersectionRouteSignalInfo.CycleInformationList)
                    {
                        // サイクル情報のデータサイズを加算 (J個)                           [13バイト]
                        importedDataSize += LENGTH_CYCLE_INFORMATION;
                    }
                }
                // データ形式区分が「０」以外の場合のみ、ＵＴＭＳリンク情報をチェックする
                if (routeSignalInfo.DataTypeIndicator != 0)
                {
                    // ＵＴＭＳリンク情報データサイズを加算                                     [ 1バイト]
                    importedDataSize += LENGTH_UTMS_LINK_INFORMATION;
                    foreach (var generation in routeSignalInfo.UTMSLinkInformation.GenerationList)
                    {
                        // 世代のデータサイズを加算 (K個)                                       [ 1バイト]
                        importedDataSize += LENGTH_GENERATION;
                        foreach (var UTMSLink in generation.UTMSLinkList)
                        {
                            // ＵＴＭＳリンクのデータサイズを加算 (L個)                         [ 4バイト]
                            importedDataSize += LENGTH_UTMS_LINK;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("getImportedDataSize error");
                Console.WriteLine(ex.Message);
                // 例外発生時はインポート対象データ長をゼロに戻す
                importedDataSize = 0;
            }

            // インポート対象データ長を返却
            return importedDataSize;
        }

        /// <summary>
        /// 基本走行情報を取得する
        /// </summary>
        /// <param name="filepath">対象ビーコンデータのファイルパス</param>
        /// <param name="routeSignalInfo">ビーコンデータから取得した路線信号情報</param>
        /// <param name="travelingInfo">[out]基本走行情報</param>
        private void getBasicTripInformation(string filepath, StRouteSignalInformation routeSignalInfo, out StBasicTripInformation travelingInfo)
        {
            travelingInfo = new StBasicTripInformation();

            try
            {
                // ファイル名から走行日時を取得
                string fileName = Path.GetFileNameWithoutExtension(filepath);
                string dateString = fileName.Replace(EVALUATED_FILE_PREFIX_STRING, "");
                if (!DateTime.TryParseExact(dateString, EVALUATED_FILE_TIME_FIELD_STRING,
                         System.Globalization.CultureInfo.InvariantCulture,
                         System.Globalization.DateTimeStyles.None, out travelingInfo.TripTimestamp))
                    travelingInfo.TripTimestamp = new DateTime();
            }
            catch { }

            try
            {
                // ディレクトリ名から路線名と都道府県名を取得
                string directoryName = Path.GetDirectoryName(filepath);
                string routeName = Path.GetFileName(directoryName);
                if (!short.TryParse(routeName.Replace(EVALUATED_DIRECTORY_ROUTE_NAME_STRING, ""), out travelingInfo.RouteNumber))
                    travelingInfo.RouteNumber = 0;          // 路線番号を抽出
                string prefecturesName = Path.GetFileName(Path.GetDirectoryName(directoryName));
                prefecturesName = prefecturesName.Remove(0, EVALUATED_PREFECTURE_NAME_PREFIX_WIDTH);    // 接頭語を削除
                var prefecturesId = dataBaseAccessor.ReferencePrefectureId(prefecturesName);
                travelingInfo.PrefecturesId = (byte)prefecturesId;
            }
            catch { }

            try
            {
                // 読み出したビーコンデータから版を取得
                travelingInfo.BeaconDataVersion = routeSignalInfo.DataTypeIndicator;
            }
            catch { }
        }

        /// <summary>
        /// ビーコンデータヘッダ部を取得する
        /// </summary>
        /// <param name="readBuf">ビーコンデータ格納バッファ</param>
        /// <param name="readPos">[ref]バッファ読み出し位置</param>
        /// <param name="beaconDataHeader">[out]ビーコンデータヘッダ部</param>
        /// <returns>成功/失敗</returns>
        private bool getBeaconDataHeader(byte[] readBuf, ref int readPos, out StBeaconDataHeader beaconDataHeader)
        {
            int bitPos;                 // 読み出しデータのビット位置
            int bitLen;                 // 読み出しデータのビット幅
            ulong resultValue;          // 取得データ格納変数

            // 路線信号情報を生成
            beaconDataHeader = new StBeaconDataHeader();

            // 規格フラグを取得            bin(1) Ｃ－８ １バイト
            bitPos = 0;
            bitLen = 1;
            beaconDataReader.GetBitFieldData(readBuf, readPos, bitPos, bitLen, out resultValue);
            beaconDataHeader.StandardFlag = (byte)resultValue;
            // 情報フラグを取得            bin(1) Ｃ－１
            bitPos += bitLen;
            bitLen = 1;
            beaconDataReader.GetBitFieldData(readBuf, readPos, bitPos, bitLen, out resultValue);
            beaconDataHeader.InformationFlag = (byte)resultValue;
            // 情報種別を取得              bin(6) Ｉ－１
            bitPos += bitLen;
            bitLen = 6;
            beaconDataReader.GetBitFieldData(readBuf, readPos, bitPos, bitLen, out resultValue);
            beaconDataHeader.InformationType = (byte)resultValue;
            readPos += sizeof(byte);
            if (readPos > readBuf.Count()) return false;    // 読み出し位置がバッファサイズ超過時はエラーを返却

            // 提供時刻情報：情報提供：時を取得     bin(5) Ｆ－１ ２バイト
            bitPos = 0;
            bitLen = 5;
            beaconDataReader.GetBitFieldData(readBuf, readPos, bitPos, bitLen, out resultValue);
            beaconDataHeader.StandardFlag = (byte)resultValue;
            // 提供時刻情報：情報提供：分を取得     bin(6) Ｆ－２
            bitPos += bitLen;
            bitLen = 6;
            beaconDataReader.GetBitFieldData(readBuf, readPos, bitPos, bitLen, out resultValue);
            beaconDataHeader.InformationFlag = (byte)resultValue;
            // 予備を取得                           bin(5)
            bitPos += bitLen;
            bitLen = 5;
            beaconDataReader.GetBitFieldData(readBuf, readPos, bitPos, bitLen, out resultValue);
            beaconDataHeader.InformationType = (byte)resultValue;
            readPos += sizeof(short);
            if (readPos > readBuf.Count()) return false;    // 読み出し位置がバッファサイズ超過時はエラーを返却

            // 最終フレームフラグを取得            bin(1) Ｃ－２ １バイト
            bitPos = 0;
            bitLen = 1;
            beaconDataReader.GetBitFieldData(readBuf, readPos, bitPos, bitLen, out resultValue);
            beaconDataHeader.LastFrameFlag = (byte)resultValue;
            // 同一情報種別内フレーム番号を取得    bin(7) Ａ－７
            bitPos += bitLen;
            bitLen = 7;
            beaconDataReader.GetBitFieldData(readBuf, readPos, bitPos, bitLen, out resultValue);
            beaconDataHeader.FrameNumberWithinSameInformationType = (byte)resultValue;
            readPos += sizeof(byte);
            if (readPos > readBuf.Count()) return false;    // 読み出し位置がバッファサイズ超過時はエラーを返却

            // フレームデータ有効データ長を取得    bin(8) Ａ－８ １バイト
            bitPos = 0;
            bitLen = 8;
            beaconDataReader.GetBitFieldData(readBuf, readPos, bitPos, bitLen, out resultValue);
            beaconDataHeader.FrameDataLength = (byte)resultValue;
            readPos += sizeof(byte);
            if (readPos > readBuf.Count()) return false;    // 読み出し位置がバッファサイズ超過時はエラーを返却

            // 成功を返却
            return true;
        }

        /// <summary>
        /// 路線信号情報を取得する
        /// </summary>
        /// <param name="readBuf">ビーコンデータ格納バッファ</param>
        /// <param name="readPos">[ref]バッファ読み出し位置</param>
        /// <param name="routeSignal">[out]路線信号情報</param>
        /// <returns>成功/失敗</returns>
        private bool getRouteSignalInformation(byte[] readBuf, ref int readPos, out StRouteSignalInformation routeSignal)
        {
            bool getResult = false;     // データ取得結果

            int bitPos;                 // 読み出しデータのビット位置
            int bitLen;                 // 読み出しデータのビット幅
            ulong resultValue;          // 取得データ格納変数

            // 路線信号情報を生成
            routeSignal = new StRouteSignalInformation();

            // 基準点からの経過時間を取得    bin(16) Ｓ－16 ２バイト
            bitPos = 0;
            bitLen = 16;
            beaconDataReader.GetBitFieldData(readBuf, readPos, bitPos, bitLen, out resultValue);
            routeSignal.ElapsedTimeFromReferencePoint = (short)resultValue;
            readPos += sizeof(short);
            if (readPos > readBuf.Count()) return false;    // 読み出し位置がバッファサイズ超過時はエラーを返却

            // 予備を取得    bin(8)
            bitPos = 0;
            bitLen = 8;
            beaconDataReader.GetBitFieldData(readBuf, readPos, bitPos, bitLen, out resultValue);
            routeSignal.Reserved = (byte)resultValue;
            readPos += sizeof(byte);
            if (readPos > readBuf.Count()) return false;    // 読み出し位置がバッファサイズ超過時はエラーを返却

            // 基準点とデータ生成時刻の差を取得     bin(16) Ｓ－16 ２バイト
            bitPos = 0;
            bitLen = 16;
            beaconDataReader.GetBitFieldData(readBuf, readPos, bitPos, bitLen, out resultValue);
            routeSignal.DifferenceSinceDataGenerationTime = (short)resultValue;
            readPos += sizeof(short);
            if (readPos > readBuf.Count()) return false;    // 読み出し位置がバッファサイズ超過時はエラーを返却

            // 情報有効時間を取得する
            getResult = getInformationValidTime(readBuf, ref readPos, out routeSignal.InformationValidTime);
            if (!getResult) return false;    // 情報取得エラー発生を返却

            // データ形式区分を取得               bin(2)  Ａ－２ １バイト
            bitPos = 0;
            bitLen = 2;
            beaconDataReader.GetBitFieldData(readBuf, readPos, bitPos, bitLen, out resultValue);
            routeSignal.DataTypeIndicator = (byte)resultValue;
            // 格納交差点数：Ｉを取得            bin(6)  Ａ－６
            bitPos += bitLen;
            bitLen = 6;
            beaconDataReader.GetBitFieldData(readBuf, readPos, bitPos, bitLen, out resultValue);
            routeSignal.NumberOfStorageIntersections = (byte)resultValue;
            readPos += sizeof(byte);
            if (readPos > readBuf.Count()) return false;    // 読み出し位置がバッファサイズ超過時はエラーを返却

            // 交差点路線信号情報（１～Ｉ）を取得
            routeSignal.IntersectionRouteSignalInformationList = new List<StIntersectionRouteSignalInformation>();
            for (int i = 0; i < routeSignal.NumberOfStorageIntersections; i++)
            {
                StIntersectionRouteSignalInformation intersectionRouteSignal;
                getResult = getIntersectionRouteSignalInformation(readBuf, ref readPos, out intersectionRouteSignal);
                if (!getResult) return false;    // 情報取得エラー発生を返却
                routeSignal.IntersectionRouteSignalInformationList.Add(intersectionRouteSignal);
            }

            // データ形式区分が「０」以外の場合のみ、ＵＴＭＳリンク情報を取得する
            if (routeSignal.DataTypeIndicator != 0)
            {
                // ＵＴＭＳリンク情報を取得
                getResult = getUTMSLinkInformation(readBuf, ref readPos, out routeSignal.UTMSLinkInformation);
                if (!getResult) return false;    // 情報取得エラー発生を返却
            }

            // 成功を返却
            return true;
        }

        /// <summary>
        /// 情報有効時間を取得する
        /// </summary>
        /// <param name="readBuf">ビーコンデータ格納バッファ</param>
        /// <param name="readPos">[ref]バッファ読み出し位置</param>
        /// <param name="routeSignal">[out]情報有効時間</param>
        /// <returns>成功/失敗</returns>
        private bool getInformationValidTime(byte[] readBuf, ref int readPos, out StInformationValidTime informationValidTime)
        {
            int bitPos;                 // 読み出しデータのビット位置
            int bitLen;                 // 読み出しデータのビット幅
            ulong resultValue;          // 取得データ格納変数

            // 情報有効時間を生成
            informationValidTime = new StInformationValidTime();

            // 情報有効時間１を取得               bin(16) Ｓ－16 ２バイト
            bitPos = 0;
            bitLen = 16;
            beaconDataReader.GetBitFieldData(readBuf, readPos, bitPos, bitLen, out resultValue);
            informationValidTime.InformationValidTime1 = (short)resultValue;
            readPos += sizeof(short);
            if (readPos > readBuf.Count()) return false;    // 読み出し位置がバッファサイズ超過時はエラーを返却

            // 情報有効時間２を取得               bin(16) Ｓ－16 ２バイト
            bitPos = 0;
            bitLen = 16;
            beaconDataReader.GetBitFieldData(readBuf, readPos, bitPos, bitLen, out resultValue);
            informationValidTime.InformationValidTime2 = (short)resultValue;
            readPos += sizeof(short);
            if (readPos > readBuf.Count()) return false;    // 読み出し位置がバッファサイズ超過時はエラーを返却

            // 成功を返却
            return true;
        }

        /// <summary>
        /// 交差点路線信号情報を取得する
        /// </summary>
        /// <param name="readBuf">ビーコンデータ格納バッファ</param>
        /// <param name="readPos">[ref]バッファ読み出し位置</param>
        /// <param name="intersectionRouteSignal">[out]交差点路線信号情報</param>
        /// <returns>成功/失敗</returns>
        public bool getIntersectionRouteSignalInformation(byte[] readBuf, ref int readPos, out StIntersectionRouteSignalInformation intersectionRouteSignal)
        {
            bool getResult = false;     // データ取得結果

            int bitPos;                 // 読み出しデータのビット位置
            int bitLen;                 // 読み出しデータのビット幅
            ulong resultValue;          // 取得データ格納変数

            // 路線信号情報を生成
            intersectionRouteSignal = new StIntersectionRouteSignalInformation();

            // 交差点位置情報を取得
            getResult = getIntersectionLocationInformationn(readBuf, ref readPos, out intersectionRouteSignal.IntersectionLocationInformation);
            if (!getResult) return false;    // 情報取得エラー発生を返却

            // 推奨速度情報を取得
            getResult = getRecommendedSpeedInformation(readBuf, ref readPos, out intersectionRouteSignal.RecommendedSpeedInformation);
            if (!getResult) return false;    // 情報取得エラー発生を返却

            // 信号制御補足情報を取得      bin(8)  Ａ－８ １バイト
            bitPos = 0;
            bitLen = 8;
            beaconDataReader.GetBitFieldData(readBuf, readPos, bitPos, bitLen, out resultValue);
            intersectionRouteSignal.SignalControlSupplementInformation = (byte)resultValue;
            // 信号制御補足情報(bit0:オフセット乗り換えタイミング)を取得
            bitPos = 7;
            bitLen = 1;
            beaconDataReader.GetBitFieldData(readBuf, readPos, bitPos, bitLen, out resultValue);
            intersectionRouteSignal.SCSI_OffsetTransferTiming = (byte)resultValue;
            // 信号制御補足情報(bit1:スプリット制御実施状況)を取得
            bitPos = 6;
            bitLen = 1;
            beaconDataReader.GetBitFieldData(readBuf, readPos, bitPos, bitLen, out resultValue);
            intersectionRouteSignal.SCSI_SplitControlImplementationStatus = (byte)resultValue;
            // 信号制御補足情報(Bit2-7:予備)を取得
            bitPos = 0;
            bitLen = 6;
            beaconDataReader.GetBitFieldData(readBuf, readPos, bitPos, bitLen, out resultValue);
            intersectionRouteSignal.SCSI_Reserved = (byte)resultValue;
            readPos += sizeof(byte);
            if (readPos > readBuf.Count()) return false;    // 読み出し位置がバッファサイズ超過時はエラーを返却

            // 交差点識別フラグを取得      bin(3)  Ａ－３ ２バイト
            bitPos = 0;
            bitLen = 3;
            beaconDataReader.GetBitFieldData(readBuf, readPos, bitPos, bitLen, out resultValue);
            intersectionRouteSignal.IntersectionIdentificationFlag = (ushort)resultValue;
            // 交差点識別フラグ(Bit15:路線信号情報提供対象)を取得
            bitPos = 0;
            bitLen = 1;
            beaconDataReader.GetBitFieldData(readBuf, readPos, bitPos, bitLen, out resultValue);
            intersectionRouteSignal.IIF_ProvidedRouteSignalInformation = (byte)resultValue;
            // 交差点識別フラグ(Bit14:提供状態)を取得
            bitPos = 1;
            bitLen = 1;
            beaconDataReader.GetBitFieldData(readBuf, readPos, bitPos, bitLen, out resultValue);
            intersectionRouteSignal.IIF_ProvidedStatus = (byte)resultValue;
            // 交差点識別フラグ(Bit13:予備)を取得
            bitPos = 2;
            bitLen = 1;
            beaconDataReader.GetBitFieldData(readBuf, readPos, bitPos, bitLen, out resultValue);
            intersectionRouteSignal.IIF_Reserved = (byte)resultValue;

            // 感応許可状態を取得          bin(13) Ａ－13
            bitPos = 3;
            bitLen = 13;
            beaconDataReader.GetBitFieldData(readBuf, readPos, bitPos, bitLen, out resultValue);
            intersectionRouteSignal.SensitivityEnabledState = (ushort)resultValue;
            // 感応許可状態(Bit12:FAST感応)を取得
            bitPos = 3;
            bitLen = 1;
            beaconDataReader.GetBitFieldData(readBuf, readPos, bitPos, bitLen, out resultValue);
            intersectionRouteSignal.SES_ResponsiveFAST = (byte)resultValue;
            // 感応許可状態(Bit11:歩行者感応)を取得
            bitPos = 4;
            bitLen = 1;
            beaconDataReader.GetBitFieldData(readBuf, readPos, bitPos, bitLen, out resultValue);
            intersectionRouteSignal.SES_ResponsivePedestrian = (byte)resultValue;
            // 感応許可状態(Bit10:リコール制御)を取得
            bitPos = 5;
            bitLen = 1;
            beaconDataReader.GetBitFieldData(readBuf, readPos, bitPos, bitLen, out resultValue);
            intersectionRouteSignal.SES_RecallControl = (byte)resultValue;
            // 感応許可状態(Bit9:ジレンマ感応)を取得
            bitPos = 6;
            bitLen = 1;
            beaconDataReader.GetBitFieldData(readBuf, readPos, bitPos, bitLen, out resultValue);
            intersectionRouteSignal.SES_ResponsiveDilemma = (byte)resultValue;
            // 感応許可状態(Bit8:高速感応)を取得
            bitPos = 7;
            bitLen = 1;
            beaconDataReader.GetBitFieldData(readBuf, readPos, bitPos, bitLen, out resultValue);
            intersectionRouteSignal.SES_ResponsiveHighway = (byte)resultValue;
            // 感応許可状態(Bit7:バス感応)を取得
            bitPos = 8;
            bitLen = 1;
            beaconDataReader.GetBitFieldData(readBuf, readPos, bitPos, bitLen, out resultValue);
            intersectionRouteSignal.SES_ResponsiveBus = (byte)resultValue;
            // 感応許可状態(Bit6:高齢者等感応)を取得
            bitPos = 9;
            bitLen = 1;
            beaconDataReader.GetBitFieldData(readBuf, readPos, bitPos, bitLen, out resultValue);
            intersectionRouteSignal.SES_ResponsiveSeniorCitizens = (byte)resultValue;
            // 感応許可状態(Bit5:ギャップ感応)を取得
            bitPos = 10;
            bitLen = 1;
            beaconDataReader.GetBitFieldData(readBuf, readPos, bitPos, bitLen, out resultValue);
            intersectionRouteSignal.SES_ResponsiveGap = (byte)resultValue;
            // 感応許可状態(Bit4:標準仕様外の感応制御)を取得
            bitPos = 11;
            bitLen = 1;
            beaconDataReader.GetBitFieldData(readBuf, readPos, bitPos, bitLen, out resultValue);
            intersectionRouteSignal.SES_SensitiveControlOutsideStandardSpec = (byte)resultValue;
            // 感応許可状態(Bit3-0:予備)を取得
            bitPos = 12;
            bitLen = 4;
            beaconDataReader.GetBitFieldData(readBuf, readPos, bitPos, bitLen, out resultValue);
            intersectionRouteSignal.SES_Reserved = (byte)resultValue;

            readPos += sizeof(ushort);  //交差点識別フラグと感応許可状態分の2バイトを進める
            if (readPos > readBuf.Count()) return false;    // 読み出し位置がバッファサイズ超過時はエラーを返却

            // サイクル情報（１）開始までの経過時間を取得     bin(16) Ｓ－16 ２バイト
            bitPos = 0;
            bitLen = 16;
            beaconDataReader.GetBitFieldData(readBuf, readPos, bitPos, bitLen, out resultValue);
            intersectionRouteSignal.ElapsedTimeToStartCycleInformation = (short)resultValue;
            readPos += sizeof(short);
            if (readPos > readBuf.Count()) return false;    // 読み出し位置がバッファサイズ超過時はエラーを返却

            // サイクル情報数：Ｊを取得      bin(8)  Ａ－８ １バイト
            bitPos = 0;
            bitLen = 8;
            beaconDataReader.GetBitFieldData(readBuf, readPos, bitPos, bitLen, out resultValue);
            intersectionRouteSignal.NumberOfCycleInformation = (byte)resultValue;
            readPos += sizeof(byte);
            if (readPos > readBuf.Count()) return false;    // 読み出し位置がバッファサイズ超過時はエラーを返却

            // サイクル情報（１～Ｊ）を取得
            intersectionRouteSignal.CycleInformationList = new List<StCycleInformation>();
            for (int i = 0; i < intersectionRouteSignal.NumberOfCycleInformation; i++)
            {
                StCycleInformation cycleInformation;
                getResult = getCycleInformation(readBuf, ref readPos, out cycleInformation);
                if (!getResult) return false;    // 情報取得エラー発生を返却
                intersectionRouteSignal.CycleInformationList.Add(cycleInformation);
            }

            // 成功を返却
            return true;
        }

        /// <summary>
        /// 交差点位置情報を取得する
        /// </summary>
        /// <param name="readBuf">ビーコンデータ格納バッファ</param>
        /// <param name="readPos">[ref]バッファ読み出し位置</param>
        /// <param name="intersectionLocation">[out]交差点位置情報</param>
        /// <returns>成功/失敗</returns>
        public bool getIntersectionLocationInformationn(byte[] readBuf, ref int readPos, out StIntersectionLocationInformation intersectionLocation)
        {
            bool getResult = false;     // データ取得結果

            int bitPos;                 // 読み出しデータのビット位置
            int bitLen;                 // 読み出しデータのビット幅
            ulong resultValue;          // 取得データ格納変数

            // 路線信号情報を生成
            intersectionLocation = new StIntersectionLocationInformation();

            // 交差点参照座標を取得
            getResult = getIntersectionReferenceCoordinates(readBuf, ref readPos, out intersectionLocation.IntersectionReferenceCoordinates);
            if (!getResult) return false;    // 情報取得エラー発生を返却

            // 光ビーコンから当該停止線までの概算道程距離を取得     bin(16) Ａ－16 ２バイト
            bitPos = 0;
            bitLen = 16;
            beaconDataReader.GetBitFieldData(readBuf, readPos, bitPos, bitLen, out resultValue);
            intersectionLocation.ApproximateDistanceToStopLine = (ushort)resultValue;
            readPos += sizeof(ushort);
            if (readPos > readBuf.Count()) return false;    // 読み出し位置がバッファサイズ超過時はエラーを返却

            // 上流交差点参照座標を取得
            getResult = getIntersectionReferenceCoordinates(readBuf, ref readPos, out intersectionLocation.UpstreamIntersectionReferenceCoordinates);
            if (!getResult) return false;    // 情報取得エラー発生を返却

            // 光ビーコンから当該停止線までの概算道程距離を取得     bin(16) Ａ－16 ２バイト
            bitPos = 0;
            bitLen = 16;
            beaconDataReader.GetBitFieldData(readBuf, readPos, bitPos, bitLen, out resultValue);
            intersectionLocation.UpstreamApproximateDistanceToStopLine = (ushort)resultValue;
            readPos += sizeof(ushort);
            if (readPos > readBuf.Count()) return false;    // 読み出し位置がバッファサイズ超過時はエラーを返却

            // 成功を返却
            return true;
        }

        /// <summary>
        /// 交差点参照座標情報を取得する
        /// </summary>
        /// <param name="readBuf">ビーコンデータ格納バッファ</param>
        /// <param name="readPos">[ref]バッファ読み出し位置</param>
        /// <param name="intersectionReferenceCoordinates">[out]交差点参照座標情報</param>
        /// <returns>成功/失敗</returns>
        public bool getIntersectionReferenceCoordinates(byte[] readBuf, ref int readPos, out StIntersectionReferenceCoordinates intersectionReferenceCoordinates)
        {
            int bitPos;                 // 読み出しデータのビット位置
            int bitLen;                 // 読み出しデータのビット幅
            ulong resultValue;          // 取得データ格納変数

            // 路線信号情報を生成
            intersectionReferenceCoordinates = new StIntersectionReferenceCoordinates();

            // ２次メッシュ座標を取得                bin(8)*2  Ｊ－３ ２バイト
            bitPos = 0;
            bitLen = 16;
            beaconDataReader.GetBitFieldData(readBuf, readPos, bitPos, bitLen, out resultValue);
            intersectionReferenceCoordinates.SecondaryMeshCoordinates = (ushort)resultValue;
            // ２次メッシュ座標(緯度)を取得
            bitPos = 0;
            bitLen = 8;
            beaconDataReader.GetBitFieldData(readBuf, readPos, bitPos, bitLen, out resultValue);
            intersectionReferenceCoordinates.SecondaryMeshCoordinatesLat = (byte)resultValue;
            // ２次メッシュ座標(経度)を取得
            bitPos = 8;
            bitLen = 8;
            beaconDataReader.GetBitFieldData(readBuf, readPos, bitPos, bitLen, out resultValue);
            intersectionReferenceCoordinates.SecondaryMeshCoordinatesLon = (byte)resultValue;
            readPos += sizeof(ushort);
            if (readPos > readBuf.Count()) return false;    // 読み出し位置がバッファサイズ超過時はエラーを返却

            // 正規化座標を取得                bin(16)*2 Ｊ－２ ４バイト
            bitPos = 0;
            bitLen = 16;
            beaconDataReader.GetBitFieldData(readBuf, readPos, bitPos, bitLen, out resultValue);
            intersectionReferenceCoordinates.NormalizedCoordinatesX = (ushort)resultValue;
            readPos += sizeof(ushort);
            beaconDataReader.GetBitFieldData(readBuf, readPos, bitPos, bitLen, out resultValue);
            intersectionReferenceCoordinates.NormalizedCoordinatesY = (ushort)resultValue;
            readPos += sizeof(ushort);
            if (readPos > readBuf.Count()) return false;    // 読み出し位置がバッファサイズ超過時はエラーを返却

            // 高度を取得                bin(16)   Ｓ－16 ２バイト
            bitPos = 0;
            bitLen = 16;
            beaconDataReader.GetBitFieldData(readBuf, readPos, bitPos, bitLen, out resultValue);
            intersectionReferenceCoordinates.HeightCondition = (short)resultValue;
            readPos += sizeof(short);
            if (readPos > readBuf.Count()) return false;    // 読み出し位置がバッファサイズ超過時はエラーを返却

            // ２次メッシュ座標(経度:世界測地系)と２次メッシュ座標(経度:世界測地系)を取得
            convertMeshCoordinates2WGS(
                intersectionReferenceCoordinates.SecondaryMeshCoordinatesLat,
                intersectionReferenceCoordinates.SecondaryMeshCoordinatesLon,
                intersectionReferenceCoordinates.NormalizedCoordinatesX,
                intersectionReferenceCoordinates.NormalizedCoordinatesY,
                out intersectionReferenceCoordinates.SecondaryMeshCoordinatesWGSLat,
                out intersectionReferenceCoordinates.SecondaryMeshCoordinatesWGSLon);

            // 成功を返却
            return true;
        }

        /// <summary>
        /// メッシュ座標から世界測地系座標に変換する
        /// </summary>
        /// <param name="meshX">２次メッシュ座標X (Secondary mesh coordinates)</param>
        /// <param name="meshY">２次メッシュ座標Y</param>
        /// <param name="normalX">正規化座標X (Normalized coordinates)</param>
        /// <param name="normalY">正規化座標Y</param>
        /// <param name="latWorld">[out]世界測地系緯度（World Geodetic System)</param>
        /// <param name="lonWorld">[out]世界測地系経度</param>
        void convertMeshCoordinates2WGS(byte meshX, byte meshY, ushort normalX, ushort normalY, out double latWorld, out double lonWorld)
        {
            // 日本測地系の経度
            double longitude = 100.0 + ((meshX >> 3) + 22.0) + ((meshX & 0x07) / 8.0);
            longitude = longitude + (normalX / 80000.0);

            // 日本測地系の緯度
            double latitude = ((meshY >> 3) + 37.0) + ((meshY & 0x07) / 8.0);
            latitude = (latitude + (normalY / 80000.0)) / 1.5;

            // 日本測地系から世界測地系に変換する
            convertGeodeticSystem2World(latitude, longitude, out latWorld, out lonWorld);
        }

        /// <summary>
        /// 日本測地系から世界測地系に変換する
        /// </summary>
        /// <param name="lat">日本測地系緯度（Tokyo Datum)</param>
        /// <param name="lon">日本測地系緯度</param>
        /// <param name="latWorld">[out]世界測地系緯度（World Geodetic System)</param>
        /// <param name="lonWorld">[out]世界測地系経度</param>
        void convertGeodeticSystem2World(double lat, double lon, out double latWorld, out double lonWorld)
        {
            // 世界測地系変換(緯度:latitude)
            latWorld = lat - (0.00010695 * lat) + (0.000017464 * lon) + 0.0046017;
            // 世界測地系変換(経度:longitude)
            lonWorld = lon - (0.000046038 * lat) - (0.000083043 * lon) + 0.01004;
        }

        /// <summary>
        /// 世界測地系から日本測地系に変換する
        /// </summary>
        /// <param name="lat">世界測地系緯度（World Geodetic System)</param>
        /// <param name="lon">世界測地系経度</param>
        /// <param name="latJapan">[out]日本測地系緯度（Tokyo Datum)</param>
        /// <param name="lonJapan">[out]日本測地系緯度</param>
        void convertGeodeticSystem2Japan(double lat, double lon, out double latJapan, out double lonJapan)
        {
            // 日本測地系変換(緯度:latitude)
            latJapan = lat + (0.000106961 * lat) - (0.000017467 * lon) - 0.004602017;
            // 日本測地系変換(経度:longitude)
            lonJapan = lon + (0.000046047 * lat) + (0.000083049 * lon) - 0.010041046;
        }

        /// <summary>
        /// 推奨速度情報を取得する
        /// </summary>
        /// <param name="readBuf">ビーコンデータ格納バッファ</param>
        /// <param name="readPos">[ref]バッファ読み出し位置</param>
        /// <param name="recommendedSpeed">[out]推奨速度情報</param>
        /// <returns>成功/失敗</returns>
        public bool getRecommendedSpeedInformation(byte[] readBuf, ref int readPos, out StRecommendedSpeedInformation recommendedSpeed)
        {
            int bitPos;                 // 読み出しデータのビット位置
            int bitLen;                 // 読み出しデータのビット幅
            ulong resultValue;          // 取得データ格納変数

            // 路線信号情報を生成
            recommendedSpeed = new StRecommendedSpeedInformation();

            //  規制速度変動有無を取得             bin(1) Ａ－１ １バイト
            bitPos = 0;
            bitLen = 1;
            beaconDataReader.GetBitFieldData(readBuf, readPos, bitPos, bitLen, out resultValue);
            recommendedSpeed.PresenceOrAbsenceOfRegulatedSpeedFluctuation = (byte)resultValue;
            // 区間の最小規制速度を取得            bin(7) Ａ－７
            bitPos += bitLen;
            bitLen = 7;
            beaconDataReader.GetBitFieldData(readBuf, readPos, bitPos, bitLen, out resultValue);
            recommendedSpeed.MinimumSpeedLimitOfSection = (byte)resultValue;
            readPos += sizeof(byte);
            if (readPos > readBuf.Count()) return false;    // 読み出し位置がバッファサイズ超過時はエラーを返却

            // 成功を返却
            return true;
        }

        /// <summary>
        /// サイクル情報を取得する
        /// </summary>
        /// <param name="readBuf">ビーコンデータ格納バッファ</param>
        /// <param name="readPos">[ref]バッファ読み出し位置</param>
        /// <param name="cycleInformation">[out]サイクル情報</param>
        /// <returns>成功/失敗</returns>
        public bool getCycleInformation(byte[] readBuf, ref int readPos, out StCycleInformation cycleInformation)
        {
            bool getResult = false;     // データ取得結果

            int bitPos;                 // 読み出しデータのビット位置
            int bitLen;                 // 読み出しデータのビット幅
            ulong resultValue;          // 取得データ格納変数

            // 路線信号情報を生成
            cycleInformation = new StCycleInformation();

            // サイクル情報ヘッダを取得
            getResult = getCycleInformationHeader(readBuf, ref readPos, out cycleInformation.CycleInformationHeader);
            if (!getResult) return false;    // 情報取得エラー発生を返却

            //  サイクル長（最小）を取得    bin(12) Ａ－12 ３バイト
            bitPos = 0;
            bitLen = 12;
            beaconDataReader.GetBitFieldData(readBuf, readPos, bitPos, bitLen, out resultValue);
            cycleInformation.CycleLengthMinimum = (ushort)resultValue;
            // サイクル長（最大）           bin(12) Ａ－12
            bitPos += bitLen;
            bitLen = 12;
            beaconDataReader.GetBitFieldData(readBuf, readPos, bitPos, bitLen, out resultValue);
            cycleInformation.CycleLengthMaximum = (ushort)resultValue;
            readPos += 3;
            if (readPos > readBuf.Count()) return false;    // 読み出し位置がバッファサイズ超過時はエラーを返却

            //  青開始時間（最小）を取得    bin(12) Ａ－12 ３バイト
            bitPos = 0;
            bitLen = 12;
            beaconDataReader.GetBitFieldData(readBuf, readPos, bitPos, bitLen, out resultValue);
            cycleInformation.BlueStartTimeMinimum = (ushort)resultValue;
            // 青開始時間（最大）           bin(12) Ａ－12
            bitPos += bitLen;
            bitLen = 12;
            beaconDataReader.GetBitFieldData(readBuf, readPos, bitPos, bitLen, out resultValue);
            cycleInformation.BlueStartTimeMaximum = (ushort)resultValue;
            readPos += 3;
            if (readPos > readBuf.Count()) return false;    // 読み出し位置がバッファサイズ超過時はエラーを返却

            //  青終了時間（最小）を取得    bin(12) Ａ－12 ３バイト
            bitPos = 0;
            bitLen = 12;
            beaconDataReader.GetBitFieldData(readBuf, readPos, bitPos, bitLen, out resultValue);
            cycleInformation.BlueEndTimeMinimum = (ushort)resultValue;
            // 青終了時間（最大）           bin(12) Ａ－12
            bitPos += bitLen;
            bitLen = 12;
            beaconDataReader.GetBitFieldData(readBuf, readPos, bitPos, bitLen, out resultValue);
            cycleInformation.BlueEndTimeMaximum = (ushort)resultValue;
            readPos += 3;
            if (readPos > readBuf.Count()) return false;    // 読み出し位置がバッファサイズ超過時はエラーを返却

            // 指令サイクル長を取得              bin(8)  Ａ－８ １バイト
            bitPos = 0;
            bitLen = 8;
            beaconDataReader.GetBitFieldData(readBuf, readPos, bitPos, bitLen, out resultValue);
            cycleInformation.CommandCycleLength = (byte)resultValue;
            readPos += sizeof(byte);
            if (readPos > readBuf.Count()) return false;    // 読み出し位置がバッファサイズ超過時はエラーを返却

            // 黄時間を取得               bin(4)  Ａ－４ ２バイト
            bitPos = 0;
            //bitLen = 1;
            bitLen = 4;
            beaconDataReader.GetBitFieldData(readBuf, readPos, bitPos, bitLen, out resultValue);
            cycleInformation.YellowTime = (ushort)resultValue;
            // 赤開始時間（最大）を取得   bin(12) Ａ－12
            bitPos += bitLen;
            //bitLen = 7;
            bitLen = 12;
            beaconDataReader.GetBitFieldData(readBuf, readPos, bitPos, bitLen, out resultValue);
            cycleInformation.RedStartTimeMaximum = (ushort)resultValue;
            readPos += sizeof(ushort);
            if (readPos > readBuf.Count()) return false;    // 読み出し位置がバッファサイズ超過時はエラーを返却

            // 成功を返却
            return true;
        }

        /// <summary>
        /// サイクル情報ヘッダを取得する
        /// </summary>
        /// <param name="readBuf">ビーコンデータ格納バッファ</param>
        /// <param name="readPos">[ref]バッファ読み出し位置</param>
        /// <param name="cycleInformationHeader">[out]サイクル情報ヘッダ</param>
        /// <returns>成功/失敗</returns>
        public bool getCycleInformationHeader(byte[] readBuf, ref int readPos, out StCycleInformationHeader cycleInformationHeader)
        {
            int bitPos;                 // 読み出しデータのビット位置
            int bitLen;                 // 読み出しデータのビット幅
            ulong resultValue;          // 取得データ格納変数

            // 路線信号情報を生成
            cycleInformationHeader = new StCycleInformationHeader();

            //  最終サイクル情報の利用区分を取得    bin(2) Ａ－２ １バイト
            bitPos = 0;
            bitLen = 2;
            beaconDataReader.GetBitFieldData(readBuf, readPos, bitPos, bitLen, out resultValue);
            cycleInformationHeader.UseClassification = (byte)resultValue;
            // 適用サイクル数を取得                 bin(6) Ａ－６
            bitPos += bitLen;
            bitLen = 6;
            beaconDataReader.GetBitFieldData(readBuf, readPos, bitPos, bitLen, out resultValue);
            cycleInformationHeader.NumberOfAppliedCycles = (byte)resultValue;
            readPos += sizeof(byte);
            if (readPos > readBuf.Count()) return false;    // 読み出し位置がバッファサイズ超過時はエラーを返却

            // 成功を返却
            return true;
        }

        /// <summary>
        /// ＵＴＭＳリンク情報を取得する
        /// </summary>
        /// <param name="readBuf">ビーコンデータ格納バッファ</param>
        /// <param name="readPos">[ref]バッファ読み出し位置</param>
        /// <param name="UTMSLinkInformation">[out]ＵＴＭＳリンク情報</param>
        /// <returns>成功/失敗</returns>
        public bool getUTMSLinkInformation(byte[] readBuf, ref int readPos, out StUTMSLinkInformation UTMSLinkInformation)
        {
            bool getResult = false;     // データ取得結果

            int bitPos;                 // 読み出しデータのビット位置
            int bitLen;                 // 読み出しデータのビット幅
            ulong resultValue;          // 取得データ格納変数

            // ＵＴＭＳリンク情報を生成
            UTMSLinkInformation = new StUTMSLinkInformation();

            // 世代数：Ｋを取得    bin(8) Ａ－８ １バイト
            bitPos = 0;
            bitLen = 8;
            beaconDataReader.GetBitFieldData(readBuf, readPos, bitPos, bitLen, out resultValue);
            UTMSLinkInformation.NumberOfGenerations = (byte)resultValue;
            readPos += sizeof(byte);
            if (readPos > readBuf.Count()) return false;    // 読み出し位置がバッファサイズ超過時はエラーを返却

            // 第１世代（最新世代）～第Ｋ世代を取得
            UTMSLinkInformation.GenerationList = new List<StGeneration>();
            for (int i = 0; i < UTMSLinkInformation.NumberOfGenerations; i++)
            {
                StGeneration generation;
                getResult = getGeneration(readBuf, ref readPos, out generation);
                if (!getResult) return false;    // 情報取得エラー発生を返却
                UTMSLinkInformation.GenerationList.Add(generation);
            }

            // 成功を返却
            return true;
        }

        /// <summary>
        /// 世代を取得する
        /// </summary>
        /// <param name="readBuf">ビーコンデータ格納バッファ</param>
        /// <param name="readPos">[ref]バッファ読み出し位置</param>
        /// <param name="generation">[out]世代情報</param>
        /// <returns>成功/失敗</returns>
        public bool getGeneration(byte[] readBuf, ref int readPos, out StGeneration generation)
        {
            bool getResult = false;     // データ取得結果

            int bitPos;                 // 読み出しデータのビット位置
            int bitLen;                 // 読み出しデータのビット幅
            ulong resultValue;          // 取得データ格納変数

            // ＵＴＭＳリンク情報を生成
            generation = new StGeneration();

            // 格納リンク数：Ｌを取得    bin(8) Ａ－８ １バイト
            bitPos = 0;
            bitLen = 8;
            beaconDataReader.GetBitFieldData(readBuf, readPos, bitPos, bitLen, out resultValue);
            generation.NumberOfStoredLinks = (byte)resultValue;
            readPos += sizeof(byte);
            if (readPos > readBuf.Count()) return false;    // 読み出し位置がバッファサイズ超過時はエラーを返却

            // ＵＴＭＳリンク（１～Ｌ）を取得
            generation.UTMSLinkList = new List<StUTMSLink>();
            for (int i = 0; i < generation.NumberOfStoredLinks; i++)
            {
                StUTMSLink UTMSLink;
                getResult = getUTMSLink(readBuf, ref readPos, out UTMSLink);
                if (!getResult) return false;    // 情報取得エラー発生を返却
                generation.UTMSLinkList.Add(UTMSLink);
            }

            // 成功を返却
            return true;
        }

        /// <summary>
        /// ＵＴＭＳリンクを取得する
        /// </summary>
        /// <param name="readBuf">ビーコンデータ格納バッファ</param>
        /// <param name="readPos">[ref]バッファ読み出し位置</param>
        /// <param name="UTMSLink">[out]ＵＴＭＳリンク情報</param>
        /// <returns>成功/失敗</returns>
        public bool getUTMSLink(byte[] readBuf, ref int readPos, out StUTMSLink UTMSLink)
        {
            int bitPos;                 // 読み出しデータのビット位置
            int bitLen;                 // 読み出しデータのビット幅
            ulong resultValue;          // 取得データ格納変数

            // ＵＴＭＳリンク情報を生成
            UTMSLink = new StUTMSLink();

            // ２次メッシュ座標を取得       bin(16) Ａ－16 ２バイト
            bitPos = 0;
            bitLen = 16;
            beaconDataReader.GetBitFieldData(readBuf, readPos, bitPos, bitLen, out resultValue);
            UTMSLink.SecondaryMeshCoordinates = (ushort)resultValue;
            // ２次メッシュ座標(緯度)を取得
            bitPos = 0;
            bitLen = 8;
            beaconDataReader.GetBitFieldData(readBuf, readPos, bitPos, bitLen, out resultValue);
            UTMSLink.SecondaryMeshCoordinatesLat = (byte)resultValue;
            // ２次メッシュ座標(経度)を取得
            bitPos = 8;
            bitLen = 8;
            beaconDataReader.GetBitFieldData(readBuf, readPos, bitPos, bitLen, out resultValue);
            UTMSLink.SecondaryMeshCoordinatesLon = (byte)resultValue;
            readPos += sizeof(ushort);
            if (readPos > readBuf.Count()) return false;    // 読み出し位置がバッファサイズ超過時はエラーを返却

            // 予約領域を取得               bin(2)  Ａ－２ ２バイト
            bitPos = 0;
            bitLen = 2;
            beaconDataReader.GetBitFieldData(readBuf, readPos, bitPos, bitLen, out resultValue);
            UTMSLink.Reserved = (byte)resultValue;
            // 道路種別を取得               bin(2)  Ｉ－４
            bitPos += bitLen;
            bitLen = 2;
            beaconDataReader.GetBitFieldData(readBuf, readPos, bitPos, bitLen, out resultValue);
            UTMSLink.RoadClassification = (byte)resultValue;
            // リンク番号を取得             bin(12) Ａ－12
            bitPos += bitLen;
            bitLen = 12;
            beaconDataReader.GetBitFieldData(readBuf, readPos, bitPos, bitLen, out resultValue);
            UTMSLink.LinkNumber = (ushort)resultValue;
            readPos += sizeof(ushort);
            if (readPos > readBuf.Count()) return false;    // 読み出し位置がバッファサイズ超過時はエラーを返却

            // 成功を返却
            return true;
        }

    }
}
