﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Npgsql;
using System.IO;
using System.Data;
using System.Globalization;
using System.Xml.Serialization;

namespace BeaconDataEvaluator
{
    /// <summary>
    /// データベース通信クラス
    /// </summary>
    /// <remarks>
    /// postgreSQLのDBにログインし、データベースbeacon_data_evaluation_dbに接続する。
    /// </remarks>
    public class DatabaseAccessor
    {
        /// <summary>
        /// 版定義
        /// </summary>
        public enum EvaluationVersion
        {
            Version1 = 1,   ///< 版1
            Version2,       ///< 版2
        }

        /// <summary>
        /// 評価パターン定義
        /// </summary>
        public enum EvaluationPattern
        {
            NotCheck = 0,               ///< 評価しない
            NormalCheck,                ///< 通常評価 (固定値チェック、範囲チェックなど)
            MultiItemReferenceCheck,    ///< 多項目参照評価 (複数値の比較チェックなど)
            CaseDivisionCheck,          ///< ケース分け有りの評価
        }

        /// <summary>
        /// 評価値型定義
        /// </summary>
        public enum EvaluationValueType
        {
            Integer = 0,        ///< 整数型
            Decimal,            ///< 小数型
        }

        /// <summary>
        /// 評価ステータス定義
        /// </summary>
        public enum EvaluationStatus
        {
            EvaluateNormal_NoneNG = 0001,                        ///< 【評価(正常)】NGなし
            EvaluateNormal_ExistNG = 0002,                       ///< 【評価(正常)】NGあり
            EvaluateError_LengthError = 1001,                    ///< 【評価エラー】Lengthエラー
            ExportError_EvaluationResultItemMakeError = 2001,    ///< 【出力系エラー】評価結果CSVファイル作成失敗
            ExportError_CategoryCountResultMakeError = 2002,     ///< 【出力系エラー】カテゴリ別NG件数カウント結果CSVファイル作成失敗
            ExportError_EvaluationResultNgItemMakeError = 2003,  ///< 【出力系エラー】評価結果NG項目CSVファイル作成失敗
            ExportError_OffsetSignalSyncValueMakeError = 2004,   ///< 【出力系エラー】オフセット信号同期CSVファイル作成失敗
            ExportError_LocationInfoMakeError = 2005,            ///< 【出力系エラー】路線別位置情報CSVファイル作成失敗
            ExportError_HtmlMakeError = 2006,                    ///< 【出力系エラー】HTMLファイル作成失敗
            ExportError_HtmlCaptureError = 2007,                 ///< 【出力系エラー】JPEGファイル作成失敗
            ExportError_SummaryMakeError = 2008,                 ///< 【出力系エラー】サマリのサマリ作成失敗
        }

        /// <summary>
        /// DBからの評価結果情報対象定義
        /// </summary>
        public enum CsvEvalResGetDataType
        {
            RouteSignal_Info,            ///< 路線信号情報
            Intersection_Info,           ///< 交差点路線信号情報
            Cycle_Info,                  ///< サイクル情報
            Generation_Info,             ///< 世代情報
            UtmsLink_Info,               ///< UTMSリンク情報
        }

        /// <summary>
        /// 評価仕様構造体
        /// </summary>
        public struct StEvaluationSpecification
        {
            public int Id;                      ///< 評価仕様ID
            public EvaluationVersion Version;   ///< 版
            public string EvaluationItem;       ///< 評価項目
            public string Condition;            ///< 条件
            public EvaluationPattern pattern;   ///< 評価パターン
            public int? Value1;                 ///< 値1 (範囲チェックの最小値)または(単独値(完全一致する値))
            public int? Value2;                 ///< 値2 (範囲チェックの最大値)
            public int? Value3;                 ///< 値3 (その他の値)(※最小値～最大値またはXXX時の、の値XXX)
            public DateTime EntryDatetime;      ///< 登録日時
            public DateTime RenewDatetime;      ///< 更新日時
            public bool LogicalDelete;          ///< 論理削除
        }

        /// <summary>
        /// 交差点情報構造体
        /// </summary>
        public struct StIntersectionInfo
        {
            public short Id;                            ///< 交差点情報ID
            public short IntersectionOrder;             ///< 交差点順序
            public short ControlManagementNum;          ///< 管制管理番号
            public string IntersectionName;             ///< 交差点名称
            public int SecondaryMeshCoordinates;        ///< 2次メッシュ座標
            public short NormalizedCoordinateX;         ///< 正規化座標X
            public short NormalizedCoordinateY;         ///< 正規化座標Y
            public short? SignalInfoProvision;          ///< 信号情報提供有無
            public double LatitudeVics;                 ///< 緯度(VICS)
            public double LongitudeVics;                ///< 経度(VICS)
            public double LatitudeTrueValue;            ///< 緯度(真値)
            public double LongitudeTrueValue;           ///< 経度(真値)
            public short DestinationDistanceTrueValue;  ///< 道程距離(真値)
        }

        /// <summary>
        /// 走行基本情報構造体
        /// </summary>
        public struct StDrivingInfo
        {
            public int DrivingInfoId;           ///< 走行基本情報ID
            public short PrefectureId;          ///< 都道府県ID
            public short RouteNum;              ///< 路線No.
            public DateTime DrivingDatetime;    ///< 走行日時
            public EvaluationVersion Version;   ///< 版
        }

        /// <summary>
        /// 評価実施履歴構造体
        /// </summary>
        public struct StEvaluationHistory
        {
            public int DrivingInfoId;           ///< 走行基本情報ID
            public int EvaluationHistoryId;     ///< 評価実施履歴ID
            public DateTime EvaluationDatetime; ///< 評価日時
            public EvaluationStatus Status;     ///< ステータス
        }

        /// <summary>
        /// 路線信号基本情報構造体
        /// </summary>
        public struct StRouteSignalInfo
        {
            public int DrivingInfoId;               ///< 走行基本情報ID
            public int EvaluationSpecificationId;   ///< 評価仕様ID
            public int IntegerValue;                ///< 整数値
            public bool Judgment;                   ///< 判定
        }

        /// <summary>
        /// 交差点路線信号情報構造体
        /// </summary>
        public struct StIntersectionRouteSignalInfo
        {
            public int DrivingInfoId;                   ///< 走行基本情報ID
            public int IntersectionRouteSignalInfoId;   ///< 交差点路線信号情報ID
            public int EvaluationSpecificationId;       ///< 評価仕様ID
            public short ValueType;                     ///< 値タイプ
            public int IntegerValue;                    ///< 整数値
            public double DoubleValue;                  ///< 浮動小数値
            public bool Judgment;                       ///< 判定
        }

        /// <summary>
        /// 評価結果Csvファイル出力情報構造体
        /// </summary>
        public struct StCsvEvaluatResultInfo
        {
            public int EvalSpecId;                  ///< 評価仕様ID
            public int BelongingId_1;               ///< 所属ID_1
            public int BelongingId_2;               ///< 所属ID_2
            public string Item;                     ///< 項目
            public string Specification;            ///< 仕様
            public string Category;                 ///< チェック分類
            public string SpecificationSource;      ///< 仕様提供元
            public Boolean? Judge;                  ///< 判定
            public int? Value;                      ///< 値
            public long ItemId;                     ///< 項目ID
        }

        /// <summary>
        /// 評価実施履歴Csvファイル出力情報構造体
        /// </summary>
        public struct StCsvEvaluationImplementationHistoryInfo
        {
            public string PrefectureName;                             /// 都道府県名
            public short RouteNum;                                    /// 路線番号
            public DateTime DrivingDatetime;                          /// 走行時刻
            public EvaluationVersion SpecificationVersion;            /// 版
            public DateTime EvaluationDatetime;                       /// 評価時刻  
            public EvaluationStatus Status;                           /// ステータス
        }

        /// <summary>
        /// チェック分類定義
        /// </summary>
        public enum EvaluatCheckType
        {
            AreaCheck = 1,       ///< 範囲チェック
            ValueCheck,          ///< 値チェック
            ConsistencyCheck,    ///< 整合性チェック
            BitCheckNgCnt,       ///< BITチェック
        }

        /// <summary>
        /// ALLテーブルデータ格納数チェック構造体
        /// </summary>
        public struct StAllTableCount
        {
            public int data1;
            public int data2;
            public int data3;
            public int data4;
            public int data5;
            public int data6;
            public int data7;
            public int data8;
            public int data9;
            public int data10;
            public int data11;
            public int data12;
            public int data13;
            public int data14;
            public int data15;
            public int data16;
            public int data17;
            public int data18;
            public int data19;
        }


        private XMLSetting xmlSetting;          ///< ビーコンデータ評価ツール設定情報

        private string connectionString;        ///< データベース接続用文字列

        /// コンストラクタ
        public DatabaseAccessor()
        {
            // ビーコンデータ評価ツール設定情報読み込み
            try
            {
                using (var fs = new FileStream(@"XMLSetting.xml", FileMode.Open, FileAccess.Read))
                {
                    var serializer = new XmlSerializer(typeof(XMLSetting));
                    xmlSetting = (XMLSetting)serializer.Deserialize(fs);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

            // データベース接続用文字列を生成
            connectionString = xmlSetting.databaseConnection.ServerName;
            connectionString += xmlSetting.databaseConnection.PortName;
            connectionString += xmlSetting.databaseConnection.UserId;
            connectionString += xmlSetting.databaseConnection.Password;
            connectionString += xmlSetting.databaseConnection.DatabaseName;
        }

        /// デストラクタ
        ~DatabaseAccessor()
        {
        }

        #region DataSet executeSelect(string strSql)
        /// <summary>
        /// 引数で指定されたSQLでSELECTを実行します。
        /// </summary>
        /// <param name="command">実行するSQLを指定します。</param>
        /// <returns>SQL実行結果を返します。</returns>
        private DataSet executeSelect(NpgsqlCommand command)
        {
            // 接続準備
            using (var connection = new NpgsqlConnection(connectionString))
            {
                // DataSetを生成
                using (var dataSet = new DataSet())
                {
                    dataSet.Locale = CultureInfo.InvariantCulture;
                    try
                    {
                        // データベースの接続開始
                        connection.Open();

                        // SELECTを実行
                        command.Connection = connection;
                        using (var dataAdapter = new NpgsqlDataAdapter(command))
                        {
                            try
                            {
                                dataAdapter.Fill(dataSet);
                            }
                            catch (System.InvalidOperationException e)
                            {
                                Console.WriteLine(e.ToString());
                            }
                            catch (PostgresException e)
                            {
                                Console.WriteLine(e.ToString());
                            }
                            catch (OverflowException e)
                            {
                                Console.WriteLine(e.ToString());
                            }
                        }
                    }
                    catch (System.Net.Sockets.SocketException e)
                    {
                        Console.WriteLine(e.Message);
                        //DB接続失敗時、処理中止のため、親にも通知する
                        throw;
                    }
                    catch (ArgumentException e)
                    {
                        Console.WriteLine(e.Message);
                        //DB接続失敗時、処理中止のため、親にも通知する
                        throw;
                    }
                    catch (PostgresException e)
                    {
                        Console.WriteLine(e.Message);
                    }
                    return dataSet;
                }
            }
        }
        #endregion

        /// <summary>
        /// 都道府県IDを参照する
        /// </summary>
        /// <param name="prefectureName">都道府県名</param>
        /// <returns>都道府県ID</returns>
        public short ReferencePrefectureId(string prefectureName)
        {
            short prefectureId = 0;

            using (var command = new NpgsqlCommand())
            {
                try
                {
                    // SQLコマンド作成
                    command.CommandText = @"SELECT PREFECTURE_ID FROM PREFECTURE_MASTER_T WHERE PREFECTURE_NAME = :prefectureName";
                    command.Parameters.Add(new NpgsqlParameter("prefectureName", NpgsqlTypes.NpgsqlDbType.Text)).Value = prefectureName;

                    // SQL実行
                    var dataSet = executeSelect(command);

                    // 最初に見つかった値を都道府県IDとする
                    getValueFromDataSet(dataSet.Tables[0].Rows[0][0], out prefectureId);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
            }

            return prefectureId;
        }

        /// <summary>
        /// 都道府県名を参照する
        /// </summary>
        /// <param name="prefectureId">都道府県ID</param>
        /// <returns>都道府県名</returns>
        public string ReferencePrefectureName(short prefectureId)
        {
            string prefectureName = "";

            using (var command = new NpgsqlCommand())
            {
                try
                {
                    // SQLコマンド作成
                    command.CommandText = @"SELECT PREFECTURE_NAME FROM PREFECTURE_MASTER_T WHERE PREFECTURE_ID = :prefectureId";
                    command.Parameters.Add(new NpgsqlParameter("prefectureId", NpgsqlTypes.NpgsqlDbType.Smallint)).Value = prefectureId;

                    // SQL実行
                    var dataSet = executeSelect(command);

                    // 最初に見つかった値を都道府県IDとする
                    getValueFromDataSet(dataSet.Tables[0].Rows[0][0], out prefectureName);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
            }

            return prefectureName;
        }

        /// <summary>
        /// 最新の走行基本情報IDを参照する
        /// </summary>
        /// <returns>走行基本情報ID</returns>
        public int GetLatestDrivingInfoId()
        {
            int drivingInfoId = 0;

            using (var command = new NpgsqlCommand())
            {
                try
                {
                    // SQLコマンド作成
                    command.CommandText = @"SELECT MAX (DRIVING_INFO_ID) FROM DRIVING_INFO_T";

                    // SQL実行
                    var dataSet = executeSelect(command);

                    // 最初に見つかった値を最新の走行基本情報IDとする
                    getValueFromDataSet(dataSet.Tables[0].Rows[0][0], out drivingInfoId);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
            }

            return drivingInfoId;
        }

        /// <summary>
        /// 最新の評価実施履歴IDを参照する
        /// </summary>
        /// <param name="drivingInfoId">走行基本情報ID</param>
        /// <returns>評価実施履歴ID</returns>
        public int GetLatestEvaluationHistoryId(int drivingInfoId)
        {
            int evaluationHistoryId = 0;

            using (var command = new NpgsqlCommand())
            {
                try
                {
                    // SQLコマンド作成
                    // (評価実施履歴テーブル(EVALUATION_IMPLEMENTATION_HISTORY_T) 中の
                    //  評価実施履歴IDキー (EVALUATION_IMPLEMENTATION_HISTORY_ID) 最大のIDを検索する)
                    command.CommandText = @"SELECT MAX (EVALUATION_IMPLEMENTATION_HISTORY_ID) FROM EVALUATION_IMPLEMENTATION_HISTORY_T";
                    command.CommandText += @"  WHERE DRIVING_INFO_ID = :drivingInfoId";
                    command.CommandText += @";";
                    command.Parameters.Add(new NpgsqlParameter("drivingInfoId", NpgsqlTypes.NpgsqlDbType.Integer)).Value = drivingInfoId;

                    // SQL実行
                    var dataSet = executeSelect(command);

                    // 最初に見つかった値を最新の評価実施履歴IDとする
                    getValueFromDataSet(dataSet.Tables[0].Rows[0][0], out  evaluationHistoryId);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
            }

            return evaluationHistoryId;
        }

        /// <summary>
        /// 指定された走行基本情報IDの最古の評価実施履歴IDを参照する
        /// </summary>
        /// <param name="drivingInfoId">走行基本情報ID</param>
        /// <returns>評価実施履歴ID</returns>
        public int GetOldestEvaluationHistoryId(int drivingInfoId)
        {
            int evaluationHistoryId = 0;

            using (var command = new NpgsqlCommand())
            {
                try
                {
                    // SQLコマンド作成
                    // (評価実施履歴テーブル(EVALUATION_IMPLEMENTATION_HISTORY_T) 中の
                    //  評価実施履歴IDキー (EVALUATION_IMPLEMENTATION_HISTORY_ID) 最大のIDを検索する)
                    command.CommandText = @"SELECT MIN(EVALUATION_IMPLEMENTATION_HISTORY_ID) FROM EVALUATION_IMPLEMENTATION_HISTORY_T";
                    command.CommandText += @"  WHERE DRIVING_INFO_ID = :drivingInfoId";
                    command.CommandText += @";";
                    command.Parameters.Add(new NpgsqlParameter("drivingInfoId", NpgsqlTypes.NpgsqlDbType.Integer)).Value = drivingInfoId;

                    // SQL実行
                    var dataSet = executeSelect(command);

                    // 最初に見つかった値を最新の評価実施履歴IDとする
                    getValueFromDataSet(dataSet.Tables[0].Rows[0][0], out evaluationHistoryId);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
            }

            return evaluationHistoryId;
        }

        /// <summary>
        /// 交差点情報を取得する
        /// </summary>
        /// <param name="prefectureId">都道府県ID</param>
        /// <param name="routeNum">路線番号</param>
        /// <param name="intersectionInfos">[out]交差点情報リスト</param>
        /// <returns>true:成功,false:失敗</returns>
        public bool GetIntersectionInfo(short prefectureId, short routeNum, out List<StIntersectionInfo> intersectionInfos)
        {
            // 交差点情報構造体を生成
            intersectionInfos = new List<StIntersectionInfo>();

            using (var command = new NpgsqlCommand())
            {
                try
                {
                    // 路線情報IDを導出する (路線情報ID = 1000 * 都道府県ID + 路線番号)
                    int routeInfoId = 1000 * prefectureId + routeNum;

                    // SQLコマンド作成
                    command.CommandText = @"SELECT";
                    command.CommandText += @" IIMT.*";
                    command.CommandText += @" FROM INTERSECTION_INFO_MASTER_T AS IIMT";
                    command.CommandText += @"  LEFT JOIN ROUTE_INTERSECTION_INFO_T AS RIIT";
                    command.CommandText += @"   ON IIMT.INTERSECTION_INFO_ID = RIIT.INTERSECTION_INFO_ID";
                    command.CommandText += @"    LEFT JOIN PREFECTURE_ROUTE_INFO_T AS PRIT";
                    command.CommandText += @"     ON RIIT.ROUTE_INFO_ID = PRIT.ROUTE_INFO_ID";
                    command.CommandText += @" WHERE";
                    command.CommandText += @"  PRIT.PREFECTURE_ID = :prefectureId";
                    command.CommandText += @"  AND PRIT.ROUTE_INFO_ID = :routeInfoId";
                    command.CommandText += @";";
                    command.Parameters.Add(new NpgsqlParameter("prefectureId", NpgsqlTypes.NpgsqlDbType.Smallint)).Value = prefectureId;
                    command.Parameters.Add(new NpgsqlParameter("routeInfoId", NpgsqlTypes.NpgsqlDbType.Integer)).Value = routeInfoId;

                    // SQL実行
                    var dataSet = executeSelect(command);

                    // 最初に見つかった行から交差点情報データを抜き出す
                    foreach (DataRow row in dataSet.Tables[0].Rows)
                    {
                        var r = dataSet.Tables[0].Rows;
                        var rr = dataSet.Tables[0].Rows[0];
                        var intersectionInfo = new StIntersectionInfo();
                        getValueFromDataSet(row[0], out intersectionInfo.Id);                           // 交差点情報ID
                        getValueFromDataSet(row[1], out intersectionInfo.IntersectionOrder);            // 交差点順序
                        getValueFromDataSet(row[2], out intersectionInfo.ControlManagementNum);         // 管制管理番号
                        getValueFromDataSet(row[3], out intersectionInfo.IntersectionName);             // 交差点名称
                        getValueFromDataSet(row[4], out intersectionInfo.SecondaryMeshCoordinates);     // 2次メッシュ座標
                        getValueFromDataSet(row[5], out intersectionInfo.NormalizedCoordinateX);        // 正規化座標X
                        getValueFromDataSet(row[6], out intersectionInfo.NormalizedCoordinateY);        // 正規化座標Y
                        getValueFromDataSet(row[7], out intersectionInfo.SignalInfoProvision);          // 信号情報提供有無
                        getValueFromDataSet(row[8], out intersectionInfo.LatitudeVics);                 // 緯度(VICS)
                        getValueFromDataSet(row[9], out intersectionInfo.LongitudeVics);                // 経度(VICS)
                        getValueFromDataSet(row[10], out intersectionInfo.LatitudeTrueValue);           // 緯度(真値)
                        getValueFromDataSet(row[11], out intersectionInfo.LongitudeTrueValue);          // 経度(真値)
                        getValueFromDataSet(row[12], out intersectionInfo.DestinationDistanceTrueValue);// 道程距離(真値)
                        intersectionInfos.Add(intersectionInfo);
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// 評価仕様を取得する
        /// </summary>
        /// <param name="evalSpecId">評価仕様ID</param>
        /// <param name="evalSpec">[out]評価仕様</param>
        /// <returns>true:成功,false:失敗</returns>
        public bool GetEvaluationSpecification(int evalSpecId, out StEvaluationSpecification evalSpec)
        {
            // 評価仕様構造体を生成
            evalSpec = new StEvaluationSpecification();

            using (var command = new NpgsqlCommand())
            {
                try
                {
                    // SQLコマンド作成
                    // (評価仕様マスタテーブル(EVALUATION_SPECIFICATION_MASTER_T) 中の
                    //  評価仕様IDキー (EVALUATION_SPECIFICATION_ID) が一致するレコードを取得する)
                    command.CommandText = @"SELECT * FROM EVALUATION_SPECIFICATION_MASTER_T WHERE (EVALUATION_SPECIFICATION_ID = :evalSpecId);";
                    command.Parameters.Add(new NpgsqlParameter("evalSpecId", NpgsqlTypes.NpgsqlDbType.Integer)).Value = evalSpecId;

                    // SQL実行
                    var dataSet = executeSelect(command);

                    // 最初に見つかった行から評価仕様データを抜き出す
                    int tempValue;
                    getValueFromDataSet(dataSet.Tables[0].Rows[0][0], out evalSpec.Id);             // 評価仕様ID
                    getValueFromDataSet(dataSet.Tables[0].Rows[0][1], out tempValue);
                    evalSpec.Version = (EvaluationVersion)tempValue;                                // 版
                    getValueFromDataSet(dataSet.Tables[0].Rows[0][2], out evalSpec.EvaluationItem); // 評価項目
                    getValueFromDataSet(dataSet.Tables[0].Rows[0][3], out evalSpec.Condition);      // 条件
                    getValueFromDataSet(dataSet.Tables[0].Rows[0][4], out tempValue);
                    evalSpec.pattern = (EvaluationPattern)tempValue;                                // 評価パターン
                    getValueFromDataSet(dataSet.Tables[0].Rows[0][5], out evalSpec.Value1);         // 値1
                    getValueFromDataSet(dataSet.Tables[0].Rows[0][6], out evalSpec.Value2);         // 値2
                    getValueFromDataSet(dataSet.Tables[0].Rows[0][7], out evalSpec.Value3);         // 値3
                    getValueFromDataSet(dataSet.Tables[0].Rows[0][8], out evalSpec.EntryDatetime);  // 登録日時
                    getValueFromDataSet(dataSet.Tables[0].Rows[0][9], out evalSpec.RenewDatetime);  // 更新日時
                    getValueFromDataSet(dataSet.Tables[0].Rows[0][10], out evalSpec.LogicalDelete); // 論理削除
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// 走行基本情報を取得する
        /// </summary>
        /// <param name="drivingInfoId">走行基本情報ID</param>
        /// <param name="drivingInfo">[out]走行基本情報</param>
        /// <returns>true:成功,false:失敗</returns>
        public bool GetDrivingInfo(int drivingInfoId, out StDrivingInfo drivingInfo)
        {
            // 走行基本情報構造体を生成
            drivingInfo = new StDrivingInfo();

            using (var command = new NpgsqlCommand())
            {
                try
                {
                    // SQLコマンド作成
                    // (評価仕様マスタテーブル(EVALUATION_SPECIFICATION_MASTER_T) 中の
                    //  評価仕様IDキー (EVALUATION_SPECIFICATION_ID) が一致するレコードを取得する)
                    command.CommandText = @"SELECT * FROM DRIVING_INFO_T WHERE (DRIVING_INFO_ID = :drivingInfoId);";
                    command.Parameters.Add(new NpgsqlParameter("drivingInfoId", NpgsqlTypes.NpgsqlDbType.Integer)).Value = drivingInfoId;

                    // SQL実行
                    var dataSet = executeSelect(command);

                    // 最初に見つかった行から走行基本情報データを抜き出す
                    int tempValue;
                    var row = dataSet.Tables[0].Rows[0];
                    getValueFromDataSet(row[0], out drivingInfo.DrivingInfoId);    // 走行基本情報ID
                    getValueFromDataSet(row[1], out drivingInfo.PrefectureId);     // 都道府県ID
                    getValueFromDataSet(row[2], out drivingInfo.RouteNum);         // 路線No.
                    getValueFromDataSet(row[3], out drivingInfo.DrivingDatetime);  // 走行日時
                    getValueFromDataSet(row[4], out tempValue);
                    drivingInfo.Version = (EvaluationVersion)tempValue;            // 版
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// 評価実施履歴を取得する
        /// </summary>
        /// <param name="drivingInfoId">走行基本情報ID</param>
        /// <param name="evaluationHistoryId">評価実施履歴ID</param>
        /// <param name="evaluationHistory">[out]評価実施履歴</param>
        /// <returns>true:成功,false:失敗</returns>
        public bool GetRouteSignalInfo(int drivingInfoId, int evaluationHistoryId, out StEvaluationHistory evaluationHistory)
        {
            // 評価実施履歴構造体を生成
            evaluationHistory = new StEvaluationHistory();

            using (var command = new NpgsqlCommand())
            {
                try
                {
                    // SQLコマンド作成
                    command.CommandText = @"SELECT";
                    command.CommandText += @" *";
                    command.CommandText += @" FROM EVALUATION_IMPLEMENTATION_HISTORY_T";
                    command.CommandText += @"  WHERE DRIVING_INFO_ID = :drivingInfoId";
                    command.CommandText += @"   AND EVALUATION_IMPLEMENTATION_HISTORY_ID = :evaluationHistoryId";
                    command.CommandText += @";";
                    command.Parameters.Add(new NpgsqlParameter("drivingInfoId", NpgsqlTypes.NpgsqlDbType.Integer)).Value = drivingInfoId;
                    command.Parameters.Add(new NpgsqlParameter("evaluationHistoryId", NpgsqlTypes.NpgsqlDbType.Integer)).Value = evaluationHistoryId;

                    // SQL実行
                    var dataSet = executeSelect(command);

                    // 最初に見つかった行から評価実施履歴データを抜き出す
                    var row = dataSet.Tables[0].Rows[0];
                    getValueFromDataSet(row[0], out evaluationHistory.DrivingInfoId);           // 走行基本情報ID
                    getValueFromDataSet(row[1], out evaluationHistory.EvaluationHistoryId);     // 評価実施履歴ID
                    getValueFromDataSet(row[2], out evaluationHistory.EvaluationDatetime);      // 評価日時
                    short tempValueStatus;
                    getValueFromDataSet(row[3], out tempValueStatus);
                    evaluationHistory.Status = (EvaluationStatus)tempValueStatus;               // ステータス
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// 路線信号基本情報を取得する
        /// </summary>
        /// <param name="drivingInfoId">走行基本情報ID</param>
        /// <param name="evaluationHistoryId">評価実施履歴ID</param>
        /// <param name="routeSignalInfo">[out]路線信号基本情報</param>
        /// <returns>true:成功,false:失敗</returns>
        public bool GetRouteSignalInfo(int drivingInfoId, int evaluationSpecificationId, out StRouteSignalInfo routeSignalInfo)
        {
            // 路線信号基本情報構造体を生成
            routeSignalInfo = new StRouteSignalInfo();

            using (var command = new NpgsqlCommand())
            {
                try
                {
                    // SQLコマンド作成
                    command.CommandText = @"SELECT";
                    command.CommandText += @" *";
                    command.CommandText += @" FROM ROUTE_SIGNAL_INFO_T";
                    command.CommandText += @"  WHERE DRIVING_INFO_ID = :drivingInfoId";
                    command.CommandText += @"   AND EVALUATION_SPECIFICATION_ID = :evaluationSpecificationId";
                    command.CommandText += @";";
                    command.Parameters.Add(new NpgsqlParameter("drivingInfoId", NpgsqlTypes.NpgsqlDbType.Integer)).Value = drivingInfoId;
                    command.Parameters.Add(new NpgsqlParameter("evaluationSpecificationId", NpgsqlTypes.NpgsqlDbType.Integer)).Value = evaluationSpecificationId;

                    // SQL実行
                    var dataSet = executeSelect(command);

                    // 最初に見つかった行から走行基本情報データを抜き出す
                    var row = dataSet.Tables[0].Rows[0];
                    getValueFromDataSet(row[0], out routeSignalInfo.DrivingInfoId);             // 走行基本情報ID
                    getValueFromDataSet(row[1], out routeSignalInfo.EvaluationSpecificationId); // 評価仕様ID
                    getValueFromDataSet(row[2], out routeSignalInfo.IntegerValue);              // 整数値
                    getValueFromDataSet(row[3], out routeSignalInfo.Judgment);                  // 判定
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// 交差点路線信号情報を取得する
        /// </summary>
        /// <param name="drivingInfoId">走行基本情報ID</param>
        /// <param name="intersectionRouteSignalInfoId">交差点路線信号情報ID</param>
        /// <param name="evaluationSpecificationId">評価仕様ID</param>
        /// <param name="intersectionRouteSignalInfo">[out]交差点路線信号情報</param>
        /// <returns>true:成功,false:失敗</returns>
        public bool GetIntersectionRouteSignalInfo(int drivingInfoId, int intersectionRouteSignalInfoId, int evaluationSpecificationId, out StIntersectionRouteSignalInfo intersectionRouteSignalInfo)
        {
            // 交差点路線信号情報構造体を生成
            intersectionRouteSignalInfo = new StIntersectionRouteSignalInfo();

            using (var command = new NpgsqlCommand())
            {
                try
                {
                    // SQLコマンド作成
                    command.CommandText = @"SELECT";
                    command.CommandText += @" *";
                    command.CommandText += @" FROM INTERSECTION_ROUTE_SIGNAL_INFO_T";
                    command.CommandText += @"  WHERE DRIVING_INFO_ID = :drivingInfoId";
                    command.CommandText += @"   AND INTERSECTION_ROUTE_SIGNAL_INFO_ID = :intersectionRouteSignalInfoId";
                    command.CommandText += @"   AND EVALUATION_SPECIFICATION_ID = :evaluationSpecificationId";
                    command.CommandText += @";";
                    command.Parameters.Add(new NpgsqlParameter("drivingInfoId", NpgsqlTypes.NpgsqlDbType.Integer)).Value = drivingInfoId;
                    command.Parameters.Add(new NpgsqlParameter("intersectionRouteSignalInfoId", NpgsqlTypes.NpgsqlDbType.Integer)).Value = intersectionRouteSignalInfoId;
                    command.Parameters.Add(new NpgsqlParameter("evaluationSpecificationId", NpgsqlTypes.NpgsqlDbType.Integer)).Value = evaluationSpecificationId;

                    // SQL実行
                    var dataSet = executeSelect(command);

                    // 最初に見つかった行から走行基本情報データを抜き出す
                    var row = dataSet.Tables[0].Rows[0];
                    getValueFromDataSet(row[0], out intersectionRouteSignalInfo.DrivingInfoId);                 // 走行基本情報ID
                    getValueFromDataSet(row[1], out intersectionRouteSignalInfo.IntersectionRouteSignalInfoId); // 交差点路線信号情報ID
                    getValueFromDataSet(row[2], out intersectionRouteSignalInfo.EvaluationSpecificationId);     // 評価仕様ID
                    getValueFromDataSet(row[3], out intersectionRouteSignalInfo.ValueType);                     // 値タイプ
                    getValueFromDataSet(row[4], out intersectionRouteSignalInfo.IntegerValue);                  // 整数値
                    getValueFromDataSet(row[5], out intersectionRouteSignalInfo.DoubleValue);                   // 浮動小数値
                    getValueFromDataSet(row[6], out intersectionRouteSignalInfo.Judgment);                      // 判定
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// 同日中の走行回数を取得する
        /// </summary>
        /// <param name="drivingInfo">走行基本情報</param>
        /// <param name="drivingTimes">[out]同日中の走行回数</param>
        /// <returns>true:成功,false:失敗</returns>
        public bool GetDrivingTimes(StDrivingInfo drivingInfo, out short drivingTimes)
        {
            // 走行回数を初期化
            drivingTimes = 0;

            // 指定された走行基本情報から都道府県IDと路線番号を取得する
            var prefecturesId = drivingInfo.PrefectureId;       // 都道府県ID
            var routeNumber = drivingInfo.RouteNum;             // 路線番号

            // 指定された走行基本情報から走行日を取得する
            var drivingDateTime = drivingInfo.DrivingDatetime;  // 走行日時
            var drivingDate = drivingDateTime.Date;
            var drivingDateTimeBegin = drivingDate;
            var drivingDateTimeEnd = drivingDate + new TimeSpan(23, 59, 59, 999);

            using (var command = new NpgsqlCommand())
            {
                try
                {
                    // SQLコマンド作成
                    command.CommandText = @" SELECT";
                    command.CommandText += @" *";
                    command.CommandText += @"  FROM";
                    command.CommandText += @"   DRIVING_INFO_T";
                    command.CommandText += @"    WHERE";
                    command.CommandText += @"     (PREFECTURES_ID = :prefecturesId)";
                    command.CommandText += @"     AND";
                    command.CommandText += @"     (ROUTE_NUMBER = :routeNumber)";
                    command.CommandText += @"     AND";
                    command.CommandText += @"     ((timestamp :tripDateBegin) <= TRIP_TIMESTAMP)";
                    command.CommandText += @"     AND";
                    command.CommandText += @"     (TRIP_TIMESTAMP <= (timestamp :tripDateEnd))";
                    command.CommandText += @";";
                    command.Parameters.Add(new NpgsqlParameter("prefecturesId", NpgsqlTypes.NpgsqlDbType.Smallint)).Value = prefecturesId;
                    command.Parameters.Add(new NpgsqlParameter("routeNumber", NpgsqlTypes.NpgsqlDbType.Smallint)).Value = routeNumber;
                    command.Parameters.Add(new NpgsqlParameter("drivingDateTimeBegin", NpgsqlTypes.NpgsqlDbType.Timestamp)).Value = drivingDateTimeBegin;
                    command.Parameters.Add(new NpgsqlParameter("drivingDateTimeEnd", NpgsqlTypes.NpgsqlDbType.Timestamp)).Value = drivingDateTimeEnd;

                    // SQL実行
                    var dataSet = executeSelect(command);

                    // 最初に見つかった行から走行基本情報データの走行日時リストに抜き出す
                    var drivingDatetimes = new List<DateTime>();
                    foreach (DataRow row in dataSet.Tables[0].Rows)
                    {
                        var r = dataSet.Tables[0].Rows;
                        var rr = dataSet.Tables[0].Rows[0];
                        DateTime drivingDatetime;
                        getValueFromDataSet(row[3], out drivingDatetime);  // 走行日時 (走行日時は3列目の要素)
                        drivingDatetimes.Add(drivingDatetime);
                    }

                    // 走行日時リストを検索して、同日中の何回目の走行かを取得する
                    foreach (var datetime in drivingDatetimes)
                    {
                        ++drivingTimes;     // 走行回数をインクリメント
                        if (datetime == drivingDateTime)
                            break;
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// 評価仕様IDから項目IDを参照する
        /// </summary>
        /// <param name="evaluationSpecificationId">評価仕様ID</param>
        /// <returns>項目ID</returns>
        public double ReferenceItemID(int evaluationSpecificationId)
        {

            double itemID = 0;
            using (var command = new NpgsqlCommand())
            {
                try
                {
                    // SQLコマンド作成
                    command.CommandText = @"SELECT ITEM_ID FROM ITEM_EVALUATION_SPECIFICATION_T WHERE EVALUATIONSPECIFICATION_ID = :evaluationSpecificationId";
                    command.Parameters.Add(new NpgsqlParameter("evaluationSpecificationId", NpgsqlTypes.NpgsqlDbType.Integer)).Value = evaluationSpecificationId;

                    // SQL実行
                    var dataSet = executeSelect(command);

                    // 最初に見つかった値を項目IDとする
                    getValueFromDataSet(dataSet.Tables[0].Rows[0][0], out itemID);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
            }
            return itemID;
        }

        /// <summary>
        /// 項目IDから出力文字列を参照する
        /// </summary>
        /// <param name="itemid">項目ID</param>
        /// <returns>項目マスタの出力文字列</returns>
        public string ReferenceOutputString(double itemid )
        {
            string outputString = "";
            using (var command = new NpgsqlCommand())
            {
                try
                {
                    // SQLコマンド作成
                    command.CommandText = @"SELECT OUTPUT_STRING ITEM_MASTER_T WHERE ITEM_ID = :itemid";
                    command.Parameters.Add(new NpgsqlParameter("itemid", NpgsqlTypes.NpgsqlDbType.Double)).Value = itemid;

                    // SQL実行
                    var dataSet = executeSelect(command);

                    // 最初に見つかった値を出力文字列とする
                    getValueFromDataSet(dataSet.Tables[0].Rows[0][0], out outputString);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
            }
            return outputString;
        }

        /// <summary>
        /// 項目IDから枝番を参照する
        /// </summary>
        /// <param name="itemid">項目ID</param>
        /// <returns>項目マスタの枝番</returns>
        public short ReferenceBranchNum(double itemid)
        {
            short branchNum = 0;
            using (var command = new NpgsqlCommand())
            {
                try
                {
                    // SQLコマンド作成
                    command.CommandText = @"SELECT BRANCH_NUM FROM ITEM_EVALUATION_SPECIFICATION_T WHERE EVALUATIONSPECIFICATION_ID = :itemid";
                    command.Parameters.Add(new NpgsqlParameter("itemid", NpgsqlTypes.NpgsqlDbType.Double)).Value = itemid;

                    // SQL実行
                    var dataSet = executeSelect(command);

                    // 最初に見つかった値を項目IDとする
                    getValueFromDataSet(dataSet.Tables[0].Rows[0][0], out branchNum);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
            }
            return branchNum;
        }

        /// <summary>
        /// SQL実行結果からデータを取得する (bool型)
        /// </summary>
        /// <param name="dataSetValue">DataSetの値要素</param>
        /// <param name="outputValue">[out]取得したbool値</param>
        private void getValueFromDataSet(object dataSetValue, out bool outputValue)
        {
            bool? tempValue;
            getValueFromDataSet(dataSetValue, out tempValue);
            outputValue = tempValue ?? false;               // null合体演算子でnull時はfalseに設定する
        }
        private void getValueFromDataSet(object dataSetValue, out bool? outputValue)
        {
            if (dataSetValue == DBNull.Value)
                outputValue = null;
            else
            {
                bool tempValue;
                bool.TryParse(dataSetValue.ToString(), out tempValue);
                outputValue = tempValue;
            }
        }
        
        /// <summary>
        /// SQL実行結果からデータを取得する (short型)
        /// </summary>
        /// <param name="dataSetValue">DataSetの値要素</param>
        /// <param name="outputValue">[out]取得したshort値</param>
        private void getValueFromDataSet(object dataSetValue, out short outputValue)
        {
            short? tempValue;
            getValueFromDataSet(dataSetValue, out tempValue);
            outputValue = tempValue ?? 0;                   // null合体演算子でnull時は0に設定する
        }
        private void getValueFromDataSet(object dataSetValue, out short? outputValue)
        {
            if (dataSetValue == DBNull.Value)
                outputValue = null;
            else
            {
                short tempValue;
                short.TryParse(dataSetValue.ToString(), out tempValue);
                outputValue = tempValue;
            }
        }

        /// <summary>
        /// SQL実行結果からデータを取得する (int型)
        /// </summary>
        /// <param name="dataSetValue">DataSetの値要素</param>
        /// <param name="outputValue">[out]取得したint値</param>
        private void getValueFromDataSet(object dataSetValue, out int outputValue)
        {
            int? tempValue;
            getValueFromDataSet(dataSetValue, out tempValue);
            outputValue = tempValue ?? 0;                   // null合体演算子でnull時は0に設定する
        }
        private void getValueFromDataSet(object dataSetValue, out int? outputValue)
        {
            if (dataSetValue == DBNull.Value)
            {
                outputValue = null;
            }
            else
            {
                int tempValue;
                int.TryParse(dataSetValue.ToString(), out tempValue);
                outputValue = tempValue;
            }
        }

        /// <summary>
        /// SQL実行結果からデータを取得する (long型)
        /// </summary>
        /// <param name="dataSetValue">DataSetの値要素</param>
        /// <param name="outputValue">[out]取得したlong値</param>
        private void getValueFromDataSet(object dataSetValue, out long outputValue)
        {
            long? tempValue;
            getValueFromDataSet(dataSetValue, out tempValue);
            outputValue = tempValue ?? 0;                   // null合体演算子でnull時は0に設定する
        }
        private void getValueFromDataSet(object dataSetValue, out long? outputValue)
        {
            if (dataSetValue == DBNull.Value)
            {
                outputValue = null;
            }
            else
            {
                long tempValue;
                long.TryParse(dataSetValue.ToString(), out tempValue);
                outputValue = tempValue;
            }
        }

        /// <summary>
        /// SQL実行結果からデータを取得する (double型)
        /// </summary>
        /// <param name="dataSetValue">DataSetの値要素</param>
        /// <param name="outputValue">[out]取得したdouble値</param>
        private void getValueFromDataSet(object dataSetValue, out double outputValue)
        {
            double? tempValue;
            getValueFromDataSet(dataSetValue, out tempValue);
            outputValue = tempValue ?? 0;                   // null合体演算子でnull時は0に設定する
        }
        private void getValueFromDataSet(object dataSetValue, out double? outputValue)
        {
            if (dataSetValue == DBNull.Value)
            {
                outputValue = null;
            }
            else
            {
                double tempValue;
                double.TryParse(dataSetValue.ToString(), out tempValue);
                outputValue = tempValue;
            }
        }

        /// <summary>
        /// SQL実行結果からデータを取得する (DateTime型)
        /// </summary>
        /// <param name="dataSetValue">DataSetの値要素</param>
        /// <param name="outputValue">[out]取得したDateTime値</param>
        private void getValueFromDataSet(object dataSetValue, out DateTime outputValue)
        {
            DateTime? tempValue;
            getValueFromDataSet(dataSetValue, out tempValue);
            outputValue = tempValue ?? DateTime.MinValue;   // null合体演算子でnull時は0001/01/01 0:00:00に設定する
        }
        private void getValueFromDataSet(object dataSetValue, out DateTime? outputValue)
        {
            if (dataSetValue == DBNull.Value)
            {
                outputValue = null;
            }
            else
            {
                DateTime tempValue;
                DateTime.TryParse(dataSetValue.ToString(), out tempValue);
                outputValue = tempValue;
            }
        }

        /// <summary>
        /// SQL実行結果からデータを取得する (string型)
        /// </summary>
        /// <param name="dataSetValue">DataSetの値要素</param>
        /// <param name="outputValue">[out]取得したstring値</param>
        private void getValueFromDataSet(object dataSetValue, out string outputValue)
        {
            if (dataSetValue == DBNull.Value)
            {
                outputValue = null;
            }
            else
            {
                outputValue = dataSetValue.ToString();
            }
        }

        #region DataSet executeInsert(string strSql)
        /// <summary>
        /// 引数で指定されたSQLでINSERTを実行します。
        /// </summary>
        /// <param name="command">実行するSQLを指定します。</param>
        /// <returns>SQL実行結果を返します。</returns>
        private void executeInsert(NpgsqlCommand command)
        {
            // 接続準備
            using (var connection = new NpgsqlConnection(connectionString))
            {
                try
                {
                    // データベースの接続開始
                    connection.Open();

                    // INSERTを実行
                    command.Connection = connection;
                    command.ExecuteNonQuery();
                }
                catch (System.Net.Sockets.SocketException e)
                {
                    Console.WriteLine(e.Message);
                    //DB接続失敗時、処理中止のため、親にも通知する
                    throw;
                }
                catch (ArgumentException e)
                {
                    Console.WriteLine(e.Message);
                    //DB接続失敗時、処理中止のため、親にも通知する
                    throw;
                }
                catch (PostgresException e)
                {
                    Console.WriteLine(e.Message);
                }
            }
        }
        #endregion

        /// <summary>
        /// 走行基本情報テーブルにデータを追加する
        /// </summary>
        /// <param name="drivingInfoId">走行基本情報ID</param>
        /// <param name="prerectureId">都道府県ID</param>
        /// <param name="routeNum">路線No.</param>
        /// <param name="drivingDatetime">走行日時</param>
        /// <param name="evaluationVersion">版</param>
        /// <returns>ture:成功、false:失敗</returns>
        /// <remarks>都道府県ごとの路線情報を格納するトランザクションテーブル</remarks>
        public bool InsertDrivingInfo(int drivingInfoId, short prerectureId, short routeNum, DateTime drivingDatetime, EvaluationVersion evaluationVersion)
        {
            // 接続準備
            using (var command = new NpgsqlCommand())
            {
                try
                {
                    // SQLコマンド作成
                    command.CommandText = @"INSERT INTO DRIVING_INFO_T ";
                    command.CommandText += @"(DRIVING_INFO_ID, PREFECTURE_ID, ROUTE_NUM, DRIVING_DATETIME, SPECIFICATION_VERSION) ";
                    command.CommandText += @"VALUES ";
                    command.CommandText += @"(:DRIVING_INFO_ID, :PREFECTURE_ID, :ROUTE_NUM, :DRIVING_DATETIME, :SPECIFICATION_VERSION)";
                    command.Parameters.Add(new NpgsqlParameter("DRIVING_INFO_ID", NpgsqlTypes.NpgsqlDbType.Integer)).Value = drivingInfoId;
                    command.Parameters.Add(new NpgsqlParameter("PREFECTURE_ID", NpgsqlTypes.NpgsqlDbType.Smallint)).Value = prerectureId;
                    command.Parameters.Add(new NpgsqlParameter("ROUTE_NUM", NpgsqlTypes.NpgsqlDbType.Smallint)).Value = routeNum;
                    command.Parameters.Add(new NpgsqlParameter("DRIVING_DATETIME", NpgsqlTypes.NpgsqlDbType.Timestamp)).Value = drivingDatetime;
                    short shortValueEvaluationVersion = (short)evaluationVersion;
                    command.Parameters.Add(new NpgsqlParameter("SPECIFICATION_VERSION", NpgsqlTypes.NpgsqlDbType.Smallint)).Value = shortValueEvaluationVersion;

                    // SQLの実行
                    executeInsert(command);
                }
                catch (Exception exception)
                {
                    Console.WriteLine(exception.Message);
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// 路線信号基本情報テーブルにデータを追加する
        /// </summary>
        /// <param name="drivingInfoId">走行基本情報ID</param>
        /// <param name="evaluationSpecificationId">評価仕様ID</param>
        /// <param name="integerValue">整数値</param>
        /// <param name="judgment">判定</param>
        /// <returns>ture:成功、false:失敗</returns>
        /// <remarks>光ビーコンデータの路線信号情報データと評価結果を格納するトランザクションテーブル</remarks>
        public bool InsertRouteSignalInfo(int drivingInfoId, int evaluationSpecificationId, int? integerValue, bool? judgment)
        {
            // 接続準備
            using (var command = new NpgsqlCommand())
            {
                try
                {
                    // SQLの準備
                    command.CommandText = @"INSERT INTO ROUTE_SIGNAL_INFO_T ";
                    command.CommandText += @"(DRIVING_INFO_ID, EVALUATION_SPECIFICATION_ID, INTEGER_VALUE, JUDGMENT) ";
                    command.CommandText += @"VALUES ";
                    command.CommandText += @"(:DRIVING_INFO_ID, :EVALUATION_SPECIFICATION_ID, :INTEGER_VALUE, :JUDGMENT)";
                    command.Parameters.Add(new NpgsqlParameter("DRIVING_INFO_ID", NpgsqlTypes.NpgsqlDbType.Integer)).Value = drivingInfoId;
                    command.Parameters.Add(new NpgsqlParameter("EVALUATION_SPECIFICATION_ID", NpgsqlTypes.NpgsqlDbType.Integer)).Value = evaluationSpecificationId;
                    command.Parameters.Add(new NpgsqlParameter("INTEGER_VALUE", NpgsqlTypes.NpgsqlDbType.Integer)).Value = (object)integerValue ?? DBNull.Value;
                    command.Parameters.Add(new NpgsqlParameter("JUDGMENT", NpgsqlTypes.NpgsqlDbType.Boolean)).Value = (object)judgment ?? DBNull.Value;

                    // SQLの実行
                    executeInsert(command);
                }
                catch (Exception exception)
                {
                    Console.WriteLine(exception.Message);
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// 交差点路線信号情報テーブルにデータを追加する
        /// </summary>
        /// <param name="drivingInfoId">走行基本情報ID</param>
        /// <param name="intersectionRouteSignalInfoId">交差点路線信号情報ID</param>
        /// <param name="evaluationSpecificationId">評価仕様ID</param>
        /// <param name="valueType">値タイプ</param>
        /// <param name="integerValue">整数値</param>
        /// <param name="decimalValue">小数値</param>
        /// <param name="judgment">判定</param>
        /// <returns>ture:成功、false:失敗</returns>
        /// <remarks>光ビーコンデータの交差点路線信号情報データと評価結果を格納するトランザクションテーブル</ remarks>
        public bool InsertIntersectionRouteSignalInfo(int drivingInfoId, int intersectionRouteSignalInfoId, int evaluationSpecificationId, EvaluationValueType valueType, int? integerValue, double? decimalValue, bool? judgment)
        {
            // 接続準備
            using (var command = new NpgsqlCommand())
            {
                try
                {
                    // SQLの準備
                    command.CommandText = @"INSERT INTO INTERSECTION_ROUTE_SIGNAL_INFO_T ";
                    command.CommandText += @"(DRIVING_INFO_ID, INTERSECTION_ROUTE_SIGNAL_INFO_ID, EVALUATION_SPECIFICATION_ID, VALUE_TYPE, INTEGER_VALUE, DECIMAL_VALUE, JUDGMENT) ";
                    command.CommandText += @"VALUES ";
                    command.CommandText += @"(:DRIVING_INFO_ID, :INTERSECTION_ROUTE_SIGNAL_INFO_ID, :EVALUATION_SPECIFICATION_ID, :VALUE_TYPE, :INTEGER_VALUE, :DECIMAL_VALUE, :JUDGMENT)";
                    command.Parameters.Add(new NpgsqlParameter("DRIVING_INFO_ID", NpgsqlTypes.NpgsqlDbType.Integer)).Value = drivingInfoId;
                    command.Parameters.Add(new NpgsqlParameter("INTERSECTION_ROUTE_SIGNAL_INFO_ID", NpgsqlTypes.NpgsqlDbType.Integer)).Value = intersectionRouteSignalInfoId;
                    command.Parameters.Add(new NpgsqlParameter("EVALUATION_SPECIFICATION_ID", NpgsqlTypes.NpgsqlDbType.Integer)).Value = evaluationSpecificationId;
                    command.Parameters.Add(new NpgsqlParameter("VALUE_TYPE", NpgsqlTypes.NpgsqlDbType.Smallint)).Value = valueType;
                    command.Parameters.Add(new NpgsqlParameter("INTEGER_VALUE", NpgsqlTypes.NpgsqlDbType.Integer)).Value = (object)integerValue ?? DBNull.Value;
                    command.Parameters.Add(new NpgsqlParameter("DECIMAL_VALUE", NpgsqlTypes.NpgsqlDbType.Double)).Value = (object)decimalValue ?? DBNull.Value;
                    command.Parameters.Add(new NpgsqlParameter("JUDGMENT", NpgsqlTypes.NpgsqlDbType.Boolean)).Value = (object)judgment ?? DBNull.Value;

                    // SQLの実行
                    executeInsert(command);
                }
                catch (Exception exception)
                {
                    Console.WriteLine(exception.Message);
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// サイクル情報テーブルにデータを追加する
        /// </summary>
        /// <param name="drivingInfoId">走行基本情報ID</param>
        /// <param name="intersectionRouteSignalInfoId">交差点路線信号情報ID</param>
        /// <param name="cycleInfoId">サイクル情報ID</param>
        /// <param name="evaluationSpecificationId">評価仕様ID</param>
        /// <param name="integerValue">整数値</param>
        /// <param name="judgment">判定</param>
        /// <returns>ture:成功、false:失敗</returns>
        /// <remarks>光ビーコンデータのサイクル情報データと評価結果を格納するトランザクションテーブル</remarks>
        public bool InsertCycleInfo(int drivingInfoId, int intersectionRouteSignalInfoId, int cycleInfoId, int evaluationSpecificationId, int? integerValue, bool? judgment)
        {
            // 接続準備
            using (var command = new NpgsqlCommand())
            {
                try
                {
                    // SQLの準備
                    command.CommandText = @"INSERT INTO CYCLE_INFO_T ";
                    command.CommandText += @"(DRIVING_INFO_ID, INTERSECTION_ROUTE_SIGNAL_INFO_ID, CYCLE_INFO_ID, EVALUATION_SPECIFICATION_ID, INTEGER_VALUE, JUDGMENT) ";
                    command.CommandText += @"VALUES ";
                    command.CommandText += @"(:DRIVING_INFO_ID, :INTERSECTION_ROUTE_SIGNAL_INFO_ID, :CYCLE_INFO_ID, :EVALUATION_SPECIFICATION_ID, :INTEGER_VALUE, :JUDGMENT)";
                    command.Parameters.Add(new NpgsqlParameter("DRIVING_INFO_ID", NpgsqlTypes.NpgsqlDbType.Integer)).Value = drivingInfoId;
                    command.Parameters.Add(new NpgsqlParameter("INTERSECTION_ROUTE_SIGNAL_INFO_ID", NpgsqlTypes.NpgsqlDbType.Integer)).Value = intersectionRouteSignalInfoId;
                    command.Parameters.Add(new NpgsqlParameter("CYCLE_INFO_ID", NpgsqlTypes.NpgsqlDbType.Integer)).Value = cycleInfoId;
                    command.Parameters.Add(new NpgsqlParameter("EVALUATION_SPECIFICATION_ID", NpgsqlTypes.NpgsqlDbType.Integer)).Value = evaluationSpecificationId;
                    command.Parameters.Add(new NpgsqlParameter("INTEGER_VALUE", NpgsqlTypes.NpgsqlDbType.Integer)).Value = (object)integerValue ?? DBNull.Value;
                    command.Parameters.Add(new NpgsqlParameter("JUDGMENT", NpgsqlTypes.NpgsqlDbType.Boolean)).Value = (object)judgment ?? DBNull.Value;

                    // SQLの実行
                    executeInsert(command);
                }
                catch (Exception exception)
                {
                    Console.WriteLine(exception.Message);
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// 世代テーブルにデータを追加する
        /// </summary>
        /// <param name="drivingInfoId">走行基本情報ID</param>
        /// <param name="generationId">世代ID</param>
        /// <param name="evaluationSpecificationId">評価仕様ID</param>
        /// <param name="integerValue">整数値</param>
        /// <param name="judgment">判定</param>
        /// <returns>ture:成功、false:失敗</returns>
        /// <remarks>光ビーコンデータの世代数データと評価結果を格納するトランザクションテーブル</remarks>
        public bool InsertGeneration(int drivingInfoId, int generationId, int evaluationSpecificationId, int? integerValue, bool? judgment)
        {
            // 接続準備
            using (var command = new NpgsqlCommand())
            {
                try
                {
                    // SQLの準備
                    command.CommandText = @"INSERT INTO GENERATION_T ";
                    command.CommandText += @"(DRIVING_INFO_ID, GENERATION_ID, EVALUATION_SPECIFICATION_ID, INTEGER_VALUE, JUDGMENT) ";
                    command.CommandText += @"VALUES ";
                    command.CommandText += @"(:DRIVING_INFO_ID, :GENERATION_ID, :EVALUATION_SPECIFICATION_ID, :INTEGER_VALUE, :JUDGMENT)";
                    command.Parameters.Add(new NpgsqlParameter("DRIVING_INFO_ID", NpgsqlTypes.NpgsqlDbType.Integer)).Value = drivingInfoId;
                    command.Parameters.Add(new NpgsqlParameter("GENERATION_ID", NpgsqlTypes.NpgsqlDbType.Smallint)).Value = generationId;
                    command.Parameters.Add(new NpgsqlParameter("EVALUATION_SPECIFICATION_ID", NpgsqlTypes.NpgsqlDbType.Integer)).Value = evaluationSpecificationId;
                    command.Parameters.Add(new NpgsqlParameter("INTEGER_VALUE", NpgsqlTypes.NpgsqlDbType.Integer)).Value = (object)integerValue ?? DBNull.Value;
                    command.Parameters.Add(new NpgsqlParameter("JUDGMENT", NpgsqlTypes.NpgsqlDbType.Boolean)).Value = (object)judgment ?? DBNull.Value;

                    // SQLの実行
                    executeInsert(command);
                }
                catch (Exception exception)
                {
                    Console.WriteLine(exception.Message);
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// UTMSリンクテーブルにデータを追加する
        /// </summary>
        /// <param name="drivingInfoId">走行基本情報ID</param>
        /// <param name="generationId">世代ID</param>
        /// <param name="UTMSLinkId">UTMSリンクID</param>
        /// <param name="evaluationSpecificationId">評価仕様ID</param>
        /// <param name="integerValue">整数値</param>
        /// <param name="judgment">判定</param>
        /// <returns>ture:成功、false:失敗</returns>
        /// <remarks>光ビーコンデータのUTMSリンク情報データと評価結果を格納するトランザクションテーブル</remarks>
        public bool InsertUTMSLink(int drivingInfoId, int generationId, int UTMSLinkId, int evaluationSpecificationId, int? integerValue, bool? judgment)
        {
            // 接続準備
            using (var command = new NpgsqlCommand())
            {
                try
                {
                    // SQLの準備
                    command.CommandText = @"INSERT INTO UTMS_LINK_T ";
                    command.CommandText += @"(DRIVING_INFO_ID, GENERATION_ID, UTMS_LINK_ID, EVALUATION_SPECIFICATION_ID, INTEGER_VALUE, JUDGMENT) ";
                    command.CommandText += @"VALUES ";
                    command.CommandText += @"(:DRIVING_INFO_ID, :GENERATION_ID, :UTMS_LINK_ID, :EVALUATION_SPECIFICATION_ID, :INTEGER_VALUE, @JUDGMENT)";
                    command.Parameters.Add(new NpgsqlParameter("DRIVING_INFO_ID", NpgsqlTypes.NpgsqlDbType.Integer)).Value = drivingInfoId;
                    command.Parameters.Add(new NpgsqlParameter("GENERATION_ID", NpgsqlTypes.NpgsqlDbType.Smallint)).Value = generationId;
                    command.Parameters.Add(new NpgsqlParameter("UTMS_LINK_ID", NpgsqlTypes.NpgsqlDbType.Smallint)).Value = UTMSLinkId;
                    command.Parameters.Add(new NpgsqlParameter("EVALUATION_SPECIFICATION_ID", NpgsqlTypes.NpgsqlDbType.Integer)).Value = evaluationSpecificationId;
                    command.Parameters.Add(new NpgsqlParameter("INTEGER_VALUE", NpgsqlTypes.NpgsqlDbType.Integer)).Value = (object)integerValue ?? DBNull.Value;
                    command.Parameters.Add(new NpgsqlParameter("JUDGMENT", NpgsqlTypes.NpgsqlDbType.Boolean)).Value = (object)judgment ?? DBNull.Value;

                    // SQLの実行
                    executeInsert(command);
                }
                catch (Exception exception)
                {
                    Console.WriteLine(exception.Message);
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// 評価実施履歴テーブルにデータを追加する
        /// </summary>
        /// <param name="drivingInfoId">走行基本情報ID</param>
        /// <param name="evaluationImplementationHistoryId">評価実施履歴ID</param>
        /// <param name="evaluationDatetime">評価実施日時</param>
        /// <param name="status">ステータス</param>
        /// <returns>ture:成功、false:失敗</returns>
        /// <remarks>評価の履歴を蓄積するためのトランザクションテーブル</remarks>
        public bool InsertEvaluationImplementationHistory(int drivingInfoId, int evaluationImplementationHistoryId, DateTime evaluationDatetime, DatabaseAccessor.EvaluationStatus status)
        {
            // 接続準備
            using (var command = new NpgsqlCommand())
            {
                try
                {
                    // SQLの準備
                    command.CommandText = @"INSERT INTO EVALUATION_IMPLEMENTATION_HISTORY_T ";
                    command.CommandText += @"(DRIVING_INFO_ID, EVALUATION_IMPLEMENTATION_HISTORY_ID, EVALUATION_DATETIME, STATUS) ";
                    command.CommandText += @"VALUES ";
                    command.CommandText += @"(:DRIVING_INFO_ID, :EVALUATION_IMPLEMENTATION_HISTORY_ID, :EVALUATION_DATETIME, :STATUS)";
                    command.Parameters.Add(new NpgsqlParameter("DRIVING_INFO_ID", NpgsqlTypes.NpgsqlDbType.Integer)).Value = drivingInfoId;
                    command.Parameters.Add(new NpgsqlParameter("EVALUATION_IMPLEMENTATION_HISTORY_ID", NpgsqlTypes.NpgsqlDbType.Integer)).Value = evaluationImplementationHistoryId;
                    command.Parameters.Add(new NpgsqlParameter("EVALUATION_DATETIME", NpgsqlTypes.NpgsqlDbType.Timestamp)).Value = evaluationDatetime;
                    command.Parameters.Add(new NpgsqlParameter("STATUS", NpgsqlTypes.NpgsqlDbType.Smallint)).Value = status;

                    // SQLの実行
                    executeInsert(command);
                }
                catch (Exception exception)
                {
                    Console.WriteLine(exception.Message);
                    return false;
                }
            }

            return true;
        }

        #region DataSet executeUpdate(string strSql)
        /// <summary>
        /// 引数で指定されたSQLでUPDATEを実行します。
        /// </summary>
        /// <param name="command">実行するSQLを指定します。</param>
        /// <returns>SQL実行結果を返します。</returns>
        private void executeUpdate(NpgsqlCommand command)
        {
            // 接続準備
            using (var connection = new NpgsqlConnection(connectionString))
            {
                try
                {
                    // データベースの接続開始
                    connection.Open();

                    // INSERTを実行
                    command.Connection = connection;
                    command.ExecuteNonQuery();
                }
                catch (System.Net.Sockets.SocketException e)
                {
                    Console.WriteLine(e.Message);
                    //DB接続失敗時、処理中止のため、親にも通知する
                    throw;
                }
                catch (ArgumentException e)
                {
                    Console.WriteLine(e.Message);
                    //DB接続失敗時、処理中止のため、親にも通知する
                    throw;
                }
                catch (PostgresException e)
                {
                    Console.WriteLine(e.Message);
                }
            }
        }
        #endregion

        /// <summary>
        /// 評価実施履歴テーブルのデータを更新する
        /// </summary>
        /// <param name="drivingInfoId">走行基本情報ID検索キー</param>
        /// <param name="evaluationImplementationHistoryId">評価実施履歴ID検索キー</param>
        /// <param name="evaluationDatetime">更新対象の評価実施日時</param>
        /// <param name="status">更新対象のステータス</param>
        /// <returns>ture:成功、false:失敗</returns>
        /// <remarks>保存されている評価の履歴を更新するためのトランザクションテーブル</remarks>
        public bool UpdateEvaluationImplementationHistory(int drivingInfoId, int evaluationImplementationHistoryId, DateTime evaluationDatetime, DatabaseAccessor.EvaluationStatus status)
        {
            // 接続準備
            using (var command = new NpgsqlCommand())
            {
                try
                {
                    // SQLの準備
                    command.CommandText = @"UPDATE EVALUATION_IMPLEMENTATION_HISTORY_T";
                    command.CommandText += @" SET EVALUATION_DATETIME = :EVALUATION_DATETIME,";
                    command.CommandText += @"     STATUS = :STATUS";
                    command.CommandText += @" WHERE DRIVING_INFO_ID = :DRIVING_INFO_ID AND";
                    command.CommandText += @"       EVALUATION_IMPLEMENTATION_HISTORY_ID = :EVALUATION_IMPLEMENTATION_HISTORY_ID";
                    command.Parameters.Add(new NpgsqlParameter("DRIVING_INFO_ID", NpgsqlTypes.NpgsqlDbType.Integer)).Value = drivingInfoId;
                    command.Parameters.Add(new NpgsqlParameter("EVALUATION_IMPLEMENTATION_HISTORY_ID", NpgsqlTypes.NpgsqlDbType.Integer)).Value = evaluationImplementationHistoryId;
                    command.Parameters.Add(new NpgsqlParameter("EVALUATION_DATETIME", NpgsqlTypes.NpgsqlDbType.Timestamp)).Value = evaluationDatetime;
                    command.Parameters.Add(new NpgsqlParameter("STATUS", NpgsqlTypes.NpgsqlDbType.Smallint)).Value = status;

                    // SQLの実行
                    executeUpdate(command);
                }
                catch (Exception exception)
                {
                    Console.WriteLine(exception.Message);
                    return false;
                }
            }

            return true;
        }

        #region DataSet executeCreate(string strSql)
        /// <summary>
        /// 引数で指定されたSQLでCREATEを実行します。
        /// </summary>
        /// <param name="command">実行するSQLを指定します。</param>
        /// <returns>SQL実行結果を返します。</returns>
        private DataSet executeCreate(NpgsqlCommand command)
        {
            // 接続準備
            using (var connection = new NpgsqlConnection(connectionString))
            {
                // DataSetを生成
                using (var dataSet = new DataSet())
                {
                    dataSet.Locale = CultureInfo.InvariantCulture;
                    try
                    {
                        // データベースの接続開始
                        connection.Open();

                        // SELECTを実行
                        command.Connection = connection;
                        using (var dataAdapter = new NpgsqlDataAdapter(command))
                        {
                            try
                            {
                                dataAdapter.Fill(dataSet);
                            }
                            catch (System.InvalidOperationException e)
                            {
                                Console.WriteLine(e.ToString());
                            }
                            catch (PostgresException e)
                            {
                                Console.WriteLine(e.ToString());
                            }
                            catch (OverflowException e)
                            {
                                Console.WriteLine(e.ToString());
                            }
                        }
                    }
                    catch (System.Net.Sockets.SocketException e)
                    {
                        Console.WriteLine(e.Message);
                        //DB接続失敗時、処理中止のため、親にも通知する
                        throw;
                    }
                    catch (ArgumentException e)
                    {
                        Console.WriteLine(e.Message);
                        //DB接続失敗時、処理中止のため、親にも通知する
                        throw;
                    }
                    catch (PostgresException e)
                    {
                        Console.WriteLine(e.Message);
                    }
                    return dataSet;
                }
            }
        }
        #endregion

        /// <summary>
        /// 走行基本情報テーブルを生成する
        /// </summary>
        /// <remarks>すでにあるテーブルを破棄し、新しいテーブルを作成する</remarks>
        public bool CreateDrivingInfo()
        {
            // 接続準備
            using (var command = new NpgsqlCommand())
            {
                try
                {
                    // SQLの準備
                    command.CommandText  = @"DROP TABLE IF EXISTS DRIVING_INFO_T;";
                    command.CommandText += @"CREATE TABLE DRIVING_INFO_T(";
                    command.CommandText += @"  DRIVING_INFO_ID integer NOT NULL,";
                    command.CommandText += @"  PREFECTURE_ID smallint,";
                    command.CommandText += @"  ROUTE_NUM smallint,";
                    command.CommandText += @"  DRIVING_DATETIME timestamp  NOT NULL,";
                    command.CommandText += @"  SPECIFICATION_VERSION smallint,";
                    command.CommandText += @"PRIMARY KEY(DRIVING_INFO_ID";
                    command.CommandText += @"));";

                    // SQLの実行
                    executeCreate(command);
                }
                catch (Exception exception)
                {
                    Console.WriteLine(exception.Message);
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// 路線信号基本情報テーブルを生成する
        /// </summary>
        /// <remarks>すでにあるテーブルを破棄し、新しいテーブルを作成する</remarks>
        public bool CreateRouteSignalInfo()
        {
            // 接続準備
            using (var command = new NpgsqlCommand())
            {
                try
                {
                    // SQLの準備
                    command.CommandText  = @"DROP TABLE IF EXISTS ROUTE_SIGNAL_INFO_T;";
                    command.CommandText += @"CREATE TABLE ROUTE_SIGNAL_INFO_T(";
                    command.CommandText += @"  DRIVING_INFO_ID integer NOT NULL,";
                    command.CommandText += @"  EVALUATION_SPECIFICATION_ID integer NOT NULL,";
                    command.CommandText += @"  INTEGER_VALUE integer,";
                    command.CommandText += @"  JUDGMENT boolean,";
                    command.CommandText += @"PRIMARY KEY(DRIVING_INFO_ID, EVALUATION_SPECIFICATION_ID";
                    command.CommandText += @"));";

                    // SQLの実行
                    executeCreate(command);
                }
                catch (Exception exception)
                {
                    Console.WriteLine(exception.Message);
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// 交差点路線信号情報テーブルを生成する
        /// </summary>
        /// <remarks>すでにあるテーブルを破棄し、新しいテーブルを作成する</remarks>
        public bool CreateIntersectionRouteSignalInfo()
        {
            // 接続準備
            using (var command = new NpgsqlCommand())
            {
                try
                {
                    // SQLの準備
                    command.CommandText  = @"DROP TABLE IF EXISTS INTERSECTION_ROUTE_SIGNAL_INFO_T;";
                    command.CommandText += @"CREATE TABLE INTERSECTION_ROUTE_SIGNAL_INFO_T(";
                    command.CommandText += @"  DRIVING_INFO_ID integer,";
                    command.CommandText += @"  INTERSECTION_ROUTE_SIGNAL_INFO_ID integer,";
                    command.CommandText += @"  EVALUATION_SPECIFICATION_ID integer,";
                    command.CommandText += @"  VALUE_TYPE smallint,";
                    command.CommandText += @"  INTEGER_VALUE integer,";
                    command.CommandText += @"  DECIMAL_VALUE decimal(9,6),";
                    command.CommandText += @"  JUDGMENT boolean,";
                    command.CommandText += @"PRIMARY KEY(DRIVING_INFO_ID, INTERSECTION_ROUTE_SIGNAL_INFO_ID, EVALUATION_SPECIFICATION_ID";
                    command.CommandText += @"));";

                    // SQLの実行
                    executeCreate(command);
                }
                catch (Exception exception)
                {
                    Console.WriteLine(exception.Message);
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// サイクル情報テーブルを生成する
        /// </summary>
        /// <remarks>すでにあるテーブルを破棄し、新しいテーブルを作成する</remarks>
        public bool CreateCycleInfo()
        {
            // 接続準備
            using (var command = new NpgsqlCommand())
            {
                try
                {
                    // SQLの準備
                    command.CommandText  = @"DROP TABLE IF EXISTS CYCLE_INFO_T;";
                    command.CommandText += @"CREATE TABLE CYCLE_INFO_T(";
                    command.CommandText += @"  DRIVING_INFO_ID integer,";
                    command.CommandText += @"  INTERSECTION_ROUTE_SIGNAL_INFO_ID integer,";
                    command.CommandText += @"  CYCLE_INFO_ID integer,";
                    command.CommandText += @"  EVALUATION_SPECIFICATION_ID integer,";
                    command.CommandText += @"  INTEGER_VALUE integer,";
                    command.CommandText += @"  JUDGMENT boolean,";
                    command.CommandText += @"PRIMARY KEY(DRIVING_INFO_ID, INTERSECTION_ROUTE_SIGNAL_INFO_ID, CYCLE_INFO_ID, EVALUATION_SPECIFICATION_ID";
                    command.CommandText += @"));";

                    // SQLの実行
                    executeCreate(command);
                }
                catch (Exception exception)
                {
                    Console.WriteLine(exception.Message);
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// 世代テーブルを生成する
        /// </summary>
        /// <remarks>すでにあるテーブルを破棄し、新しいテーブルを作成する</remarks>
        public bool CreateGeneration()
        {
            // 接続準備
            using (var command = new NpgsqlCommand())
            {
                try
                {
                    // SQLの準備
                    command.CommandText  = @"DROP TABLE IF EXISTS GENERATION_T;";
                    command.CommandText += @"CREATE TABLE GENERATION_T(";
                    command.CommandText += @"  DRIVING_INFO_ID integer NOT NULL,";
                    command.CommandText += @"  GENERATION_ID smallint NOT NULL,";
                    command.CommandText += @"  EVALUATION_SPECIFICATION_ID integer NOT NULL,";
                    command.CommandText += @"  INTEGER_VALUE integer,";
                    command.CommandText += @"  JUDGMENT boolean,";
                    command.CommandText += @"PRIMARY KEY(DRIVING_INFO_ID, GENERATION_ID, EVALUATION_SPECIFICATION_ID";
                    command.CommandText += @"));";

                    // SQLの実行
                    executeCreate(command);
                }
                catch (Exception exception)
                {
                    Console.WriteLine(exception.Message);
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// UTMSリンクテーブルを生成する
        /// </summary>
        /// <remarks>すでにあるテーブルを破棄し、新しいテーブルを作成する</remarks>
        public bool CreateUTMSLink()
        {
            // 接続準備
            using (var command = new NpgsqlCommand())
            {
                try
                {
                    // SQLの準備
                    command.CommandText  = @"DROP TABLE IF EXISTS UTMS_LINK_T;";
                    command.CommandText += @"CREATE TABLE UTMS_LINK_T(";
                    command.CommandText += @"  DRIVING_INFO_ID integer NOT NULL,";
                    command.CommandText += @"  GENERATION_ID smallint NOT NULL,";
                    command.CommandText += @"  UTMS_LINK_ID smallint NOT NULL,";
                    command.CommandText += @"  EVALUATION_SPECIFICATION_ID integer NOT NULL,";
                    command.CommandText += @"  INTEGER_VALUE integer,";
                    command.CommandText += @"  JUDGMENT boolean,";
                    command.CommandText += @"PRIMARY KEY(DRIVING_INFO_ID, GENERATION_ID, UTMS_LINK_ID, EVALUATION_SPECIFICATION_ID";
                    command.CommandText += @"));";

                    // SQLの実行
                    executeCreate(command);
                }
                catch (Exception exception)
                {
                    Console.WriteLine(exception.Message);
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// 評価実施履歴テーブルを生成する
        /// </summary>
        /// <remarks>すでにあるテーブルを破棄し、新しいテーブルを作成する</remarks>
        public bool CreateEvaluationImplementationHistory()
        {
            // 接続準備
            using (var command = new NpgsqlCommand())
            {
                try
                {
                    // SQLの準備
                    command.CommandText = @"DROP TABLE IF EXISTS EVALUATION_IMPLEMENTATION_HISTORY_T;";
                    command.CommandText += @"CREATE TABLE EVALUATION_IMPLEMENTATION_HISTORY_T(";
                    command.CommandText += @"  DRIVING_INFO_ID integer NOT NULL,";
                    command.CommandText += @"  EVALUATION_IMPLEMENTATION_HISTORY_ID integer NOT NULL,";
                    command.CommandText += @"  EVALUATION_DATETIME timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,";
                    command.CommandText += @"  STATUS smallint,";
                    command.CommandText += @"PRIMARY KEY(DRIVING_INFO_ID, EVALUATION_IMPLEMENTATION_HISTORY_ID";
                    command.CommandText += @"));";

                    // SQLの実行
                    executeCreate(command);
                }
                catch (Exception exception)
                {
                    Console.WriteLine(exception.Message);
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// 評価結果Csvファイル出力情報リストを取得する
        /// </summary>
        /// <param name="drivinginfoId">走行基本情報ID</param>
        /// <param name="csvEvaluatResultInfos">[out] 評価結果Csvファイル出力情報リスト</param>
        /// <returns>true:成功,false:失敗</returns>
        public bool GetCsvEvaluatResultInfo(int drivinginfoId, CsvEvalResGetDataType type, out List<StCsvEvaluatResultInfo> csvEvaluatResultInfos )
        {
            // 評価結果Csvファイル出力情報構造体を生成
            csvEvaluatResultInfos = new List<StCsvEvaluatResultInfo>();

            using (var command = new NpgsqlCommand())
            {
                try
                {
                    // ①路線信号基本情報の取得
                    if (type == CsvEvalResGetDataType.RouteSignal_Info)
                    {
                        // SQL準備
                        command.CommandText = @"SELECT ";
                        command.CommandText += @"RSI.EVALUATION_SPECIFICATION_ID,";
                        command.CommandText += @"I_M.OUTPUT_STRING,";
                        command.CommandText += @"ES_M.EVALUATION_ITEM,";
                        command.CommandText += @"JT_M.JUDGMENT_TYPE,";
                        command.CommandText += @"SPS_M.SPECIFICATION_PROVIDING_SOURCE,";
                        command.CommandText += @"RSI.JUDGMENT,";
                        command.CommandText += @"RSI.INTEGER_VALUE,";
                        command.CommandText += @"IES.ITEM_ID";
                        command.CommandText += @" FROM ";
                        command.CommandText += @" ROUTE_SIGNAL_INFO_T AS RSI";
                        command.CommandText += @"  LEFT JOIN EVALUATION_SPECIFICATION_MASTER_T AS ES_M";
                        command.CommandText += @"   ON RSI.EVALUATION_SPECIFICATION_ID = ES_M.EVALUATION_SPECIFICATION_ID";
                        command.CommandText += @"    LEFT JOIN ITEM_EVALUATION_SPECIFICATION_T AS IES";
                        command.CommandText += @"     ON ES_M.EVALUATION_SPECIFICATION_ID = IES.EVALUATION_SPECIFICATION_ID";
                        command.CommandText += @"      LEFT JOIN ITEM_MASTER_T AS I_M";
                        command.CommandText += @"       ON IES.ITEM_ID = I_M.ITEM_ID";
                        command.CommandText += @"    LEFT JOIN EVALUATION_SPECIFICATION_JUDGMENT_TYPE_T AS ESJT";
                        command.CommandText += @"     ON ES_M.EVALUATION_SPECIFICATION_ID = ESJT.EVALUATION_SPECIFICATION_ID";
                        command.CommandText += @"      LEFT JOIN JUDGMENT_TYPE_MASTER_T AS JT_M";
                        command.CommandText += @"       ON ESJT.JUDGMENT_TYPE_ID = JT_M.JUDGMENT_TYPE_ID";
                        command.CommandText += @"    LEFT JOIN EVALUATION_SPECIFICATION_PROVIDING_SOURCE_T AS ESPS";
                        command.CommandText += @"     ON ES_M.EVALUATION_SPECIFICATION_ID = ESPS.EVALUATION_SPECIFICATION_ID";
                        command.CommandText += @"      LEFT JOIN SPECIFICATION_PROVIDING_SOURCE_MASTER_T AS SPS_M";
                        command.CommandText += @"       ON ESPS.SPECIFICATION_PROVIDING_SOURCE_ID = SPS_M.SPECIFICATION_PROVIDING_SOURCE_ID";
                        command.CommandText += @" WHERE ";
                        command.CommandText += @" RSI.DRIVING_INFO_ID = " + drivinginfoId.ToString();
                        command.CommandText += @" ORDER BY ";
                        command.CommandText += @" RSI.DRIVING_INFO_ID ASC,";
                        command.CommandText += @" RSI.EVALUATION_SPECIFICATION_ID";
                        command.CommandText += @";";
                    }
                    else if (type == CsvEvalResGetDataType.Intersection_Info)
                    {
                        // ②交差点路線信号情報の取得
                        command.CommandText = @"SELECT ";
                        command.CommandText += @" IRSI.EVALUATION_SPECIFICATION_ID,";
                        command.CommandText += @" IRSI.INTERSECTION_ROUTE_SIGNAL_INFO_ID,";
                        command.CommandText += @" I_M.OUTPUT_STRING,";
                        command.CommandText += @" ES_M.EVALUATION_ITEM,";
                        command.CommandText += @" JT_M.JUDGMENT_TYPE,";
                        command.CommandText += @" SPS_M.SPECIFICATION_PROVIDING_SOURCE,";
                        command.CommandText += @" IRSI.JUDGMENT,";
                        command.CommandText += @" IRSI.INTEGER_VALUE,";
                        command.CommandText += @" IES.ITEM_ID";
                        command.CommandText += @" FROM ";
                        command.CommandText += @" INTERSECTION_ROUTE_SIGNAL_INFO_T AS IRSI";
                        command.CommandText += @"  LEFT JOIN EVALUATION_SPECIFICATION_MASTER_T AS ES_M";
                        command.CommandText += @"   ON IRSI.EVALUATION_SPECIFICATION_ID = ES_M.EVALUATION_SPECIFICATION_ID";
                        command.CommandText += @"    LEFT JOIN ITEM_EVALUATION_SPECIFICATION_T AS IES";
                        command.CommandText += @"     ON ES_M.EVALUATION_SPECIFICATION_ID = IES.EVALUATION_SPECIFICATION_ID";
                        command.CommandText += @"      LEFT JOIN ITEM_MASTER_T AS I_M";
                        command.CommandText += @"       ON IES.ITEM_ID = I_M.ITEM_ID";
                        command.CommandText += @"    LEFT JOIN EVALUATION_SPECIFICATION_JUDGMENT_TYPE_T AS ESJT";
                        command.CommandText += @"     ON ES_M.EVALUATION_SPECIFICATION_ID = ESJT.EVALUATION_SPECIFICATION_ID";
                        command.CommandText += @"      LEFT JOIN JUDGMENT_TYPE_MASTER_T AS JT_M";
                        command.CommandText += @"       ON ESJT.JUDGMENT_TYPE_ID = JT_M.JUDGMENT_TYPE_ID";
                        command.CommandText += @"    LEFT JOIN EVALUATION_SPECIFICATION_PROVIDING_SOURCE_T AS ESPS";
                        command.CommandText += @"     ON ES_M.EVALUATION_SPECIFICATION_ID = ESPS.EVALUATION_SPECIFICATION_ID";
                        command.CommandText += @"      LEFT JOIN SPECIFICATION_PROVIDING_SOURCE_MASTER_T AS SPS_M";
                        command.CommandText += @"       ON ESPS.SPECIFICATION_PROVIDING_SOURCE_ID = SPS_M.SPECIFICATION_PROVIDING_SOURCE_ID ";
                        command.CommandText += @"WHERE ";
                        command.CommandText += @" IRSI.DRIVING_INFO_ID = " + drivinginfoId.ToString();
                        command.CommandText += @" AND IRSI.VALUE_TYPE = 0 ";
                        command.CommandText += @" ORDER BY";
                        command.CommandText += @" IRSI.DRIVING_INFO_ID ASC,";
                        command.CommandText += @" IRSI.INTERSECTION_ROUTE_SIGNAL_INFO_ID ASC,";
                        command.CommandText += @" IRSI.EVALUATION_SPECIFICATION_ID ASC";
                        command.CommandText += @";";
                    }
                    else if (type == CsvEvalResGetDataType.Cycle_Info)
                    {
                        // ③サイクル情報の取得
                        command.CommandText = @"SELECT ";
                        command.CommandText += @" CI.EVALUATION_SPECIFICATION_ID,";
                        command.CommandText += @" CI.INTERSECTION_ROUTE_SIGNAL_INFO_ID,";
                        command.CommandText += @" CI.CYCLE_INFO_ID,";
                        command.CommandText += @" I_M.OUTPUT_STRING,";
                        command.CommandText += @" ES_M.EVALUATION_ITEM,";
                        command.CommandText += @" JT_M.JUDGMENT_TYPE,";
                        command.CommandText += @" SPS_M.SPECIFICATION_PROVIDING_SOURCE,";
                        command.CommandText += @" CI.JUDGMENT,";
                        command.CommandText += @" CI.INTEGER_VALUE,";
                        command.CommandText += @" IES.ITEM_ID ";
                        command.CommandText += @"FROM ";
                        command.CommandText += @" CYCLE_INFO_T AS CI";
                        command.CommandText += @"  LEFT JOIN EVALUATION_SPECIFICATION_MASTER_T AS ES_M";
                        command.CommandText += @"   ON CI.EVALUATION_SPECIFICATION_ID = ES_M.EVALUATION_SPECIFICATION_ID";
                        command.CommandText += @"    LEFT JOIN ITEM_EVALUATION_SPECIFICATION_T AS IES";
                        command.CommandText += @"     ON ES_M.EVALUATION_SPECIFICATION_ID = IES.EVALUATION_SPECIFICATION_ID";
                        command.CommandText += @"      LEFT JOIN ITEM_MASTER_T AS I_M";
                        command.CommandText += @"       ON IES.ITEM_ID = I_M.ITEM_ID";
                        command.CommandText += @"    LEFT JOIN EVALUATION_SPECIFICATION_JUDGMENT_TYPE_T AS ESJT";
                        command.CommandText += @"     ON ES_M.EVALUATION_SPECIFICATION_ID = ESJT.EVALUATION_SPECIFICATION_ID";
                        command.CommandText += @"      LEFT JOIN JUDGMENT_TYPE_MASTER_T AS JT_M";
                        command.CommandText += @"       ON ESJT.JUDGMENT_TYPE_ID = JT_M.JUDGMENT_TYPE_ID";
                        command.CommandText += @"    LEFT JOIN EVALUATION_SPECIFICATION_PROVIDING_SOURCE_T AS ESPS";
                        command.CommandText += @"     ON ES_M.EVALUATION_SPECIFICATION_ID = ESPS.EVALUATION_SPECIFICATION_ID";
                        command.CommandText += @"      LEFT JOIN SPECIFICATION_PROVIDING_SOURCE_MASTER_T AS SPS_M";
                        command.CommandText += @"       ON ESPS.SPECIFICATION_PROVIDING_SOURCE_ID = SPS_M.SPECIFICATION_PROVIDING_SOURCE_ID ";
                        command.CommandText += @"WHERE ";
                        command.CommandText += @" CI.DRIVING_INFO_ID = " + drivinginfoId.ToString();
                        command.CommandText += @" ORDER BY";
                        command.CommandText += @" CI.DRIVING_INFO_ID ASC,";
                        command.CommandText += @" CI.INTERSECTION_ROUTE_SIGNAL_INFO_ID ASC,";
                        command.CommandText += @" CI.CYCLE_INFO_ID ASC,";
                        command.CommandText += @" CI.EVALUATION_SPECIFICATION_ID ASC";
                        command.CommandText += @";";
                    }
                    else if (type == CsvEvalResGetDataType.Generation_Info)
                    {
                        // ④世代の取得
                        command.CommandText = @"SELECT ";
                        command.CommandText += @" G.EVALUATION_SPECIFICATION_ID,";
                        command.CommandText += @" G.GENERATION_ID,";
                        command.CommandText += @" I_M.OUTPUT_STRING,";
                        command.CommandText += @" ES_M.EVALUATION_ITEM,";
                        command.CommandText += @" JT_M.JUDGMENT_TYPE,";
                        command.CommandText += @" SPS_M.SPECIFICATION_PROVIDING_SOURCE,";
                        command.CommandText += @" G.JUDGMENT,";
                        command.CommandText += @" G.INTEGER_VALUE,";
                        command.CommandText += @" IES.ITEM_ID ";
                        command.CommandText += @"FROM ";
                        command.CommandText += @" GENERATION_T AS G";
                        command.CommandText += @"  LEFT JOIN EVALUATION_SPECIFICATION_MASTER_T AS ES_M";
                        command.CommandText += @"   ON G.EVALUATION_SPECIFICATION_ID = ES_M.EVALUATION_SPECIFICATION_ID";
                        command.CommandText += @"    LEFT JOIN ITEM_EVALUATION_SPECIFICATION_T AS IES";
                        command.CommandText += @"     ON ES_M.EVALUATION_SPECIFICATION_ID = IES.EVALUATION_SPECIFICATION_ID";
                        command.CommandText += @"      LEFT JOIN ITEM_MASTER_T AS I_M";
                        command.CommandText += @"       ON IES.ITEM_ID = I_M.ITEM_ID";
                        command.CommandText += @"    LEFT JOIN EVALUATION_SPECIFICATION_JUDGMENT_TYPE_T AS ESJT";
                        command.CommandText += @"     ON ES_M.EVALUATION_SPECIFICATION_ID = ESJT.EVALUATION_SPECIFICATION_ID";
                        command.CommandText += @"      LEFT JOIN JUDGMENT_TYPE_MASTER_T AS JT_M";
                        command.CommandText += @"       ON ESJT.JUDGMENT_TYPE_ID = JT_M.JUDGMENT_TYPE_ID";
                        command.CommandText += @"    LEFT JOIN EVALUATION_SPECIFICATION_PROVIDING_SOURCE_T AS ESPS";
                        command.CommandText += @"     ON ES_M.EVALUATION_SPECIFICATION_ID = ESPS.EVALUATION_SPECIFICATION_ID";
                        command.CommandText += @"      LEFT JOIN SPECIFICATION_PROVIDING_SOURCE_MASTER_T AS SPS_M";
                        command.CommandText += @"       ON ESPS.SPECIFICATION_PROVIDING_SOURCE_ID = SPS_M.SPECIFICATION_PROVIDING_SOURCE_ID ";
                        command.CommandText += @"WHERE ";
                        command.CommandText += @" G.DRIVING_INFO_ID = " + drivinginfoId.ToString();
                        command.CommandText += @" ORDER BY";
                        command.CommandText += @" G.DRIVING_INFO_ID ASC,";
                        command.CommandText += @" G.GENERATION_ID ASC,";
                        command.CommandText += @" G.EVALUATION_SPECIFICATION_ID ASC";
                        command.CommandText += @";";
                    }
                    else if (type == CsvEvalResGetDataType.UtmsLink_Info)
                    {
                        // ⑤UTMSリンクの取得
                        command.CommandText = @"SELECT ";
                        command.CommandText += @" UL.EVALUATION_SPECIFICATION_ID,";
                        command.CommandText += @" UL.GENERATION_ID,";
                        command.CommandText += @" UL.UTMS_LINK_ID,";
                        command.CommandText += @" I_M.OUTPUT_STRING,";
                        command.CommandText += @" ES_M.EVALUATION_ITEM,";
                        command.CommandText += @" JT_M.JUDGMENT_TYPE,";
                        command.CommandText += @" SPS_M.SPECIFICATION_PROVIDING_SOURCE,";
                        command.CommandText += @" UL.JUDGMENT,";
                        command.CommandText += @" UL.INTEGER_VALUE,";
                        command.CommandText += @" IES.ITEM_ID ";
                        command.CommandText += @"FROM ";
                        command.CommandText += @" UTMS_LINK_T AS UL";
                        command.CommandText += @"  LEFT JOIN EVALUATION_SPECIFICATION_MASTER_T AS ES_M";
                        command.CommandText += @"   ON UL.EVALUATION_SPECIFICATION_ID = ES_M.EVALUATION_SPECIFICATION_ID";
                        command.CommandText += @"    LEFT JOIN ITEM_EVALUATION_SPECIFICATION_T AS IES";
                        command.CommandText += @"     ON ES_M.EVALUATION_SPECIFICATION_ID = IES.EVALUATION_SPECIFICATION_ID";
                        command.CommandText += @"      LEFT JOIN ITEM_MASTER_T AS I_M";
                        command.CommandText += @"       ON IES.ITEM_ID = I_M.ITEM_ID";
                        command.CommandText += @"    LEFT JOIN EVALUATION_SPECIFICATION_JUDGMENT_TYPE_T AS ESJT";
                        command.CommandText += @"     ON ES_M.EVALUATION_SPECIFICATION_ID = ESJT.EVALUATION_SPECIFICATION_ID";
                        command.CommandText += @"      LEFT JOIN JUDGMENT_TYPE_MASTER_T AS JT_M";
                        command.CommandText += @"       ON ESJT.JUDGMENT_TYPE_ID = JT_M.JUDGMENT_TYPE_ID";
                        command.CommandText += @"    LEFT JOIN EVALUATION_SPECIFICATION_PROVIDING_SOURCE_T AS ESPS";
                        command.CommandText += @"     ON ES_M.EVALUATION_SPECIFICATION_ID = ESPS.EVALUATION_SPECIFICATION_ID";
                        command.CommandText += @"      LEFT JOIN SPECIFICATION_PROVIDING_SOURCE_MASTER_T AS SPS_M";
                        command.CommandText += @"       ON ESPS.SPECIFICATION_PROVIDING_SOURCE_ID = SPS_M.SPECIFICATION_PROVIDING_SOURCE_ID";
                        command.CommandText += @" WHERE ";
                        command.CommandText += @" UL.DRIVING_INFO_ID = " + drivinginfoId.ToString();
                        command.CommandText += @" ORDER BY";
                        command.CommandText += @" UL.DRIVING_INFO_ID ASC,";
                        command.CommandText += @" UL.GENERATION_ID ASC,";
                        command.CommandText += @" UL.UTMS_LINK_ID ASC,";
                        command.CommandText += @" UL.EVALUATION_SPECIFICATION_ID ASC";
                        command.CommandText += @";";

                    }

                    // SQL実行
                    var dataSet = executeSelect(command);

                    if (type == CsvEvalResGetDataType.RouteSignal_Info)
                    {
                        // 最初に見つかった行から評価結果Csvファイル出力情報データを抜き出す
                        foreach (DataRow row in dataSet.Tables[0].Rows)
                        {
                            var r = dataSet.Tables[0].Rows;
                            var rr = dataSet.Tables[0].Rows[0];
                            var csvEvaluatResultInfo = new StCsvEvaluatResultInfo();
                            getValueFromDataSet(row[0], out csvEvaluatResultInfo.EvalSpecId);            // 評価仕様ID
                            getValueFromDataSet(row[1], out csvEvaluatResultInfo.Item);                  // 項目
                            getValueFromDataSet(row[2], out csvEvaluatResultInfo.Specification);         // 仕様
                            getValueFromDataSet(row[3], out csvEvaluatResultInfo.Category);              // チェック分類
                            getValueFromDataSet(row[4], out csvEvaluatResultInfo.SpecificationSource);   // 仕様提供元
                            getValueFromDataSet(row[5], out csvEvaluatResultInfo.Judge);                 // 判定
                            getValueFromDataSet(row[6], out csvEvaluatResultInfo.Value);                 // 値
                            getValueFromDataSet(row[7], out csvEvaluatResultInfo.ItemId);                // 項目ID
                            csvEvaluatResultInfo.BelongingId_1 = 0;                                      // 所属ID_1
                            csvEvaluatResultInfo.BelongingId_2 = 0;                                      // 所属ID_2
                            csvEvaluatResultInfos.Add(csvEvaluatResultInfo);
                        }
                    }else if( ( type == CsvEvalResGetDataType.Intersection_Info ) || ( type == CsvEvalResGetDataType.Generation_Info ) )
                    {
                        // 最初に見つかった行から評価結果Csvファイル出力情報データを抜き出す
                        foreach (DataRow row in dataSet.Tables[0].Rows)
                        {
                            var r = dataSet.Tables[0].Rows;
                            var rr = dataSet.Tables[0].Rows[0];
                            var csvEvaluatResultInfo = new StCsvEvaluatResultInfo();
                            getValueFromDataSet(row[0], out csvEvaluatResultInfo.EvalSpecId);            // 評価仕様ID
                            getValueFromDataSet(row[1], out csvEvaluatResultInfo.BelongingId_1);         // 所属ID_1(交差点路線信号情報ID or 世代ID )
                            getValueFromDataSet(row[2], out csvEvaluatResultInfo.Item);                  // 項目
                            getValueFromDataSet(row[3], out csvEvaluatResultInfo.Specification);         // 仕様
                            getValueFromDataSet(row[4], out csvEvaluatResultInfo.Category);              // チェック分類
                            getValueFromDataSet(row[5], out csvEvaluatResultInfo.SpecificationSource);   // 仕様提供元
                            getValueFromDataSet(row[6], out csvEvaluatResultInfo.Judge);                 // 判定
                            getValueFromDataSet(row[7], out csvEvaluatResultInfo.Value);                 // 値
                            getValueFromDataSet(row[8], out csvEvaluatResultInfo.ItemId);                // 項目ID
                            csvEvaluatResultInfo.BelongingId_2 = 0;                                      // 所属ID_2
                            csvEvaluatResultInfos.Add(csvEvaluatResultInfo);
                        }
                    }else if ((type == CsvEvalResGetDataType.Cycle_Info) || (type == CsvEvalResGetDataType.UtmsLink_Info) )
                    {
                        // 最初に見つかった行から評価結果Csvファイル出力情報データを抜き出す
                        foreach (DataRow row in dataSet.Tables[0].Rows)
                        {
                            var r = dataSet.Tables[0].Rows;
                            var rr = dataSet.Tables[0].Rows[0];
                            var csvEvaluatResultInfo = new StCsvEvaluatResultInfo();
                            getValueFromDataSet(row[0], out csvEvaluatResultInfo.EvalSpecId);            // 評価仕様ID
                            getValueFromDataSet(row[1], out csvEvaluatResultInfo.BelongingId_1);         // 所属ID_1(交差点路線信号情報ID or 世代ID )
                            getValueFromDataSet(row[2], out csvEvaluatResultInfo.BelongingId_2);         // 所属ID_2(サイクル情報ID or UTMSリンクID )
                            getValueFromDataSet(row[3], out csvEvaluatResultInfo.Item);                  // 項目
                            getValueFromDataSet(row[4], out csvEvaluatResultInfo.Specification);         // 仕様
                            getValueFromDataSet(row[5], out csvEvaluatResultInfo.Category);              // チェック分類
                            getValueFromDataSet(row[6], out csvEvaluatResultInfo.SpecificationSource);   // 仕様提供元
                            getValueFromDataSet(row[7], out csvEvaluatResultInfo.Judge);                 // 判定
                            getValueFromDataSet(row[8], out csvEvaluatResultInfo.Value);                 // 値
                            getValueFromDataSet(row[9], out csvEvaluatResultInfo.ItemId);                // 項目ID
                            csvEvaluatResultInfos.Add(csvEvaluatResultInfo);
                        }
                    }


                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    return false;
                }
            }
            return true;
        }

        /// <summary>
        /// カテゴリ別NG件数カウントを取得する
        /// </summary>
        /// <param name="drivinginfoId">走行基本情報ID</param>
        /// <param name="checktype">チェックカテゴリ</param>
        /// <returns>指定カテゴリNG数</returns>
        public int GetCsvCategoryNgCountInfo(int drivinginfoId, int checktype)
        {
            int resCnt = 0;
            int judgmenttypeid = 0;

            // CSV出力順序とチェックカテゴリの順序が一致していないため調整
            if(checktype == 1) { judgmenttypeid = 1; }
            else if (checktype == 2) { judgmenttypeid = 2; }
            else if (checktype == 3) { judgmenttypeid = 4; }
            else if (checktype == 4) { judgmenttypeid = 3; }

            using (var command = new NpgsqlCommand())
            {
                try
                {
                    // ①路線信号基本情報から
                    command.CommandText = @"SELECT ";
                    command.CommandText += @"COUNT(*) ";
                    command.CommandText += @"FROM ";
                    command.CommandText += @" ROUTE_SIGNAL_INFO_T AS RSI";
                    command.CommandText += @"  LEFT JOIN EVALUATION_SPECIFICATION_MASTER_T AS ES_M";
                    command.CommandText += @"   ON RSI.EVALUATION_SPECIFICATION_ID = ES_M.EVALUATION_SPECIFICATION_ID ";
                    command.CommandText += @"    LEFT JOIN ITEM_EVALUATION_SPECIFICATION_T AS IES ";
                    command.CommandText += @"     ON ES_M.EVALUATION_SPECIFICATION_ID = IES.EVALUATION_SPECIFICATION_ID ";
                    command.CommandText += @"      LEFT JOIN ITEM_MASTER_T AS I_M ";
                    command.CommandText += @"       ON IES.ITEM_ID = I_M.ITEM_ID ";
                    command.CommandText += @"    LEFT JOIN EVALUATION_SPECIFICATION_JUDGMENT_TYPE_T AS ESJT ";
                    command.CommandText += @"     ON ES_M.EVALUATION_SPECIFICATION_ID = ESJT.EVALUATION_SPECIFICATION_ID ";
                    command.CommandText += @"      LEFT JOIN JUDGMENT_TYPE_MASTER_T AS JT_M ";
                    command.CommandText += @"       ON ESJT.JUDGMENT_TYPE_ID = JT_M.JUDGMENT_TYPE_ID ";
                    command.CommandText += @"    LEFT JOIN EVALUATION_SPECIFICATION_PROVIDING_SOURCE_T AS ESPS ";
                    command.CommandText += @"     ON ES_M.EVALUATION_SPECIFICATION_ID = ESPS.EVALUATION_SPECIFICATION_ID ";
                    command.CommandText += @"      LEFT JOIN SPECIFICATION_PROVIDING_SOURCE_MASTER_T AS SPS_M ";
                    command.CommandText += @"       ON ESPS.SPECIFICATION_PROVIDING_SOURCE_ID = SPS_M.SPECIFICATION_PROVIDING_SOURCE_ID ";
                    command.CommandText += @"WHERE ";
                    command.CommandText += @" RSI.DRIVING_INFO_ID = " + drivinginfoId.ToString();
                    command.CommandText += @" AND RSI.JUDGMENT = FALSE ";
                    command.CommandText += @" AND JT_M.JUDGMENT_TYPE_ID = " + judgmenttypeid.ToString();
                    command.CommandText += @";";

                    // SQL実行
                    var dataSet = executeSelect(command);
                    int chkcnt;
                    // 最初に見つかった行からカテゴリ別NG件数を抜き出す
                    getValueFromDataSet(dataSet.Tables[0].Rows[0][0], out chkcnt);

                    resCnt = chkcnt;                    // 指定NG件数を格納

                    // ②交差点路線信号情報から
                    command.CommandText = @"SELECT ";
                    command.CommandText += @" COUNT(*) ";
                    command.CommandText += @"FROM  ";
                    command.CommandText += @" INTERSECTION_ROUTE_SIGNAL_INFO_T AS IRSI ";
                    command.CommandText += @"  LEFT JOIN EVALUATION_SPECIFICATION_MASTER_T AS ES_M ";
                    command.CommandText += @"   ON IRSI.EVALUATION_SPECIFICATION_ID = ES_M.EVALUATION_SPECIFICATION_ID ";
                    command.CommandText += @"    LEFT JOIN ITEM_EVALUATION_SPECIFICATION_T AS IES ";
                    command.CommandText += @"     ON ES_M.EVALUATION_SPECIFICATION_ID = IES.EVALUATION_SPECIFICATION_ID ";
                    command.CommandText += @"      LEFT JOIN ITEM_MASTER_T AS I_M ";
                    command.CommandText += @"       ON IES.ITEM_ID = I_M.ITEM_ID ";
                    command.CommandText += @"    LEFT JOIN EVALUATION_SPECIFICATION_JUDGMENT_TYPE_T AS ESJT ";
                    command.CommandText += @"     ON ES_M.EVALUATION_SPECIFICATION_ID = ESJT.EVALUATION_SPECIFICATION_ID ";
                    command.CommandText += @"      LEFT JOIN JUDGMENT_TYPE_MASTER_T AS JT_M ";
                    command.CommandText += @"       ON ESJT.JUDGMENT_TYPE_ID = JT_M.JUDGMENT_TYPE_ID ";
                    command.CommandText += @"    LEFT JOIN EVALUATION_SPECIFICATION_PROVIDING_SOURCE_T AS ESPS ";
                    command.CommandText += @"     ON ES_M.EVALUATION_SPECIFICATION_ID = ESPS.EVALUATION_SPECIFICATION_ID ";
                    command.CommandText += @"      LEFT JOIN SPECIFICATION_PROVIDING_SOURCE_MASTER_T AS SPS_M ";
                    command.CommandText += @"       ON ESPS.SPECIFICATION_PROVIDING_SOURCE_ID = SPS_M.SPECIFICATION_PROVIDING_SOURCE_ID ";
                    command.CommandText += @"WHERE  ";
                    command.CommandText += @" IRSI.DRIVING_INFO_ID = " + drivinginfoId.ToString();
                    command.CommandText += @" AND IRSI.VALUE_TYPE = 0 ";
                    command.CommandText += @" AND IRSI.JUDGMENT = FALSE ";
                    command.CommandText += @" AND JT_M.JUDGMENT_TYPE_ID =  " + judgmenttypeid.ToString();
                    command.CommandText += @";";
                    // SQL実行
                    dataSet = executeSelect(command);
                    // 最初に見つかった行からカテゴリ別NG件数を抜き出す
                    getValueFromDataSet(dataSet.Tables[0].Rows[0][0], out chkcnt);
                    resCnt += chkcnt;                    // 指定NG件数を格納

                    // ③サイクル情報から
                    command.CommandText = @"SELECT  ";
                    command.CommandText += @"  COUNT(*) ";
                    command.CommandText += @" FROM  ";
                    command.CommandText += @"  CYCLE_INFO_T AS CI ";
                    command.CommandText += @"   LEFT JOIN EVALUATION_SPECIFICATION_MASTER_T AS ES_M ";
                    command.CommandText += @"    ON CI.EVALUATION_SPECIFICATION_ID = ES_M.EVALUATION_SPECIFICATION_ID ";
                    command.CommandText += @"     LEFT JOIN ITEM_EVALUATION_SPECIFICATION_T AS IES ";
                    command.CommandText += @"      ON ES_M.EVALUATION_SPECIFICATION_ID = IES.EVALUATION_SPECIFICATION_ID ";
                    command.CommandText += @"       LEFT JOIN ITEM_MASTER_T AS I_M ";
                    command.CommandText += @"        ON IES.ITEM_ID = I_M.ITEM_ID ";
                    command.CommandText += @"     LEFT JOIN EVALUATION_SPECIFICATION_JUDGMENT_TYPE_T AS ESJT ";
                    command.CommandText += @"      ON ES_M.EVALUATION_SPECIFICATION_ID = ESJT.EVALUATION_SPECIFICATION_ID ";
                    command.CommandText += @"       LEFT JOIN JUDGMENT_TYPE_MASTER_T AS JT_M ";
                    command.CommandText += @"        ON ESJT.JUDGMENT_TYPE_ID = JT_M.JUDGMENT_TYPE_ID ";
                    command.CommandText += @"     LEFT JOIN EVALUATION_SPECIFICATION_PROVIDING_SOURCE_T AS ESPS ";
                    command.CommandText += @"      ON ES_M.EVALUATION_SPECIFICATION_ID = ESPS.EVALUATION_SPECIFICATION_ID ";
                    command.CommandText += @"       LEFT JOIN SPECIFICATION_PROVIDING_SOURCE_MASTER_T AS SPS_M ";
                    command.CommandText += @"        ON ESPS.SPECIFICATION_PROVIDING_SOURCE_ID = SPS_M.SPECIFICATION_PROVIDING_SOURCE_ID ";
                    command.CommandText += @" WHERE  ";
                    command.CommandText += @"  CI.DRIVING_INFO_ID = " + drivinginfoId.ToString();
                    command.CommandText += @"  AND CI.JUDGMENT = FALSE ";
                    command.CommandText += @"  AND JT_M.JUDGMENT_TYPE_ID = " + judgmenttypeid.ToString();
                    command.CommandText += @" ;";
                    // SQL実行
                    dataSet = executeSelect(command);
                    getValueFromDataSet(dataSet.Tables[0].Rows[0][0], out chkcnt);
                    resCnt += chkcnt;                    // 指定NG件数を格納

                    // ④世代情報から
                    command.CommandText = @"SELECT ";
                    command.CommandText += @"  COUNT(*)";
                    command.CommandText += @" FROM ";
                    command.CommandText += @"  GENERATION_T AS G";
                    command.CommandText += @"   LEFT JOIN EVALUATION_SPECIFICATION_MASTER_T AS ES_M";
                    command.CommandText += @"    ON G.EVALUATION_SPECIFICATION_ID = ES_M.EVALUATION_SPECIFICATION_ID";
                    command.CommandText += @"     LEFT JOIN ITEM_EVALUATION_SPECIFICATION_T AS IES";
                    command.CommandText += @"      ON ES_M.EVALUATION_SPECIFICATION_ID = IES.EVALUATION_SPECIFICATION_ID";
                    command.CommandText += @"       LEFT JOIN ITEM_MASTER_T AS I_M";
                    command.CommandText += @"        ON IES.ITEM_ID = I_M.ITEM_ID";
                    command.CommandText += @"     LEFT JOIN EVALUATION_SPECIFICATION_JUDGMENT_TYPE_T AS ESJT";
                    command.CommandText += @"      ON ES_M.EVALUATION_SPECIFICATION_ID = ESJT.EVALUATION_SPECIFICATION_ID";
                    command.CommandText += @"       LEFT JOIN JUDGMENT_TYPE_MASTER_T AS JT_M";
                    command.CommandText += @"        ON ESJT.JUDGMENT_TYPE_ID = JT_M.JUDGMENT_TYPE_ID";
                    command.CommandText += @"     LEFT JOIN EVALUATION_SPECIFICATION_PROVIDING_SOURCE_T AS ESPS";
                    command.CommandText += @"      ON ES_M.EVALUATION_SPECIFICATION_ID = ESPS.EVALUATION_SPECIFICATION_ID";
                    command.CommandText += @"       LEFT JOIN SPECIFICATION_PROVIDING_SOURCE_MASTER_T AS SPS_M";
                    command.CommandText += @"        ON ESPS.SPECIFICATION_PROVIDING_SOURCE_ID = SPS_M.SPECIFICATION_PROVIDING_SOURCE_ID";
                    command.CommandText += @" WHERE ";
                    command.CommandText += @"  G.DRIVING_INFO_ID = " + drivinginfoId.ToString();
                    command.CommandText += @"  AND G.JUDGMENT = FALSE";
                    command.CommandText += @"  AND JT_M.JUDGMENT_TYPE_ID = " + judgmenttypeid.ToString();
                    command.CommandText += @" ;";
                    // SQL実行
                    dataSet = executeSelect(command);
                    getValueFromDataSet(dataSet.Tables[0].Rows[0][0], out chkcnt);
                    resCnt += chkcnt;                    // 指定NG件数を格納

                    // ⑤UTMSリンク情報から
                    command.CommandText = @"SELECT ";
                    command.CommandText += @"  COUNT(*)";
                    command.CommandText += @" FROM ";
                    command.CommandText += @"  UTMS_LINK_T AS UL";
                    command.CommandText += @"   LEFT JOIN EVALUATION_SPECIFICATION_MASTER_T AS ES_M";
                    command.CommandText += @"    ON UL.EVALUATION_SPECIFICATION_ID = ES_M.EVALUATION_SPECIFICATION_ID";
                    command.CommandText += @"     LEFT JOIN ITEM_EVALUATION_SPECIFICATION_T AS IES";
                    command.CommandText += @"      ON ES_M.EVALUATION_SPECIFICATION_ID = IES.EVALUATION_SPECIFICATION_ID";
                    command.CommandText += @"       LEFT JOIN ITEM_MASTER_T AS I_M";
                    command.CommandText += @"        ON IES.ITEM_ID = I_M.ITEM_ID";
                    command.CommandText += @"     LEFT JOIN EVALUATION_SPECIFICATION_JUDGMENT_TYPE_T AS ESJT";
                    command.CommandText += @"      ON ES_M.EVALUATION_SPECIFICATION_ID = ESJT.EVALUATION_SPECIFICATION_ID";
                    command.CommandText += @"       LEFT JOIN JUDGMENT_TYPE_MASTER_T AS JT_M";
                    command.CommandText += @"        ON ESJT.JUDGMENT_TYPE_ID = JT_M.JUDGMENT_TYPE_ID";
                    command.CommandText += @"     LEFT JOIN EVALUATION_SPECIFICATION_PROVIDING_SOURCE_T AS ESPS";
                    command.CommandText += @"      ON ES_M.EVALUATION_SPECIFICATION_ID = ESPS.EVALUATION_SPECIFICATION_ID";
                    command.CommandText += @"       LEFT JOIN SPECIFICATION_PROVIDING_SOURCE_MASTER_T AS SPS_M";
                    command.CommandText += @"        ON ESPS.SPECIFICATION_PROVIDING_SOURCE_ID = SPS_M.SPECIFICATION_PROVIDING_SOURCE_ID";
                    command.CommandText += @" WHERE";
                    command.CommandText += @"  UL.DRIVING_INFO_ID = " + drivinginfoId.ToString();
                    command.CommandText += @"  AND UL.JUDGMENT = FALSE ";
                    command.CommandText += @"  AND JT_M.JUDGMENT_TYPE_ID = " + judgmenttypeid.ToString();
                    command.CommandText += @" ;";
                    // SQL実行
                    dataSet = executeSelect(command);
                    getValueFromDataSet(dataSet.Tables[0].Rows[0][0], out chkcnt);
                    resCnt += chkcnt;                    // 指定NG件数を格納
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    return resCnt;
                }
            }
            return resCnt;
        }

        /// <summary>
        /// 評価実施履歴Csvファイル出力情報リストを取得する
        /// </summary>
        /// <param name="csvEvaluatResultInfos">[out] 評価実施履歴Csvファイル出力情報リスト</param>
        /// <returns>true:成功,false:失敗</returns>
        public bool GetCsvEvaluationImplementationHistoryInfo(out List<StCsvEvaluationImplementationHistoryInfo> csvEvaluationImplementationHistoryInfos)
        {
            // 評価実施履歴Csvファイル出力情報構造体を生成
            csvEvaluationImplementationHistoryInfos = new List<StCsvEvaluationImplementationHistoryInfo>();

            using (var command = new NpgsqlCommand())
            {
                try
                {
                    // SQL準備
                    command.CommandText = @"SELECT ";
                    command.CommandText += @" PM.PREFECTURE_NAME, ";
                    command.CommandText += @" DI.ROUTE_NUM, ";
                    command.CommandText += @" DI.DRIVING_DATETIME, ";
                    command.CommandText += @" DI.SPECIFICATION_VERSION, ";
                    command.CommandText += @" EIH.EVALUATION_DATETIME, ";
                    command.CommandText += @" EIH.STATUS ";
                    command.CommandText += @"FROM ";
                    command.CommandText += @" EVALUATION_IMPLEMENTATION_HISTORY_T AS EIH ";
                    command.CommandText += @"  LEFT JOIN DRIVING_INFO_T AS DI ";
                    command.CommandText += @"   ON EIH.DRIVING_INFO_ID = DI.DRIVING_INFO_ID ";
                    command.CommandText += @"    LEFT JOIN PREFECTURE_MASTER_T AS PM ";
                    command.CommandText += @"     ON DI.PREFECTURE_ID = PM.PREFECTURE_ID ";
                    command.CommandText += @" WHERE ";
                    command.CommandText += @" EIH.STATUS > 1000 ";
                    command.CommandText += @";";

                    // SQL実行
                    var dataSet = executeSelect(command);
                    short tempValue1;
                    short tempValue2;

                    // 最初に見つかった行から評価結果Csvファイル出力情報データを抜き出す
                    foreach (DataRow row in dataSet.Tables[0].Rows)
                    {
                        var r = dataSet.Tables[0].Rows;
                        var rr = dataSet.Tables[0].Rows[0];
                        var csvEvaluationImplementationHistoryInfo = new StCsvEvaluationImplementationHistoryInfo();
                        getValueFromDataSet(row[0], out csvEvaluationImplementationHistoryInfo.PrefectureName);          // 都道府県名
                        getValueFromDataSet(row[1], out csvEvaluationImplementationHistoryInfo.RouteNum);                // 路線番号
                        getValueFromDataSet(row[2], out csvEvaluationImplementationHistoryInfo.DrivingDatetime);         // 走行時刻
                        getValueFromDataSet(row[3], out tempValue1);                                                     // 版
                        csvEvaluationImplementationHistoryInfo.SpecificationVersion = (EvaluationVersion)tempValue1;     
                        getValueFromDataSet(row[4], out csvEvaluationImplementationHistoryInfo.EvaluationDatetime);      // 評価時刻
                        getValueFromDataSet(row[5], out tempValue2);                                                     // ステータス
                        csvEvaluationImplementationHistoryInfo.Status = (EvaluationStatus)tempValue2; 
                        csvEvaluationImplementationHistoryInfos.Add(csvEvaluationImplementationHistoryInfo);
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    return false;
                }
            }
            return true;
        }

        public bool ALLcount(out StAllTableCount alltabelcount)
        {
            alltabelcount = new StAllTableCount();
            // 接続準備
            using (var command = new NpgsqlCommand())
            {
                try
                {
                    // SQLの準備
                    command.CommandText = @"SELECT COUNT(*) FROM PREFECTURE_MASTER_T;";
                    // SQL実行
                    var dataSet = executeSelect(command);
                    // 最初に見つかった行から走行基本情報データを抜き出す
                    var row = dataSet.Tables[0].Rows[0];
                    getValueFromDataSet(row[0], out alltabelcount.data1);

                    command.CommandText = @"SELECT COUNT(*) FROM ROUTE_INFO_MASTER_T;";
                    // SQL実行
                    dataSet = executeSelect(command);
                    // 最初に見つかった行から走行基本情報データを抜き出す
                    row = dataSet.Tables[0].Rows[0];
                    getValueFromDataSet(row[0], out alltabelcount.data2);

                    command.CommandText = @"SELECT COUNT(*) FROM INTERSECTION_INFO_MASTER_T;";
                    // SQL実行
                    dataSet = executeSelect(command);
                    // 最初に見つかった行から走行基本情報データを抜き出す
                    row = dataSet.Tables[0].Rows[0];
                    getValueFromDataSet(row[0], out alltabelcount.data3);

                    command.CommandText = @"SELECT COUNT(*) FROM ITEM_MASTER_T;";
                    // SQL実行
                    dataSet = executeSelect(command);
                    // 最初に見つかった行から走行基本情報データを抜き出す
                    row = dataSet.Tables[0].Rows[0];
                    getValueFromDataSet(row[0], out alltabelcount.data4);

                    command.CommandText = @"SELECT COUNT(*) FROM EVALUATION_SPECIFICATION_MASTER_T;";
                    // SQL実行
                    dataSet = executeSelect(command);
                    // 最初に見つかった行から走行基本情報データを抜き出す
                    row = dataSet.Tables[0].Rows[0];
                    getValueFromDataSet(row[0], out alltabelcount.data5);

                    command.CommandText = @"SELECT COUNT(*) FROM JUDGMENT_TYPE_MASTER_T;";
                    // SQL実行
                    dataSet = executeSelect(command);
                    // 最初に見つかった行から走行基本情報データを抜き出す
                    row = dataSet.Tables[0].Rows[0];
                    getValueFromDataSet(row[0], out alltabelcount.data6);

                    command.CommandText = @"SELECT COUNT(*) FROM SPECIFICATION_PROVIDING_SOURCE_MASTER_T;";
                    // SQL実行
                    dataSet = executeSelect(command);
                    // 最初に見つかった行から走行基本情報データを抜き出す
                    row = dataSet.Tables[0].Rows[0];
                    getValueFromDataSet(row[0], out alltabelcount.data7);

                    command.CommandText = @"SELECT COUNT(*) FROM DRIVING_INFO_T;";
                    // SQL実行
                    dataSet = executeSelect(command);
                    // 最初に見つかった行から走行基本情報データを抜き出す
                    row = dataSet.Tables[0].Rows[0];
                    getValueFromDataSet(row[0], out alltabelcount.data8);

                    command.CommandText = @"SELECT COUNT(*) FROM ROUTE_SIGNAL_INFO_T;";
                    // SQL実行
                    dataSet = executeSelect(command);
                    // 最初に見つかった行から走行基本情報データを抜き出す
                    row = dataSet.Tables[0].Rows[0];
                    getValueFromDataSet(row[0], out alltabelcount.data9);

                    command.CommandText = @"SELECT COUNT(*) FROM INTERSECTION_ROUTE_SIGNAL_INFO_T;";
                    // SQL実行
                    dataSet = executeSelect(command);
                    // 最初に見つかった行から走行基本情報データを抜き出す
                    row = dataSet.Tables[0].Rows[0];
                    getValueFromDataSet(row[0], out alltabelcount.data10);

                    command.CommandText = @"SELECT COUNT(*) FROM CYCLE_INFO_T;";
                    // SQL実行
                    dataSet = executeSelect(command);
                    // 最初に見つかった行から走行基本情報データを抜き出す
                    row = dataSet.Tables[0].Rows[0];
                    getValueFromDataSet(row[0], out alltabelcount.data11);

                    command.CommandText = @"SELECT COUNT(*) FROM GENERATION_T;";
                    // SQL実行
                    dataSet = executeSelect(command);
                    // 最初に見つかった行から走行基本情報データを抜き出す
                    row = dataSet.Tables[0].Rows[0];
                    getValueFromDataSet(row[0], out alltabelcount.data12);

                    command.CommandText = @"SELECT COUNT(*) FROM UTMS_LINK_T;";
                    // SQL実行
                    dataSet = executeSelect(command);
                    // 最初に見つかった行から走行基本情報データを抜き出す
                    row = dataSet.Tables[0].Rows[0];
                    getValueFromDataSet(row[0], out alltabelcount.data13);

                    command.CommandText = @"SELECT COUNT(*) FROM EVALUATION_IMPLEMENTATION_HISTORY_T;";
                    // SQL実行
                    dataSet = executeSelect(command);
                    // 最初に見つかった行から走行基本情報データを抜き出す
                    row = dataSet.Tables[0].Rows[0];
                    getValueFromDataSet(row[0], out alltabelcount.data14);

                    command.CommandText = @"SELECT COUNT(*) FROM PREFECTURE_ROUTE_INFO_T;";
                    // SQL実行
                    dataSet = executeSelect(command);
                    // 最初に見つかった行から走行基本情報データを抜き出す
                    row = dataSet.Tables[0].Rows[0];
                    getValueFromDataSet(row[0], out alltabelcount.data15);

                    command.CommandText = @"SELECT COUNT(*) FROM ROUTE_INTERSECTION_INFO_T;";
                    // SQL実行
                    dataSet = executeSelect(command);
                    // 最初に見つかった行から走行基本情報データを抜き出す
                    row = dataSet.Tables[0].Rows[0];
                    getValueFromDataSet(row[0], out alltabelcount.data16);

                    command.CommandText = @"SELECT COUNT(*) FROM ITEM_EVALUATION_SPECIFICATION_T;";

                    // SQL実行
                    dataSet = executeSelect(command);
                    // 最初に見つかった行から走行基本情報データを抜き出す
                    row = dataSet.Tables[0].Rows[0];
                    getValueFromDataSet(row[0], out alltabelcount.data17);

                    command.CommandText = @"SELECT COUNT(*) FROM EVALUATION_SPECIFICATION_JUDGMENT_TYPE_T;";
                    // SQL実行
                    dataSet = executeSelect(command);
                    // 最初に見つかった行から走行基本情報データを抜き出す
                    row = dataSet.Tables[0].Rows[0];
                    getValueFromDataSet(row[0], out alltabelcount.data18);

                    command.CommandText = @"SELECT COUNT(*) FROM EVALUATION_SPECIFICATION_PROVIDING_SOURCE_T;";
                    // SQL実行
                    dataSet = executeSelect(command);
                    // 最初に見つかった行から走行基本情報データを抜き出す
                    row = dataSet.Tables[0].Rows[0];
                    getValueFromDataSet(row[0], out alltabelcount.data19);

                }
                catch (Exception exception)
                {
                    Console.WriteLine(exception.Message);
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// 走行履歴テーブルに格納されているLengthエラーの件数をカウントする(走行情報IDを指定)
        /// </summary>
        /// <param name="drivingInfoId">走行情報ID</param>
        /// <returns></returns>
        public int GetLengthErrorCount(int drivingInfoId)
        {
            int result = 0;

            using (var command = new NpgsqlCommand())
            {
                try
                {
                    // SQLコマンド作成
                    command.CommandText = @"SELECT COUNT(*) FROM EVALUATION_IMPLEMENTATION_HISTORY_T ";
                    command.CommandText += @" WHERE STATUS = 1001";
                    command.CommandText += @" AND DRIVING_INFO_ID =  :DRIVING_INFO_ID";
                    command.Parameters.Add(new NpgsqlParameter("DRIVING_INFO_ID", NpgsqlTypes.NpgsqlDbType.Integer)).Value = drivingInfoId;

                    // SQL実行
                    var dataSet = executeSelect(command);

                    // 結果を格納
                    getValueFromDataSet(dataSet.Tables[0].Rows[0][0], out result);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
            }

            return result;
        }

    }
}
