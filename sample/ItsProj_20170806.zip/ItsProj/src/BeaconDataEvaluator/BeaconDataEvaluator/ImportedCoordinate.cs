﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BeaconDataEvaluator
{
    /// <summary>
    /// インポート座標の近接真値座標インデックス割り当てクラス
    /// </summary>
    public class ImportedCoordinate
    {
        public Point Coordinate;                ///< インポートされた座標
        public short Destination;               ///< 光ビーコンから当該停止線までの概算道程距離
        public double DistanceCoordinate;       ///< 誤差(座標)
        public short DistanceDestination;       ///< 誤差(道程距離)
        public int OriginalCoordinateIndex;     ///< 真値の座標インデックス

        /// <summary>
        /// デフォルトコンストラクタ
        /// </summary>
        public ImportedCoordinate()
        {
            Coordinate = new Point();
            Coordinate.X = 0;
            Coordinate.Y = 0;
            Destination = 0;
            DistanceCoordinate = 0;
            DistanceDestination = 0;
            OriginalCoordinateIndex = 0;
        }

        /// <summary>
        /// 初期化コンストラクタ(Point)
        /// </summary>
        /// <param name="point">2次元座標</param>
        public ImportedCoordinate(Point point)
        {
            Coordinate = new Point();
            Coordinate = point;
            Destination = 0;
            DistanceCoordinate = 0;
            DistanceDestination = 0;
            OriginalCoordinateIndex = 0;
        }

        /// <summary>
        /// 初期化コンストラクタ(x, y)
        /// </summary>
        /// <param name="x">2次元座標X</param>
        /// <param name="y">2次元座標Y</param>
        public ImportedCoordinate(double x, double y)
        {
            Coordinate = new Point();
            Coordinate.X = x;
            Coordinate.Y = y;
            Destination = 0;
            DistanceCoordinate = 0;
            DistanceDestination = 0;
            OriginalCoordinateIndex = 0;
        }

        /// <summary>
        /// コピーコンストラクタ
        /// </summary>
        /// <param name="previousCoordinate">コピー元の値</param>
        public ImportedCoordinate(ImportedCoordinate previousCoordinate)
        {
            Coordinate = previousCoordinate.Coordinate;
            Destination = previousCoordinate.Destination;
            DistanceCoordinate = previousCoordinate.DistanceCoordinate;
            DistanceDestination = previousCoordinate.DistanceDestination;
            OriginalCoordinateIndex = previousCoordinate.OriginalCoordinateIndex;
        }

    }
}
