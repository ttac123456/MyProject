﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Microsoft;
using System.Windows.Threading;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using System.Xml.Serialization;
using System.IO;

namespace BeaconDataEvaluator
{
    /// <summary>
    /// 交差点画像作成クラス
    /// </summary>
    /// <remarks>
    /// 指定された交差点HTMLをブラウザで表示して、表示されたイメージ画像を保存する。
    /// </remarks>
    [ComVisibleAttribute(true)]
    public partial class IntersectionHtmlBrowser : Window
    {
        private const string EXTENSION_NAME_IMAGE = @"jpg";             ///< 画像ファイルの拡張子
        public static Point ImagePictSizeHD = new Point(1366, 768);     ///< 画像ファイルサイズ

        private System.Windows.Threading.Dispatcher mainWindowDispatcher;   ///< メインウィンドウのディスパッチャ
        public Action<string> OnHtmlLoaded;                             ///< HTMLロード完了イベント
        public Action OnHtmlClosed;                                     ///< HTMLクローズ完了イベント

        private string htmlFilepath;                                    ///< 入力HTMLファイルパス
        private bool htmlLoadDone;                                      ///< HTMLロード完了フラグ

        /// コンストラクタ
        public IntersectionHtmlBrowser(Dispatcher mwDispatcher)
        {
            InitializeComponent();

            // メインウィンドウのディスパッチャを保持
            mainWindowDispatcher = mwDispatcher;
        }

        /// <summary>
        /// ウィンドウロード完了イベント
        /// </summary>
        /// <param name="sender">イベント発生元</param>
        /// <param name="e">イベントパラメータ</param>
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            // JavaScriptのエラー表示を抑止する
            webBrowserIntersection.ScriptErrorsSuppressed = true;

            // JavaScriptからのpublicメンバーアクセスを可能にする
            webBrowserIntersection.ObjectForScripting = this;

            // ブラウザウィンドウのクライアントサイズを設定する
            setBrowserSize();

            // ブラウザに指定したソースを表示させる
            var navigateFilepath = new Uri(htmlFilepath).ToString();
            webBrowserIntersection.Navigate(navigateFilepath);
        }

        /// <summary>
        /// ウィンドウクローズ完了イベント
        /// </summary>
        /// <param name="sender">イベント発生元</param>
        /// <param name="e">イベントパラメータ</param>
        private void Window_Closed(object sender, EventArgs e)
        {
            webBrowserIntersection.Dispose();
            OnHtmlClosed();
        }

        // Updates the URL in TextBoxAddress upon navigation.
        /// <summary>
        /// ウェブブラウザの指定ソースロード完了イベント
        /// </summary>
        /// <param name="sender">イベント発生元</param>
        /// <param name="e">イベントパラメータ</param>
        private void webBrowserIntersection_Navigated(object sender, WebBrowserNavigatedEventArgs e)
        {
            // HTMLファイルパスから、画像ファイルパスを生成する
            string imageFilepath = System.IO.Path.ChangeExtension(htmlFilepath, EXTENSION_NAME_IMAGE);
            // 画像描画遅延時間を取得する
            int imageDrawCompletionDelaySec = 0;
            using (var fs = new FileStream(@"XMLSetting.xml", FileMode.Open, FileAccess.Read))
            {
                var serializer = new XmlSerializer(typeof(XMLSetting));
                var xmlSetting = (XMLSetting)serializer.Deserialize(fs);
                int.TryParse(xmlSetting.mapMaker.ImageDrawCompletionDelaySec, out imageDrawCompletionDelaySec);
            }
            // 画像遅延保存タスクを起動する
            var t = Task.Run(() => delaySaveImage(imageFilepath, imageDrawCompletionDelaySec));
        }

        /// <summary>
        /// 入力HTMLファイルパスを指定する
        /// </summary>
        /// <param name="filepath">入力HTMLファイルパス</param>
        public void SetHtmlFilepath(string filepath)
        {
            // 入力HTMLファイルパスを保存する
            htmlFilepath = filepath;
        }

        /// <summary>
        /// ブラウザウィンドウのクライアントサイズを設定
        /// </summary>
        /// <param name="w"></param>
        /// <param name="h"></param>
        private void setBrowserSize()
        {
            Width = ImagePictSizeHD.X;
            Height = ImagePictSizeHD.Y;
        }

        /// <summary>
        /// 画像遅延保存タスク処理
        /// </summary>
        /// <param name="filepath">出力画像ファイルパス</param>
        /// <param name="millisecond">ファイル保存前の遅延時間(ミリ秒)</param>
        /// <remarks>所定時間待ってから画像ファイルを保存する</remarks>
        private void delaySaveImage(string filepath, int millisecond)
        {
            // HTMLロード完了フラグ:OFF
            htmlLoadDone = false;
            // 現在時刻を取得
            var beginTime = DateTime.Now;
            while (millisecond > 0)
            {
                // HTMLロード完了または所定時間経過を待つ
                int passedMillisecond = (int)(DateTime.Now - beginTime).TotalMilliseconds;
                if (htmlLoadDone || passedMillisecond > millisecond)
                    break;
                Thread.Sleep(100);
            }

            Dispatcher.BeginInvoke((Action)(() =>
            {
                try
                {
                    // 画像ファイルを保存する
                    saveImage(filepath);
                    // HTMLロード完了をコールバックする
                    OnHtmlLoaded(filepath);
                }
                catch (Exception e)
                {
                    Console.WriteLine($@"画像ファイル保存失敗 ({filepath}) : {e.Message}");
                    // HTMLロード失敗をコールバックする
                    OnHtmlLoaded("");
                }
                finally
                {
                    // 自ウィンドウをクローズする
                    Close();
                }
            }));
        }

        /// <summary>
        /// 画像ファイルを保存する
        /// </summary>
        /// <param name="fileName">出力画像ファイルパス</param>
        public void saveImage(string filepath)
        {
            //WebBrowserコントロールのgraphicsインスタンスを取得する
            System.Drawing.Graphics g = webBrowserIntersection.CreateGraphics();

            //画像を保存するbitmapオブジェクトを生成する
            System.Drawing.Bitmap bmp = new System.Drawing.Bitmap(webBrowserIntersection.Width, webBrowserIntersection.Height);

            //WebBrowserからbitmapオブジェクトに描画する
            webBrowserIntersection.DrawToBitmap(bmp, new System.Drawing.Rectangle(0, 0, webBrowserIntersection.Width, webBrowserIntersection.Height));

            //画像をファイルに保存する
            bmp.Save(filepath, System.Drawing.Imaging.ImageFormat.Jpeg);

            //bitmapオブジェクトを破棄する
            bmp.Dispose();

            //graphicsインスタンスを破棄する
            g.Dispose();
        }

    }
}
