﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Drawing;
using System.IO;

namespace BeaconDataEvaluator
{
    /// <summary>
    /// 交差点HTML作成クラス
    /// </summary>
    /// <remarks>
    /// 指定したフォルダに交差点マーカーとHTMLを保存し、さらにHTMLを表示したイメージ画像も保存する。
    /// </remarks>
    public class IntersectionHtmlMaker
    {
        /// <summary>
        /// HTMLへの追記検索モード定義
        /// </summary>
        private enum SeekHtmlMode
        {
            None = 0,               ///< 検索しない
            SeekDocktype,           ///< DOCTYPEタグ開始を検索
            SeekImageStart,         ///< imageタグ開始を検索
            SeekImageEnd,           ///< imageタグ終了を検索
            SeekLineItem,           ///< lineitem2タグを検索
            SeekSetmarkersGpsdata,  ///< setMarkers関数コールのgpsdata2キーワードを検索
            SeekPolylineGpsdata,    ///< Polyline関数コールのlineitem2キーワードを検索
            SeekAMapFitBounds,      ///< aMapFitBounds関数コールを検索
            SeekGpsdataStart,       ///< gpsdata2タグ開始を検索
            SeekGpsdataEnd,         ///< gpsdata2タグ終了を検索
            SeekSetmarkersStart,    ///< setMarkers関数開始を検索
            SeekSetmarkersEnd1,     ///< setMarkers関数終了1を検索
            SeekSetmarkersEnd2,     ///< setMarkers関数終了2を検索
            SeekAMapFitBoundsStart, ///< aMapFitBounds関数開始を検索
            SeekAMapFitBoundsEnd1,  ///< aMapFitBounds関数終了1を検索
            SeekAMapFitBoundsEnd2,  ///< aMapFitBounds関数終了2を検索
        }

        // DOCTYPEタグの検索用キーワード
        private const string SEEK_HTML_DOCTYPE = @"<!DOCTYPE html>";    ///< DOCTYPE検出ワード

        // imageタグの検索用キーワード
        private const string SEEK_HTML_IMAGE_START = @"var image = [";  ///< imageタグ検出開始ワード
        private const string SEEK_HTML_IMAGE_END = @"];";               ///< imageタグ検出終了ワード

        // lineitem2タグの検索用キーワード
        private const string SEEK_HTML_LINEITEM2 = @"var lineitem2 = [];";  ///< lineitem2タグ検出ワード

        // setMarkers関数コールのgpsdata2キーワードの検索用キーワード
        private const string SEEK_HTML_SETMARKERS_GPSDATA2 = @"setMarkers(map, gpsdata2, image[1], lineitem2);";    ///< setMarkers関数コールのgpsdata2キーワード検出ワード

        // aMapFitBounds関数コールの検索用キーワード
        private const string SEEK_HTML_AMAPFITBOUNDS = @"aMapFitBounds(map, FitBounds);}";  ///< aMapFitBounds関数コールの検出ワード

        // Polyline関数コールのlineitem2キーワードの検索用キーワード
        private const string SEEK_HTML_POLYLINE_GPSDATA2 = @"new google.maps.Polyline({path: lineitem2, strokeColor: '#00FF00', strokeOpacity: 1.0, strokeWeight: 2, map: map});";  ///< Polyline関数コールのlineitem2キーワード検出ワード

        // gpsdata2タグの検索用キーワード
        private const string SEEK_HTML_GPSDATA2_START = @"var gpsdata2 = [";    ///< gpsdata2タグ検出開始ワード
        private const string SEEK_HTML_GPSDATA2_END = @"];";                    ///< gpsdata2タグ検出終了ワード

        // setMarkers関数の検索用キーワード
        private const string SEEK_HTML_SETMARKERS_START = @"function setMarkers(map, locations, image, lineitem) {";    ///< setMarkers関数タグ検出開始ワード
        private const string SEEK_HTML_SETMARKERS_END_1ST = @"}";                                                       ///< setMarkers関数タグ検出終了ワード(内側ループ終了)
        private const string SEEK_HTML_SETMARKERS_END_2ND = @"}";                                                       ///< setMarkers関数タグ検出終了ワード(外側ループ終了)

        // aMapFitBounds関数の検索用キーワード
        private const string SEEK_HTML_AMAPFITBOUNDS_START = @"function aMapFitBounds(map, FitBounds) {";   ///< aMapFitBounds関数タグ検出開始ワード
        private const string SEEK_HTML_AMAPFITBOUNDS_END_1ST = @"}";                                        ///< aMapFitBounds関数タグ検出終了ワード(内側ループ終了)
        private const string SEEK_HTML_AMAPFITBOUNDS_END_2ND = @"}";                                        ///< aMapFitBounds関数タグ検出終了ワード(外側ループ終了)

        private const string IMAGE_EXTENSION = @"png";                  ///< 交差点マーカー画像の拡張子文字列
        private const string IMAGE_STORAGE_DIRECTORY = @"markerIcon";   ///< 交差点マーカー画像の格納先ディレクトリ名文字列
        private const string BEACON_IMAGE_FILENAME = @"Beacon.png";     ///< ビーコン画像のファイル名文字列
        private const string SIGNAL_IMAGE_FILENAME = @"signal.png";     ///< 信号画像のファイル名文字列
        private const int MAX_INTESECTOIN_COUNT = 20;                   ///< 交差点マーカー画像の最大数

        private const string ROUTE_NAME_BASE = @"路線";                 ///< 路線HTMLファイル名のベース文字列(路線番号を後から付与する)
        private const string HTML_EXTENSION = @"htm";                   ///< HTMLファイルの拡張子文字列

        private DatabaseAccessor dataBaseAccessor;                          ///< データベース通信クラス
        private System.Windows.Threading.Dispatcher mainWindowDispatcher;   ///< メインウィンドウのディスパッチャ
        private Dictionary<string, Bitmap> MarkerImages;                    ///< 交差点マーカー画像リスト

        private IntersectionHtmlBrowser browser;            ///< 交差点画像作成クラス
        private string imageFilePath;                       ///< 生成された交差点画像ファイルパス
        private bool imageFileCreateFailed;                 ///< 交差点画像ファイル生成失敗フラグ

        /// コンストラクタ
        public IntersectionHtmlMaker(DatabaseAccessor dbAccessor, System.Windows.Threading.Dispatcher mwDispatcher)
        {
            // データベース通信クラスを保持
            dataBaseAccessor = dbAccessor;
            // メインウィンドウのディスパッチャを保持
            mainWindowDispatcher = mwDispatcher;
            // 交差点マーカー画像リストを作成する
            makeMarkerImageList();
            // HTMLブラウザを初期化
            htmlBrowserInitialize();
        }

        /// デストラクタ
        ~IntersectionHtmlMaker()
        {
            // HTMLブラウザをクローズ
            htmlBrowserClose();
        }

        /// <summary>
        /// 交差点マーカー画像リストを作成する
        /// </summary>
        private void makeMarkerImageList()
        {
            MarkerImages = new Dictionary<string, Bitmap>();
            MarkerImages.Add(@"beacon_00", Properties.Resources.beacon_00);
            MarkerImages.Add(@"intersection_01", Properties.Resources.intersection_01);
            MarkerImages.Add(@"intersection_02", Properties.Resources.intersection_02);
            MarkerImages.Add(@"intersection_03", Properties.Resources.intersection_03);
            MarkerImages.Add(@"intersection_04", Properties.Resources.intersection_04);
            MarkerImages.Add(@"intersection_05", Properties.Resources.intersection_05);
            MarkerImages.Add(@"intersection_06", Properties.Resources.intersection_06);
            MarkerImages.Add(@"intersection_07", Properties.Resources.intersection_07);
            MarkerImages.Add(@"intersection_08", Properties.Resources.intersection_08);
            MarkerImages.Add(@"intersection_09", Properties.Resources.intersection_09);
            MarkerImages.Add(@"intersection_10", Properties.Resources.intersection_10);
            MarkerImages.Add(@"intersection_11", Properties.Resources.intersection_11);
            MarkerImages.Add(@"intersection_12", Properties.Resources.intersection_12);
            MarkerImages.Add(@"intersection_13", Properties.Resources.intersection_13);
            MarkerImages.Add(@"intersection_14", Properties.Resources.intersection_14);
            MarkerImages.Add(@"intersection_15", Properties.Resources.intersection_15);
            MarkerImages.Add(@"intersection_16", Properties.Resources.intersection_16);
            MarkerImages.Add(@"intersection_17", Properties.Resources.intersection_17);
            MarkerImages.Add(@"intersection_18", Properties.Resources.intersection_18);
            MarkerImages.Add(@"intersection_19", Properties.Resources.intersection_19);
            MarkerImages.Add(@"intersection_20", Properties.Resources.intersection_20);
        }

        /// <summary>
        /// 交差点HTMLを作成する
        /// </summary>
        /// <param name="drivingInfoId">走行基本情報ID</param>
        /// <param name="inputPath">入力ディレクトリパス</param>
        /// <param name="outputPath">出力ディレクトリパス</param>
        /// <param name="intersectionInfos">真値交差点リスト</param>
        /// <param name="importedCoordinates">インポート交差点リスト</param>
        /// <returns>作成された画像ファイルパス文字列</returns>
        /// <remarks>入出力ディレクトリは、都道府県や路線を含まないベースのディレクトリ(INPUTへのパス)を指定すること</remarks>
        public string Start(int drivingInfoId, string inputPath, string outputPath, List<DatabaseAccessor.StIntersectionInfo> intersectionInfos = null, List<ImportedCoordinate> importedCoordinates = null)
        {
            string imageFilePath = "";      // 作成された画像ファイルパス文字列

            // DBから走行基本情報を取得する
            DatabaseAccessor.StDrivingInfo drivingInfo;
            dataBaseAccessor.GetDrivingInfo(drivingInfoId, out drivingInfo);

            // ビーコンデータバージョンを取得する
            var beaconDataVersion = drivingInfo.Version;

            // 交差点情報が指定されずに開始した場合は、
            if ((intersectionInfos == null) || (importedCoordinates == null))
            {
                // 交差点情報を取得する
                CalculateLocationInformationByRoute(drivingInfoId, beaconDataVersion, out intersectionInfos, out importedCoordinates);
            }

            // 都道府県名と路線名を入出力ディレクトリパスに連結する
            string inputPathWithRoute;
            string outputPathWithRoute;
            combinePrefectureRoutePath(drivingInfoId, inputPath, outputPath, out inputPathWithRoute, out outputPathWithRoute);

            // 交差点マーカー画像を出力先ディレクトリに展開する
            deployMarkerImages(inputPathWithRoute, outputPathWithRoute);

            // 路線HTMLファイルを展開する
            var htmlFilePath = deployRouteHtmlFile(drivingInfoId, inputPathWithRoute, outputPathWithRoute, intersectionInfos, importedCoordinates, beaconDataVersion);
            // HTMLファイル作成失敗時はファイルパスは空。エラーを出力し、空をreturn。


            // 交差点画像ファイルを展開する
            imageFilePath = deployIntersectionImageFile(drivingInfoId, htmlFilePath);
            string imageFilename = DataExporter.makeExporteFilepath(drivingInfoId, dataBaseAccessor, DataExporter.ExportType.MapImage);
            // JPEGファイル作成失敗時はファイルパスは空。エラーを出力し、空をreturn。


            // 作成された画像ファイルパス文字列を返却
            return imageFilename;
        }

        /// <summary>
        /// 路線別位置情報算出
        /// </summary>
        /// <param name="drivingInfoId">走行基本情報ID</param>
        /// <param name="beaconDataVersion">版</param>
        /// <param name="intersectionInfos">[out]真値交差点リスト</param>
        /// <param name="importedCoordinates">[out]インポート交差点リスト</param>
        public void CalculateLocationInformationByRoute(int drivingInfoId, DatabaseAccessor.EvaluationVersion beaconDataVersion, out List<DatabaseAccessor.StIntersectionInfo> intersectionInfos, out List<ImportedCoordinate> importedCoordinates)
        {
            // DBから走行基本情報を取得する
            DatabaseAccessor.StDrivingInfo drivingInfo;
            dataBaseAccessor.GetDrivingInfo(drivingInfoId, out drivingInfo);

            // 交差点情報マスタから交差点情報を取得する
            short prefectureId = drivingInfo.PrefectureId;  // 都道府県ID
            short routeNum = drivingInfo.RouteNum;          // 路線番号
            dataBaseAccessor.GetIntersectionInfo(prefectureId, routeNum, out intersectionInfos);

            // 評価結果データから交差点情報を取得する
            var evalSpecIdForIntersectionNumber = (beaconDataVersion == DatabaseAccessor.EvaluationVersion.Version1) ? 14 : 137;    // 格納交差点数
            var evalSpecIdForCoordinatesWGSLat = (beaconDataVersion == DatabaseAccessor.EvaluationVersion.Version1) ? 22 : 145;     // ２次メッシュ座標(緯度:世界測地系)
            var evalSpecIdForCoordinatesWGSLon = (beaconDataVersion == DatabaseAccessor.EvaluationVersion.Version1) ? 23 : 146;     // ２次メッシュ座標(経度:世界測地系)
            var evalSpecIdForDestination = (beaconDataVersion == DatabaseAccessor.EvaluationVersion.Version1) ? 30 : 153;           // 光ビーコンから当該停止線までの概算道程距離
            var evalSpecIdForUpstreamCoordinatesWGSLat = (beaconDataVersion == DatabaseAccessor.EvaluationVersion.Version1) ? 36 : 162; // 上流交差点の２次メッシュ座標(緯度:世界測地系)
            var evalSpecIdForUpstreamCoordinatesWGSLon = (beaconDataVersion == DatabaseAccessor.EvaluationVersion.Version1) ? 37 : 163; // 上流交差点の２次メッシュ座標(経度:世界測地系)

            importedCoordinates = new List<ImportedCoordinate>();   //  インポート座標の近接真値座標リスト
            DatabaseAccessor.StRouteSignalInfo routeSignalInfo;
            dataBaseAccessor.GetRouteSignalInfo(drivingInfoId, evalSpecIdForIntersectionNumber, out routeSignalInfo);    // 格納交差点数
            ImportedCoordinate importedCoordinate;
            DatabaseAccessor.StIntersectionRouteSignalInfo intersectionRouteSignalInfo;

            // ビーコン座標を取得
            importedCoordinate = new ImportedCoordinate();
            dataBaseAccessor.GetIntersectionRouteSignalInfo(drivingInfoId, 1, evalSpecIdForUpstreamCoordinatesWGSLat, out intersectionRouteSignalInfo);
            importedCoordinate.Coordinate.X = intersectionRouteSignalInfo.DoubleValue;  // 上流交差点の２次メッシュ座標(緯度:世界測地系)
            dataBaseAccessor.GetIntersectionRouteSignalInfo(drivingInfoId, 1, evalSpecIdForUpstreamCoordinatesWGSLon, out intersectionRouteSignalInfo);
            importedCoordinate.Coordinate.Y = intersectionRouteSignalInfo.DoubleValue;  // 上流交差点の２次メッシュ座標(経度:世界測地系)
            importedCoordinates.Add(importedCoordinate);

            // 交差点座標を取得
            var intersectionNumber = routeSignalInfo.IntegerValue;
            for (int intersectionId = 1; intersectionId <= intersectionNumber; intersectionId++)
            {
                importedCoordinate = new ImportedCoordinate();

                dataBaseAccessor.GetIntersectionRouteSignalInfo(drivingInfoId, intersectionId, evalSpecIdForCoordinatesWGSLat, out intersectionRouteSignalInfo);
                importedCoordinate.Coordinate.X = intersectionRouteSignalInfo.DoubleValue;      // ２次メッシュ座標(緯度:世界測地系)

                dataBaseAccessor.GetIntersectionRouteSignalInfo(drivingInfoId, intersectionId, evalSpecIdForCoordinatesWGSLon, out intersectionRouteSignalInfo);
                importedCoordinate.Coordinate.Y = intersectionRouteSignalInfo.DoubleValue;      // ２次メッシュ座標(経度:世界測地系)

                dataBaseAccessor.GetIntersectionRouteSignalInfo(drivingInfoId, intersectionId, evalSpecIdForDestination, out intersectionRouteSignalInfo);
                importedCoordinate.Destination = (short)intersectionRouteSignalInfo.IntegerValue;   // 光ビーコンから当該停止線までの概算道程距離

                importedCoordinates.Add(importedCoordinate);
            }
            // インポート座標に最も近い真値座標インデックスを割り当てる
            chooseNearestCoordinate(intersectionInfos, ref importedCoordinates);

            var count = importedCoordinates.Count();
        }

        /// <summary>
        /// インポート座標に最も近い真値座標インデックスを割り当てる
        /// </summary>
        /// <param name="originalCoordinates">真値の座標リスト</param>
        /// <param name="importedCoordinates">[ref]インポートされた座標リスト</param>
        private static void chooseNearestCoordinate(List<DatabaseAccessor.StIntersectionInfo> originalCoordinates, ref List<ImportedCoordinate> importedCoordinates)
        {
            int importIndex = 0;
            foreach (var importedCoordinate in importedCoordinates)
            {
                var CoordinateDistances = new List<double>();   // 誤差(座標)の一時保管リスト
                var DestinationDistances = new List<short>();   // 誤差(道程距離)の一時保管リスト
                double minimumDistance = double.MaxValue;       // 最小値をdouble型の最大値に初期化
                int coordinateIndex = 0;                        // 真値インデックスを初期化
                int coordinateIndexWithMinimumDistance = 0;     // 最小誤差を検出した真値インデックス保管用

                foreach (var originalCoordinate in originalCoordinates)
                {
                    // 真値座標とインポート座標から誤差を算出する
                    var realCordinate = new Point(originalCoordinate.LatitudeTrueValue, originalCoordinate.LongitudeTrueValue);
                    double coordinateDistance = distance(realCordinate, importedCoordinate.Coordinate);
                    CoordinateDistances.Add(coordinateDistance);        // 誤差(座標)
                    // 真値道程距離とインポート道程距離から誤差を算出する
                    var realDestination = originalCoordinate.DestinationDistanceTrueValue;
                    var importedDestination = importedCoordinate.Destination;
                    var destinationDistance = (short)Math.Abs(realDestination - importedDestination);
                    DestinationDistances.Add(destinationDistance);      // 誤差(道程距離)
                    // 座標から算出した最小誤差と真値インデックスを保持しておく
                    if (minimumDistance > coordinateDistance)
                    {
                        minimumDistance = coordinateDistance;
                        coordinateIndexWithMinimumDistance = coordinateIndex;
                    }
                    coordinateIndex++;      // 真値インデックスをインクリメント
                }
                // 誤差が最小となった真値インデックスを検索する
                coordinateIndex = 0;
                foreach (var coordinateDistance in CoordinateDistances)
                {
                    if (coordinateDistance == minimumDistance)
                    {
                        importedCoordinate.DistanceCoordinate = coordinateDistance;                     // 誤差(座標)
                        importedCoordinate.DistanceDestination = DestinationDistances[coordinateIndex]; // 誤差(道程距離)
                        importedCoordinate.OriginalCoordinateIndex = coordinateIndexWithMinimumDistance;// 真値座標インデックス
                        break;
                    }
                    coordinateIndex++;  // 真値インデックスをインクリメント
                }
                importIndex++;  // インポート値インデックスをインクリメント
            }
        }

        /// <summary>
        /// 2点間の距離を求める
        /// </summary>
        /// <param name="p1">2次元座標(緯度1,経度1)</param>
        /// <param name="p2">2次元座標(緯度2,経度2)</param>
        /// <returns>距離(m)</returns>
        private static double distance(Point p1, Point p2)
        {
            // まず2点間の距離は、三平方の定理を使うと、「a^2 + b^2 = c^2（cが斜辺）」
            // そしてWikipediaから平均で緯度1度あたり「111km」、経度1度あたり「91km」なので、
            // 距離は「距離(km) = √((緯度1 – 緯度2) / 0.0111)^2 + ( (経度1 – 経度2) / 0.0091)^2」
            // で求められる。

            double diffLat = p1.X - p2.X;   // 緯度の差
            double diffLon = p1.Y - p2.Y;   // 経度の差

            return 1000 * Math.Sqrt(Math.Pow(diffLat / 0.0111, 2) + Math.Pow(diffLon / 0.0091, 2));
        }

        /// <summary>
        /// 都道府県名と路線名を入出力ディレクトリパスに連結する
        /// </summary>
        /// <param name="drivingInfoId">走行基本情報ID</param>
        /// <param name="baseInputPath">連結元の入力パス</param>
        /// <param name="baseOutputPath">連結元の出力パス</param>
        /// <param name="inputPath">[out]都道府県名と路線名を連結した入力パス</param>
        /// <param name="outputPath">[out]都道府県名と路線名を連結した出力</param>
        private void combinePrefectureRoutePath(int drivingInfoId, string baseInputPath, string baseOutputPath, out string inputPath, out string outputPath)
        {
            // 走行基本情報を取得する
            DatabaseAccessor.StDrivingInfo driveingInfo;
            dataBaseAccessor.GetDrivingInfo(drivingInfoId, out driveingInfo);

            // 都道府県名を取得する
            var prefectureName = dataBaseAccessor.ReferencePrefectureName(driveingInfo.PrefectureId);
            prefectureName = $"{driveingInfo.PrefectureId:00}_" + prefectureName;

            // 路線名を取得する
            var routeName = ROUTE_NAME_BASE + $"{driveingInfo.RouteNum:000}";

            // 指定パスに都道府県名と路線名を連結する
            inputPath = Path.Combine(baseInputPath, prefectureName, routeName);
            outputPath = Path.Combine(baseOutputPath, prefectureName, routeName);
        }

        /// <summary>
        /// 交差点マーカー画像を展開する
        /// </summary>
        /// <param name="inputPath">コピー元画像ディレクトリパス</param>
        /// <param name="destinationPath">展開先ディレクトリパス</param>
        private void deployMarkerImages(string inputPath, string destinationPath)
        {
            // 展開先ディレクトリパスを作成する
            string markerImageStoragePath = Path.Combine(destinationPath, IMAGE_STORAGE_DIRECTORY);
            makeDeployDirectory(markerImageStoragePath);

            // 交差点マーカー画像を展開する
            deployMarkerImages(destinationPath);

            // ビーコン画像をコピーする
            string beaconFilepathSrc = Path.Combine(inputPath, BEACON_IMAGE_FILENAME);      // ビーコン画像のコピー元ファイルパス
            string beaconFilepathDst = Path.Combine(destinationPath, BEACON_IMAGE_FILENAME);// ビーコン画像の展開先ファイルパス
            copyFile(beaconFilepathSrc, beaconFilepathDst);

            // 信号画像をコピーする
            string signalFilepathSrc = Path.Combine(inputPath, SIGNAL_IMAGE_FILENAME);      // 信号画像のコピー元ファイルパス
            string signalFilepathDst = Path.Combine(destinationPath, SIGNAL_IMAGE_FILENAME);// 信号画像の展開先ファイルパス
            copyFile(signalFilepathSrc, signalFilepathDst);
        }

        /// <summary>
        /// 展開先ディレクトリパスを作成する
        /// </summary>
        /// <param name="deployPath">展開先のディレクトリパス</param>
        private void makeDeployDirectory(string deployPath)
        {
            if (!Directory.Exists(deployPath))
            {
                Directory.CreateDirectory(deployPath);
            }
        }

        /// <summary>
        /// 交差点マーカー画像を展開する
        /// </summary>
        /// <param name="destinationPath">展開先のディレクトリパス</param>
        private void deployMarkerImages(string destinationPath)
        {
            foreach (var bitmapIntersection in MarkerImages)
            {
                string intersectionFileName = Path.ChangeExtension(bitmapIntersection.Key, IMAGE_EXTENSION);
                string intersectionFilePath = Path.Combine(destinationPath, IMAGE_STORAGE_DIRECTORY, intersectionFileName);
                bitmapIntersection.Value.Save(intersectionFilePath);
            }
        }

        /// <summary>
        /// ファイルをコピーする
        /// </summary>
        /// <param name="srcPath">コピー元ファイルパス</param>
        /// <param name="dstPath">コピー先ファイルパス</param>
        private void copyFile(string srcPath, string dstPath)
        {
            try
            {
                File.Copy(srcPath, dstPath, true);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"画像展開エラー {srcPath} to {dstPath} : {ex.Message}");
            }
        }

        /// <summary>
        /// 路線HTMLファイルを展開する
        /// </summary>
        /// <param name="drivingInfoId">走行基本情報ID</param>
        /// <param name="inputPath">コピー元路線HTML格納ディレクトリパス</param>
        /// <param name="destinationPath">展開先ディレクトリパス</param>
        /// <param name="intersectionInfos">真値の座標リスト</param>
        /// <param name="importedCoordinates">インポートされた座標リスト</param>
        /// <param name="beaconDataVersion">版</param>
        /// <returns></returns>
        private string deployRouteHtmlFile(int drivingInfoId, string inputPath, string destinationPath, List<DatabaseAccessor.StIntersectionInfo> intersectionInfos, List<ImportedCoordinate> importedCoordinates, DatabaseAccessor.EvaluationVersion beaconDataVersion)
        {
            // コピー元の路線HTMLファイルパスを取得
            string routeName = Path.GetFileName(inputPath);
            int routeNumber;
            int.TryParse(routeName.Replace(ROUTE_NAME_BASE, ""), out routeNumber);
            string srcHtmlFileName = Path.ChangeExtension(ROUTE_NAME_BASE + routeNumber.ToString(), HTML_EXTENSION);
            string srcHtmlFilePath = Path.Combine(inputPath, srcHtmlFileName);

            // 展開先の路線HTMLファイルパスを作成する
            string dstHtmlFileName = DataExporter.makeExporteFilepath(drivingInfoId, dataBaseAccessor, DataExporter.ExportType.MapHTML);
            string dstHtmlFilePath = Path.Combine(destinationPath, dstHtmlFileName);

            try
            {
                // 展開先ディレクトリパスを作成する
                makeDeployDirectory(destinationPath);

                // 路線HTMLファイルを作成する
                makeIntersectionHtmlFile(intersectionInfos, importedCoordinates, beaconDataVersion, srcHtmlFilePath, dstHtmlFilePath);
            }
            catch (Exception e)
            {
                // エラー処理
                Console.WriteLine(e);

                // 評価履歴テーブルにエラーコードを挿入
                htmlErrInsertEvaluationHistory(drivingInfoId, DataExporter.ExportType.MapHTML);
            }
            // 作成した路線HTMLファイルパスを返却
            return dstHtmlFilePath;
        }

        /// <summary>
        /// 路線HTMLファイルを作成する
        /// </summary>
        /// <param name="intersectionInfos">真値の座標リスト</param>
        /// <param name="importedCoordinates">インポートされた座標リスト</param>
        /// <param name="beaconDataVersion">版</param>
        /// <param name="srcHtmlFilePath">読み込み元のHTMLファイルパス</param>
        /// <param name="dstHtmlFilePath">インポート座標追記先のHTMLファイルパス</param>
        private void makeIntersectionHtmlFile(List<DatabaseAccessor.StIntersectionInfo> intersectionInfos, List<ImportedCoordinate> importedCoordinates, DatabaseAccessor.EvaluationVersion beaconDataVersion, string srcHtmlFilePath, string dstHtmlFilePath)
        {
            // StreamReaderを生成する
            using (var streamReader = new StreamReader(srcHtmlFilePath, Encoding.Default))
            // StreamWriterを生成する
            using (var streamWriter = new StreamWriter(dstHtmlFilePath, false, Encoding.Default))
            {
                // HTMLへの追記検索モード
                SeekHtmlMode seekHtmlMode = SeekHtmlMode.SeekDocktype; // まずはDOCTYPEタグ開始を検索

                // 読み込みできる文字がなくなるまで繰り返す
                while (streamReader.Peek() >= 0)
                {
                    // ファイルを 1 行ずつ読み込む
                    string stringBuffer = streamReader.ReadLine();

                    // aMapFitBounds関数コールを検出時は、
                    if (stringBuffer == SEEK_HTML_AMAPFITBOUNDS)
                    {
                        // initialize関数の末尾の括弧を削除する
                        deleteTrailingParenthesisInitialize(streamWriter);
                    }
                    // 上記以外は、
                    else
                    {
                        // 読み込んだ1行をファイルに書き込む
                        streamWriter.WriteLine(stringBuffer);
                    }

                    // HTMLへの追記キーワードをチェック
                    switch (seekHtmlMode)
                    {
                    case SeekHtmlMode.SeekDocktype:                   // DOCTYPEタグ開始を検索
                        if (stringBuffer == SEEK_HTML_DOCTYPE)
                        {
                            // ActiveX実行時のセキュリティ保護警告抑止用文字列を追加
                            appendSequrityWarningSuppressionString(streamWriter);
                            seekHtmlMode = SeekHtmlMode.SeekImageStart;
                        }
                        break;
                    case SeekHtmlMode.SeekImageStart:                   // imageタグ開始を検索
                        if (stringBuffer == SEEK_HTML_IMAGE_START)
                        {
                            seekHtmlMode = SeekHtmlMode.SeekImageEnd;
                        }
                        break;
                    case SeekHtmlMode.SeekImageEnd:                   // imageタグ終了を検索
                        if (stringBuffer == SEEK_HTML_IMAGE_END)
                        {
                            // imageタグに続けてbeaconMarkerImageタグ、intersectionMarkerImageタグを追加
                            appendBeaconMarkerImage(streamWriter, beaconDataVersion);
                            appendIntersectionMarkerImage(streamWriter, importedCoordinates);
                            seekHtmlMode = SeekHtmlMode.SeekLineItem;
                        }
                        break;
                    case SeekHtmlMode.SeekLineItem:                // lineitem2タグを検索
                        if (stringBuffer == SEEK_HTML_LINEITEM2)
                        {
                            // lineitem2タグに続けてlineitem3タグ、lineitem4タグを追加
                            appendLineitem3(streamWriter);
                            appendLineitem4(streamWriter);
                            seekHtmlMode = SeekHtmlMode.SeekSetmarkersGpsdata;
                        }
                        break;
                    case SeekHtmlMode.SeekSetmarkersGpsdata:       // setMarkers関数コールのgpsdata2キーワードを検索
                        if (stringBuffer == SEEK_HTML_SETMARKERS_GPSDATA2)
                        {
                            // gpsdata2に続けてgpsdata3、gpsdata4のaddMarker関数コールを追加
                            appendAddMarkerGpsdata3(streamWriter);
                            appendAddMarkerGpsdata4(streamWriter);
                            seekHtmlMode = SeekHtmlMode.SeekPolylineGpsdata;
                        }
                        break;
                    case SeekHtmlMode.SeekPolylineGpsdata:         // Polyline関数コールのlineitem2キーワードを検索
                        if (stringBuffer == SEEK_HTML_POLYLINE_GPSDATA2)
                        {
                            // lineitem2に続けてlineitem3、lineitem4のPolyline関数コールを追加
                            appendPolylineGpsdata3(streamWriter);
                            appendPolylineGpsdata4(streamWriter);
                            seekHtmlMode = SeekHtmlMode.SeekAMapFitBounds;
                        }
                        break;

                    case SeekHtmlMode.SeekAMapFitBounds:       // aMapFitBounds関数コールを検索
                        if (stringBuffer == SEEK_HTML_AMAPFITBOUNDS)
                        {
                            // aMapFitBoundsに続けてloadDone関数コールを追加
                            appendAddLoadDoneCall(streamWriter);
                            // 更に、initialize関数の末尾に括弧を追加する
                            appendTrailingParenthesisInitialize(streamWriter);
                            seekHtmlMode = SeekHtmlMode.SeekGpsdataStart;
                        }
                        break;

                    case SeekHtmlMode.SeekGpsdataStart:                 // gpsdata2タグ開始を検索
                        if (stringBuffer == SEEK_HTML_GPSDATA2_START)
                        {
                            seekHtmlMode = SeekHtmlMode.SeekGpsdataEnd;
                        }
                        break;
                    case SeekHtmlMode.SeekGpsdataEnd:                 // gpsdata2タグ終了を検索
                        if (stringBuffer == SEEK_HTML_GPSDATA2_END)
                        {
                            // gpsdata2タグに続けてgpsdata3タグ、gpsdata4タグを追加
                            appendGpsdata3(streamWriter, intersectionInfos, importedCoordinates, beaconDataVersion);
                            appendGpsdata4(streamWriter, intersectionInfos, importedCoordinates, beaconDataVersion);
                            seekHtmlMode = SeekHtmlMode.SeekSetmarkersStart;
                        }
                        break;
                    case SeekHtmlMode.SeekSetmarkersStart:              // setMarkers関数開始を検索
                        if (stringBuffer == SEEK_HTML_SETMARKERS_START)
                        {
                            seekHtmlMode = SeekHtmlMode.SeekSetmarkersEnd1;
                        }
                        break;
                    case SeekHtmlMode.SeekSetmarkersEnd1:              // setMarkers関数終了1を検索
                        if (stringBuffer == SEEK_HTML_SETMARKERS_END_1ST)
                        {
                            seekHtmlMode = SeekHtmlMode.SeekSetmarkersEnd2;
                        }
                        break;
                    case SeekHtmlMode.SeekSetmarkersEnd2:              // setMarkers関数終了2を検索
                        if (stringBuffer == SEEK_HTML_SETMARKERS_END_2ND)
                        {
                            // setMarkersに続けてaddMarkerを追加
                            appendAddMarker(streamWriter);
                            seekHtmlMode = SeekHtmlMode.SeekAMapFitBoundsStart;
                        }
                        break;

                    case SeekHtmlMode.SeekAMapFitBoundsStart:              // aMapFitBounds関数開始を検索
                        if (stringBuffer == SEEK_HTML_AMAPFITBOUNDS_START)
                        {
                            seekHtmlMode = SeekHtmlMode.SeekAMapFitBoundsEnd1;
                        }
                        break;
                    case SeekHtmlMode.SeekAMapFitBoundsEnd1:              //  aMapFitBounds関数終了1を検索
                        if (stringBuffer == SEEK_HTML_AMAPFITBOUNDS_END_1ST)
                        {
                            seekHtmlMode = SeekHtmlMode.SeekAMapFitBoundsEnd2;
                        }
                        break;
                    case SeekHtmlMode.SeekAMapFitBoundsEnd2:              // aMapFitBounds関数終了2を検索
                        if (stringBuffer == SEEK_HTML_AMAPFITBOUNDS_END_2ND)
                        {
                            // aMapFitBoundsに続けてloadDoneを追加
                            appendAddLoadDone(streamWriter);
                            seekHtmlMode = SeekHtmlMode.None;              ///< 検索しない
                        }
                        break;

                    }
                }

                // StreamWriterを閉じる
                streamWriter.Close();
                // StreamReaderを生成する
                streamReader.Close();
            }

        }

        /// <summary>
        /// ActiveX実行時のセキュリティ保護警告抑止用文字列を追加
        /// </summary>
        /// <param name="streamWriter">出力HTMLファイル書き込み用のストリーム</param>
        /// <remarks>(セキュリティ保護警告抑止用文字列はDOCTYPEの次行に記載する)</remarks>
        /// <remarks>(HTMLをブラウザ表示する際のスクリプトエラーを無視するために必要)</remarks>
        private void appendSequrityWarningSuppressionString(StreamWriter streamWriter)
        {
            streamWriter.WriteLine(@"<!-- saved from url = (0017)http://localhost/ -->");
        }

        /// <summary>
        /// ビーコンマーカーの画像リスト記述を追加する
        /// </summary>
        /// <param name="streamWriter">出力HTMLファイル書き込み用のストリーム</param>
        /// <param name="beaconDataVersion">インポートデータの版</param>
        private void appendBeaconMarkerImage(StreamWriter streamWriter, DatabaseAccessor.EvaluationVersion beaconDataVersion)
        {
            streamWriter.WriteLine(@"var beaconMarkerImage = [");

            if (beaconDataVersion == DatabaseAccessor.EvaluationVersion.Version2)
            {
                // 版2のみビーコンマーカーアイコンを指定する
                streamWriter.WriteLine(@"new google.maps.MarkerImage('markerIcon/beacon_00.png', new google.maps.Size(21, 34), new google.maps.Point(0, 0), new google.maps.Point(10, 34))");
            }

            streamWriter.WriteLine(@"];");
        }

        /// <summary>
        /// 交差点マーカーの画像リスト記述を追加する
        /// </summary>
        /// <param name="streamWriter">出力HTMLファイル書き込み用のストリーム</param>
        /// <param name="importedCoordinates">インポートされた座標リスト</param>
        private void appendIntersectionMarkerImage(StreamWriter streamWriter, List<ImportedCoordinate> importedCoordinates)
        {
            streamWriter.WriteLine(@"var intersectionMarkerImage = [");

            int intersectionMaxCount = importedCoordinates.Count();
            int intersectionCounter = 0;
            foreach (var importedCoordinate in importedCoordinates)
            {
                // 先頭はビーコン座標のため読み飛ばし
                if (intersectionCounter == 0)
                {
                    ++intersectionCounter;
                    continue;
                }

                // 2つ目以降の交差点座標を読み込む
                var intersectionLat = importedCoordinate.Coordinate.X;
                var intersectionLon = importedCoordinate.Coordinate.Y;
                var intersectionIndex = importedCoordinate.OriginalCoordinateIndex;     // 真値交差点のIndex
                string writeString = $@"new google.maps.MarkerImage('markerIcon/intersection_{intersectionIndex:00}.png', new google.maps.Size(21, 34), new google.maps.Point(0,0), new google.maps.Point(10, 34))";
                // カンマを追加
                if (++intersectionCounter != intersectionMaxCount)
                    writeString += ",";     // 最終行でなければ「,」を付ける
                // ファイルに1行書き込む
                streamWriter.WriteLine(writeString);
            }

            streamWriter.WriteLine(@"];");
        }

        /// <summary>
        /// ビーコンマーカー連結ライン描画用の定義記述を追加する
        /// </summary>
        /// <param name="streamWriter">出力HTMLファイル書き込み用のストリーム</param>
        private void appendLineitem3(StreamWriter streamWriter)
        {
            streamWriter.WriteLine(@"var lineitem3 = [];");

        }

        /// <summary>
        /// 交差点マーカー連結ライン描画用の定義記述を追加する
        /// </summary>
        /// <param name="streamWriter">出力HTMLファイル書き込み用のストリーム</param>
        private void appendLineitem4(StreamWriter streamWriter)
        {
            streamWriter.WriteLine(@"var lineitem4 = [];");
        }

        /// <summary>
        /// ビーコンマーカーをプロットするためのメソッド呼び出し記述を追加する
        /// </summary>
        /// <param name="streamWriter">出力HTMLファイル書き込み用のストリーム</param>
        private void appendAddMarkerGpsdata3(StreamWriter streamWriter)
        {
            streamWriter.WriteLine(@"addMarker(map, gpsdata3, beaconMarkerImage);");
        }

        /// <summary>
        /// 交差点マーカーをプロットするためのメソッド呼び出し記述を追加する
        /// </summary>
        /// <param name="streamWriter">出力HTMLファイル書き込み用のストリーム</param>
        private void appendAddMarkerGpsdata4(StreamWriter streamWriter)
        {
            streamWriter.WriteLine(@"addMarker(map, gpsdata4, intersectionMarkerImage);");
        }

        /// <summary>
        /// ビーコンマーカー連結ライン描画用の記述を追加する
        /// </summary>
        /// <param name="streamWriter">出力HTMLファイル書き込み用のストリーム</param>
        private void appendPolylineGpsdata3(StreamWriter streamWriter)
        {
            streamWriter.WriteLine(@"new google.maps.Polyline({path: lineitem3, strokeColor: '#007200', strokeOpacity: 1.0, strokeWeight: 2, map: map});");
        }

        /// <summary>
        /// 交差点マーカー連結ライン描画用の記述を追加する
        /// </summary>
        /// <param name="streamWriter">出力HTMLファイル書き込み用のストリーム</param>
        private void appendPolylineGpsdata4(StreamWriter streamWriter)
        {
            streamWriter.WriteLine(@"new google.maps.Polyline({path: lineitem4, strokeColor: '#0000FF', strokeOpacity: 1.0, strokeWeight: 2, map: map});");
        }

        /// <summary>
        /// initialize関数の末尾の括弧を削除する
        /// </summary>
        /// <param name="streamWriter">出力HTMLファイル書き込み用のストリーム</param>
        private void deleteTrailingParenthesisInitialize(StreamWriter streamWriter)
        {
            streamWriter.WriteLine(SEEK_HTML_AMAPFITBOUNDS.Replace(@"}", @""));  // aMapFitBounds関数コールの検出ワード行の末尾の'}'を削除
            //streamWriter.WriteLine(@"aMapFitBounds(map, FitBounds);");
            //streamWriter.WriteLine(@"}");
        }

        /// <summary>
        /// HTML読み込み完了をアプリケーションに通知するためのメソッド呼び出し記述を追加する
        /// </summary>
        /// <param name="streamWriter">出力HTMLファイル書き込み用のストリーム</param>
        private void appendAddLoadDoneCall(StreamWriter streamWriter)
        {
            // NOTE:このタイミングでは、まだロード完了になっていない。
            // NOTE;厳密にロード完了タイミングを知る方法が判明するまでは、ディレイ時間で
            // NOTE:対応することとし、ブラウザアプリへの通知はコメントアウトしておく。

            //streamWriter.WriteLine(@"loadDone();");
        }

        /// <summary>
        /// initialize関数の末尾に括弧を追加する
        /// </summary>
        /// <param name="streamWriter">出力HTMLファイル書き込み用のストリーム</param>
        private void appendTrailingParenthesisInitialize(StreamWriter streamWriter)
        {
            streamWriter.WriteLine(@"}");
        }

        /// <summary>
        /// ビーコンマーカーをプロットする座標リスト記述を追加する
        /// </summary>
        /// <param name="streamWriter">出力HTMLファイル書き込み用のストリーム</param>
        /// <param name="intersectionInfos">真値の座標リスト</param>
        /// <param name="importedCoordinates">インポートされた座標リスト</param>
        /// <param name="beaconDataVersion">インポートデータの版</param>
        private void appendGpsdata3(StreamWriter streamWriter, List<DatabaseAccessor.StIntersectionInfo> intersectionInfos, List<ImportedCoordinate> importedCoordinates, DatabaseAccessor.EvaluationVersion beaconDataVersion)
        {
            streamWriter.WriteLine(@"var gpsdata3 = [");

            // 版2のみ、座標を読み込む
            if (beaconDataVersion == DatabaseAccessor.EvaluationVersion.Version2)
            {
                var beaconLat = importedCoordinates[0].Coordinate.X;
                var beaconLon = importedCoordinates[0].Coordinate.Y;
                streamWriter.WriteLine($@"[{beaconLat},{beaconLon},'Beacon_取得データ']");
            }

            streamWriter.WriteLine(@"];");
        }

        /// <summary>
        /// 交差点マーカーをプロットする座標リスト記述を追加する
        /// </summary>
        /// <param name="streamWriter">出力HTMLファイル書き込み用のストリーム</param>
        /// <param name="intersectionInfos">真値の座標リスト</param>
        /// <param name="importedCoordinates">インポートされた座標リスト</param>
        /// <param name="beaconDataVersion">インポートデータの版</param>
        private void appendGpsdata4(StreamWriter streamWriter, List<DatabaseAccessor.StIntersectionInfo> intersectionInfos, List<ImportedCoordinate> importedCoordinates, DatabaseAccessor.EvaluationVersion beaconDataVersion)
        {
            streamWriter.WriteLine(@"var gpsdata4 = [");

            int intersectionMaxCount = importedCoordinates.Count();
            int intersectionCounter = 0;
            foreach (var importedCoordinate in importedCoordinates)
            {
                // 先頭はビーコン座標のため読み飛ばし
                if (intersectionCounter == 0)
                {
                    ++intersectionCounter;
                    continue;
                }

                // 2つ目以降の交差点座標を読み込む
                var intersectionLat = importedCoordinate.Coordinate.X;
                var intersectionLon = importedCoordinate.Coordinate.Y;
                var intersectionIndex = importedCoordinate.OriginalCoordinateIndex;     // 真値交差点のIndex
                string writeString = $@"[{intersectionLat},{intersectionLon},'交差点位置情報({intersectionIndex})_取得データ']";
                // カンマを追加
                if (++intersectionCounter != intersectionMaxCount)
                    writeString += ",";     // 最終行でなければ「,」を付ける
                // ファイルに1行書き込む
                streamWriter.WriteLine(writeString);
            }

            streamWriter.WriteLine(@"];");
        }

        /// <summary>
        /// マーカーをプロットするためのメソッド記述を追加する
        /// </summary>
        /// <param name="streamWriter">出力HTMLファイル書き込み用のストリーム</param>
        private void appendAddMarker(StreamWriter streamWriter)
        {
            streamWriter.WriteLine(@"function addMarker(map, locations, image) {");
            streamWriter.WriteLine(@"  for (var i = 0; i < locations.length; i++) {");
            streamWriter.WriteLine(@"    var marker = new google.maps.Marker({");
            streamWriter.WriteLine(@"      position: new google.maps.LatLng(locations[i][0], locations[i][1]),");
            streamWriter.WriteLine(@"      icon: image[i],");
            streamWriter.WriteLine(@"      title: locations[i][2],");
            streamWriter.WriteLine(@"      map: map");
            streamWriter.WriteLine(@"    });");
            streamWriter.WriteLine(@"  }");
            streamWriter.WriteLine(@"}");
        }

        /// <summary>
        /// HTML読み込み完了をプラウザアプリケーションに通知するためのメソッド記述を追加する
        /// </summary>
        /// <param name="streamWriter">出力HTMLファイル書き込み用のストリーム</param>
        private void appendAddLoadDone(StreamWriter streamWriter)
        {
            // NOTE:このタイミングでは、まだロード完了になっていない。
            // NOTE;厳密にロード完了タイミングを知る方法が判明するまでは、ディレイ時間で
            // NOTE:対応することとし、ブラウザアプリへの通知はコメントアウトしておく。

            //streamWriter.WriteLine(@"function loadDone()");
            //streamWriter.WriteLine(@"{");

            //// ファイル名を通知
            //streamWriter.WriteLine(@"  //ブラウザアプリにロード完了を通知します。");
            //streamWriter.WriteLine(@"  var filename = window.location.href.split('/').pop();");
            //streamWriter.WriteLine(@"  window.external.NotifiedCompletionFromHTML(filename);");

            //streamWriter.WriteLine(@"}");
        }

        /// <summary>
        /// 交差点画像ファイルを展開する
        /// </summary>
        /// <param name="htmlFilePath">HTMLファイルパス</param>
        /// <returns></returns>
        private string deployIntersectionImageFile(int drivingInfoId, string htmlFilePath)
        {
            imageFilePath = @"";        // 作成された交差点画像ファイル名

            try
            {
                // 交差点画像ファイル生成失敗フラグ:OFF
                imageFileCreateFailed = false;

                // HTMLブラウザをオープン
                if (mainWindowDispatcher.CheckAccess())
                {
                    htmlBrowserOpen(htmlFilePath);
                }
                else
                {
                    mainWindowDispatcher.Invoke(() => htmlBrowserOpen(htmlFilePath));
                }

                // HTMLブラウザで画像表示が完了するのを待つ
                while (imageFilePath == @"" || imageFileCreateFailed)
                    Thread.Sleep(100);

                // HTMLブラウザをクローズ
                if (mainWindowDispatcher.CheckAccess())
                {
                    htmlBrowserClose();
                }
                else
                {
                    mainWindowDispatcher.Invoke(() => htmlBrowserClose());
                }
            }
            catch (Exception e)
            {
                // エラー処理
                Console.WriteLine(e);

                // 評価履歴テーブルにエラーコードを挿入
                htmlErrInsertEvaluationHistory(drivingInfoId, DataExporter.ExportType.MapImage);
            }
            // 交差点画像ファイル名を返却
            return imageFilePath;
        }

        /// <summary>
        /// HTMLブラウザを初期化
        /// </summary>
        void htmlBrowserInitialize()
        {
            // HTMLブラウザをクローズ
            htmlBrowserClose();
        }

        /// <summary>
        /// HTMLブラウザをオープン
        /// </summary>
        /// <param name="htmlFilePath">入力HTMLファイルパス</param>
        void htmlBrowserOpen(string htmlFilePath)
        {
            // 交差点HTMLブラウザを生成
            browser = new IntersectionHtmlBrowser(mainWindowDispatcher);
            // 交差点HTMLブラウザのコールバック登録
            browser.OnHtmlLoaded = ((filepath) =>
            {
                if (filepath != "")
                {
                    // 生成された交差点画像ファイルパスを保持
                    imageFilePath = filepath;
                }
                else
                {
                    // 交差点画像ファイルパスをクリア(作成失敗を保持)
                    imageFilePath = "";
                    // 交差点画像ファイル生成失敗フラグ:ON
                    imageFileCreateFailed = true;
                }
            });
            browser.OnHtmlClosed = (() =>
            {
                // HTMLブラウザをクローズ
                htmlBrowserClose();
            });
            // 交差点HTMLブラウザに入力HTMLファイルパスを登録
            browser.SetHtmlFilepath(htmlFilePath);

            // 交差点HTMLブラウザを表示
            browser.Show();
        }

        /// <summary>
        /// HTMLブラウザをクローズ
        /// </summary>
        void htmlBrowserClose()
        {
            // 交差点HTMLブラウザをクローズ
            if (browser != null)
                browser.Close();
            browser = null;
        }

        /// <summary>
        /// HTML、JPEGファイル出力エラー時、評価履歴テーブルにエラーコードを挿入する
        /// </summary>
        /// <param name="drivingInfoId">走行情報ID</param>
        private void htmlErrInsertEvaluationHistory(int drivingInfoId, DataExporter.ExportType exportCsvType)
        {
            // 評価実施履歴IDを採番(評価実施履歴の主キーを取得)
            int evaluationHistoryId = getEvaluationHistoryId(drivingInfoId);

            // 評価完了時点の時刻を取得して、評価実施日時とする
            var evaluatedTimestamp = DateTime.Now;

            // エラーコード取得
            var evalStatus = DatabaseAccessor.EvaluationStatus.EvaluateNormal_NoneNG;

            if (exportCsvType == DataExporter.ExportType.MapHTML)
            {
                evalStatus = DatabaseAccessor.EvaluationStatus.ExportError_HtmlMakeError;
            }
            else if (exportCsvType == DataExporter.ExportType.MapImage)
            {
                evalStatus = DatabaseAccessor.EvaluationStatus.ExportError_HtmlCaptureError;
            }

            // エラーを評価履歴テーブルに書き込み
            dataBaseAccessor.InsertEvaluationImplementationHistory(drivingInfoId, evaluationHistoryId, evaluatedTimestamp, evalStatus);
        }
        /// <summary>
        /// 評価実施履歴IDを採番
        /// </summary>
        /// <returns>評価実施履歴ID</returns>
        /// <remarks>評価実施履歴の主キーを取得する</remarks>
        private int getEvaluationHistoryId(int drivingInfoId)
        {
            // DBから最新の評価実施履歴IDを取得して、インクリメントした値を返却する
            return dataBaseAccessor.GetLatestEvaluationHistoryId(drivingInfoId) + 1;
        }
    }
}
