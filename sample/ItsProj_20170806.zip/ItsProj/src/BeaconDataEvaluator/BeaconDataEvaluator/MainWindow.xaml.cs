﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;
using Microsoft.WindowsAPICodePack.Dialogs;    // for use CommonOpenFileDialog, CommonFileDialogResult

namespace BeaconDataEvaluator
{
    /// <summary>
    /// MainWindow.xaml の相互作用ロジック
    /// </summary>
    /// <remarks>高度化光インフラデータ解析アプリのメイン画面</remarks>
    public partial class MainWindow : Window
    {
        private Controller controller;              ///< 高度化光インフラデータ解析制御クラス
        private DispatcherTimer timerPollingStatus; ///< 評価状況ポーリングタイマ

        /// コンストラクタ
        public MainWindow()
        {
            InitializeComponent();

            // データ評価クラスを生成
            controller = new Controller(Application.Current.Dispatcher);
            controller.OnDone = doneEvaluate;

            // 評価状況ポーリングタイマを生成
            timerPollingStatus = new DispatcherTimer(DispatcherPriority.Normal);
            timerPollingStatus.Interval = new TimeSpan(0, 0, 0, 0, 50);
            timerPollingStatus.Tick += new EventHandler(timerPollingStatus_Tick);

            // 評価状況を初期表示する
            updateStatus();
        }

        /// デストラクタ
        ~MainWindow()
        {
            // 評価状況ポーリングを停止する
            stopTimerPollingStatus();

            // データ評価クラスを中断する
            controller.Cancel();
        }

        /// <summary>
        /// 評価完了コールバック処理
        /// </summary>
        /// <param name="result"></param>
        private void doneEvaluate(Controller.TaskResultCode result)
        {
            // 評価状況ポーリングを停止する
            Dispatcher.Invoke(stopTimerPollingStatus);
            // 評価状況を表示する
            Dispatcher.Invoke(updateStatus);

            // 評価キャンセル/失敗時は、画面配置コントロール表示を有効化しておく
            switch (result)
            {
            case Controller.TaskResultCode.Cancel:      // キャンセル
            case Controller.TaskResultCode.Failure:     // 失敗
                { 
                    // 画面配置コントロールの表示有効化
                    Dispatcher.Invoke(() => { setEnablePlacedControls(true); });
                }
                break;
            }

        }

        /// <summary>
        /// 評価状況ポーリングを開始する
        /// </summary>
        private void startTimerPollingStatus()
        {
            // 評価状況ポーリングタイマを開始
            timerPollingStatus.Start();
        }

        /// <summary>
        /// 評価状況ポーリングを停止する
        /// </summary>
        private void stopTimerPollingStatus()
        {
            // 評価状況ポーリングタイマを終了
            timerPollingStatus.Stop();
        }

        /// <summary>
        /// 評価状況を表示する
        /// </summary>
        private void updateStatus()
        {
            // 評価状況を取得
            var controllerStatus = controller.GetStatus();

            // 評価状況テキストを更新する
            setStatusText(controllerStatus);
            // 評価状況テキスト色を設定する
            setStatusTextColor(controllerStatus);

            switch (controllerStatus.Status)
            {
            case Controller.RunStatuses.Counting:       // 評価総数カウント中
            case Controller.RunStatuses.Importing:      // インポート実行中
            case Controller.RunStatuses.Evaluating:     // 評価実行中
            case Controller.RunStatuses.Exporting:      // エクスポート実行中
                // 画面配置コントロールの表示無効化
                setEnablePlacedControls(false);
                break;
            case Controller.RunStatuses.Idle:           // 開始待ち
            default:
                // 画面配置コントロールの表示有効化
                setEnablePlacedControls(true);
                break;
            }
        }

        /// <summary>
        /// 評価状況テキストを更新する
        /// </summary>
        /// <param name="status">データ評価実行状態</param>
        private void setStatusText(Controller.RunStatus status)
        {
            // ステータスの進捗状況のテキストを変更
            labelStatusImportProgress.Content = "( " + status.currentImportCount.ToString() + "/" + status.totalEvaluateCount.ToString() + " ファイル )";
            labelStatusEvaluateProgress.Content = "( " + status.currentEvaluateCount.ToString() + "/" + status.totalEvaluateCount.ToString() + " ファイル )";
            labelStatusExportProgress.Content = "( " + status.currentExportCount.ToString() + "/" + status.totalEvaluateCount.ToString() + " ファイル )";
            labelBasicTripInformationValue.Content = status.PrefecturesName + " " + status.RouteName + " " + status.BeaconDataVersion + " " + status.DrivingDatetime;
        }

        /// <summary>
        /// 評価状況テキスト色を設定する
        /// </summary>
        /// <param name="status">データ評価実行状態</param>
        private void setStatusTextColor(Controller.RunStatus status)
        {
            // ラベル色を黒に設定
            Color labelColorImport = Colors.Black;
            Color labelColorEvaluate = Colors.Black;
            Color labelColorExport = Colors.Black;

            // インポート処理のラベル色を青に変更
            if ((status.currentImportCount != 0) && (status.currentImportCount == status.totalEvaluateCount))
                labelColorImport = Colors.Blue;
            // 評価処理のラベル色を青に変更
            if ((status.currentEvaluateCount != 0) && (status.currentEvaluateCount == status.totalEvaluateCount))
                labelColorEvaluate = Colors.Blue;
            // エクスポート処理のラベル色を青に変更
            if ((status.currentExportCount != 0) && (status.currentExportCount == status.totalEvaluateCount))
                labelColorExport = Colors.Blue;

            // ステータスの処理名のラベル色を変更
            labelStatusImportText.Foreground = new SolidColorBrush(labelColorImport);           // ステータスの処理名
            labelStatusEvaluateText.Foreground = new SolidColorBrush(labelColorEvaluate);       // ステータスの処理名
            labelStatusExportText.Foreground = new SolidColorBrush(labelColorExport);           // ステータスの処理名
            // ステータスの進捗状況のラベル色を変更
            labelStatusImportProgress.Foreground = new SolidColorBrush(labelColorImport);       // ステータスの進捗状況
            labelStatusEvaluateProgress.Foreground = new SolidColorBrush(labelColorEvaluate);   // ステータスの進捗状況
            labelStatusExportProgress.Foreground = new SolidColorBrush(labelColorExport);       // ステータスの進捗状況
        }

        /// <summary>
        /// 画面配置コントロールの有効/無効切り替え
        /// </summary>
        /// <param name="enable">true:表示有効,false:表示無効</param>
        void setEnablePlacedControls(bool enable)
        {
            // 画面に配置されたコントロールの有効/無効を切り替える
            textBoxInputPath.IsEnabled = enable;        // 出力情報フォルダパステキストボックス
            buttonInputPath.IsEnabled = enable;         // 出力情報フォルダパス参照ボタン
            textBoxOutputPath.IsEnabled = enable;       // 出力情報フォルダパステキストボックス
            buttonOutputPath.IsEnabled = enable;        // 出力情報フォルダパス参照ボタン
            buttonEvaluate.IsEnabled = enable;          // 評価開始ボタン
        }
        /// <summary>
        /// アプリケーション設定情報を保存する
        /// </summary>
        private void saveApplicationSetting()
        {
            // 入出力情報フォルダパスを保存する
            Properties.Settings.Default.InputPath = textBoxInputPath.Text;
            Properties.Settings.Default.OutputPath = textBoxOutputPath.Text;
            Properties.Settings.Default.Save();
        }

        /// <summary>
        /// アプリケーション設定情報を復元する
        /// </summary>
        private void loadApplicationSetting()
        {
            // 入出力情報フォルダパスを復元する
            if (Properties.Settings.Default.InputPath == "")
                textBoxInputPath.Text = @"C:\光インフラデータ\INPUT";
            else
                textBoxInputPath.Text = Properties.Settings.Default.InputPath;

            if (Properties.Settings.Default.InputPath == "")
                textBoxOutputPath.Text = @"C:\光インフラデータ\OUTPUT";
            else
                textBoxOutputPath.Text = Properties.Settings.Default.OutputPath;
        }

        /// <summary>
        /// ウィンドウロード完了イベント
        /// </summary>
        /// <param name="sender">イベント発生元</param>
        /// <param name="e">イベントパラメータ</param>
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            // アプリケーション設定情報を復元する
            loadApplicationSetting();
        }

        /// <summary>
        /// ウィンドウ終了処理中イベント
        /// </summary>
        /// <param name="sender">イベント発生元</param>
        /// <param name="e">イベントパラメータ</param>
        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            // アプリケーション設定情報を保存する
            saveApplicationSetting();
        }

        /// <summary>
        /// 評価状況ポーリングタイマの周期起動イベント
        /// </summary>
        /// <param name="sender">イベント発生元</param>
        /// <param name="e">イベントパラメータ</param>
        void timerPollingStatus_Tick(object sender, EventArgs e)
        {
            // 評価状況を表示する
            Dispatcher.Invoke(updateStatus);
        }

        /// <summary>
        /// 入力情報フォルダパス参照ボタン押下イベント
        /// </summary>
        /// <param name="sender">イベント発生元</param>
        /// <param name="e">イベントパラメータ</param>
        private void buttonInputPath_Click(object sender, RoutedEventArgs e)
        {
            // ダイアログのインスタンスを生成
            var dialog = new CommonOpenFileDialog("入力情報フォルダの選択");
            // 選択形式をフォルダースタイルにする IsFolderPicker プロパティを設定
            dialog.IsFolderPicker = true;
            dialog.DefaultDirectory = System.IO.Path.GetDirectoryName(textBoxInputPath.Text);
            // ダイアログを表示
            if (dialog.ShowDialog() == CommonFileDialogResult.Ok)
            {
                // 選択したパスを表示する
                textBoxInputPath.Text = dialog.FileName;
            }
        }

        /// <summary>
        /// 出力情報フォルダパス参照ボタン押下イベント
        /// </summary>
        /// <param name="sender">イベント発生元</param>
        /// <param name="e">イベントパラメータ</param>
        private void buttonOutputPath_Click(object sender, RoutedEventArgs e)
        {
            // ダイアログのインスタンスを生成
            var dialog = new CommonOpenFileDialog("出力情報フォルダの選択");
            // 選択形式をフォルダースタイルにする IsFolderPicker プロパティを設定
            dialog.IsFolderPicker = true;
            dialog.DefaultDirectory = System.IO.Path.GetDirectoryName(textBoxOutputPath.Text);
            // ダイアログを表示
            if (dialog.ShowDialog() == CommonFileDialogResult.Ok)
            {
                // 選択したパスを表示する
                textBoxOutputPath.Text = dialog.FileName;
            }
        }

        /// <summary>
        /// 評価開始/キャンセルボタン押下イベント
        /// </summary>
        /// <param name="sender">イベント発生元</param>
        /// <param name="e">イベントパラメータ</param>
        private void buttonEvaluate_Click(object sender, RoutedEventArgs e)
        {
            // 前回動作時のExcelゾンビプロセスを、評価前に強制終了しておく
            System.Diagnostics.Process[] ps = System.Diagnostics.Process.GetProcessesByName("EXCEL");
            foreach (System.Diagnostics.Process p in ps)
            {
                p.Kill();
            }

            // 入力情報フォルダ が存在しているかどうか確認する
            if ( System.IO.Directory.Exists(textBoxInputPath.Text))
            {
                // 出力情報フォルダ が存在しているかどうか確認する
                if (System.IO.Directory.Exists(textBoxOutputPath.Text))
                {
                    // 出力情報フォルダが存在しているため、削除して実行していいか質問する
                    System.Windows.Forms.DialogResult result = System.Windows.Forms.MessageBox.Show("出力情報フォルダがすでに存在しています。\nフォルダを削除し評価開始してよろしいですか？",
                        "警告", System.Windows.Forms.MessageBoxButtons.YesNo, System.Windows.Forms.MessageBoxIcon.Exclamation);
                    
                    // 「はい」画選択された場合、出力情報フォルダを削除し評価開始
                    if (result == System.Windows.Forms.DialogResult.Yes)
                    {
                        System.IO.Directory.Delete(textBoxOutputPath.Text, true);
                    }
                    else
                    {
                        //「いいえ」が選択された時
                        return;
                    }
                }
                // 評価状況ポーリングを開始する
                startTimerPollingStatus();
                // データ評価を開始する
                controller.Start(textBoxInputPath.Text, textBoxOutputPath.Text);
                // 評価状況表示を更新する
                updateStatus();
            }
            else
            {
                System.Windows.Forms.MessageBox.Show("入力情報フォルダが存在しません","警告", 
                    System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation);
            }
        }

        /// <summary>
        /// 入力情報フォルダパステキストボックスドラッグオーバイベント
        /// </summary>
        /// <param name="sender">イベント発生元</param>
        /// <param name="e">イベントパラメータ</param>
        private void textBoxInputPath_PreviewDragOver(object sender, DragEventArgs e)
        {
            // ドラッグしてテキストボックスに重なった時に、マウスポインタ表示を切り替える
            if (e.Data.GetDataPresent(System.Windows.DataFormats.FileDrop, true))
            {
                e.Effects = System.Windows.DragDropEffects.Copy;
            }
            else
            {
                e.Effects = System.Windows.DragDropEffects.None;
            }
            e.Handled = true;
        }

        /// <summary>
        /// 入力情報フォルダパステキストボックスドロップイベント
        /// </summary>
        /// <param name="sender">イベント発生元</param>
        /// <param name="e">イベントパラメータ</param>
        private void textBoxInputPath_PreviewDrop(object sender, DragEventArgs e)
        {
            // テキストボックス上でドロップした時に、テキストボックスにパス表示する
            var dropFiles = e.Data.GetData(System.Windows.DataFormats.FileDrop) as string[];
            if (dropFiles == null) return;
            textBoxInputPath.Text = dropFiles[0];
        }

        /// <summary>
        /// 出力情報フォルダパステキストボックスドラッグオーバイベント
        /// </summary>
        /// <param name="sender">イベント発生元</param>
        /// <param name="e">イベントパラメータ</param>
        private void textBoxOutputPath_PreviewDragOver(object sender, DragEventArgs e)
        {
            // ドラッグしてテキストボックスに重なった時に、マウスポインタ表示を切り替える
            if (e.Data.GetDataPresent(System.Windows.DataFormats.FileDrop, true))
            {
                e.Effects = System.Windows.DragDropEffects.Copy;
            }
            else
            {
                e.Effects = System.Windows.DragDropEffects.None;
            }
            e.Handled = true;
        }

        /// <summary>
        /// 出力情報フォルダパステキストボックスドロップイベント
        /// </summary>
        /// <param name="sender">イベント発生元</param>
        /// <param name="e">イベントパラメータ</param>
        private void textBoxOutputPath_PreviewDrop(object sender, DragEventArgs e)
        {
            // テキストボックス上でドロップした時に、テキストボックスにパス表示する
            var dropFiles = e.Data.GetData(System.Windows.DataFormats.FileDrop) as string[];
            if (dropFiles == null) return;
            textBoxOutputPath.Text = dropFiles[0];
        }
    }
}
