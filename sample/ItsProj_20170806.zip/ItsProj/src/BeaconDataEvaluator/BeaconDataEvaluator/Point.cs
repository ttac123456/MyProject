﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BeaconDataEvaluator
{
    /// <summary>
    /// 2次元座標クラス
    /// </summary>
    public class Point
    {
        public double X;        ///< x座標
        public double Y;        ///< y座標

        /// <summary>
        /// デフォルトコンストラクタ
        /// </summary>
        public Point()
        {
            X = 0;
            Y = 0;
        }

        /// <summary>
        /// 初期化コンストラクタ(x, y)
        /// </summary>
        /// <param name="x">2次元座標X</param>
        /// <param name="y">2次元座標Y</param>
        public Point(double x, double y)
        {
            X = x;
            Y = y;
        }

        /// <summary>
        /// コピーコンストラクタ(Point)
        /// </summary>
        /// <param name="previousCoordinate">コピー元の値</param>
        public Point(Point previousPoint)
        {
            this.X = previousPoint.X;
            this.Y = previousPoint.Y;
        }

        public override string ToString()
        {
            return "(" + X + ", " + Y + ")";
        }

    }
}
