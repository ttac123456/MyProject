﻿using Microsoft.Office.Interop.Excel;
using System;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using Microsoft.Office.Core;
using Excel = Microsoft.Office.Interop.Excel;
using System.Collections.Generic;

namespace BeaconDataEvaluator
{
    /// <summary>
    /// サマリファイル作成処理クラス
    /// </summary>
    /// <remarks>
    /// サマリファイルを作成し、該当フォルダに出力処理を行う。
    /// サマリファイル作成に必要な全6ファイル+フォルダパスを入力とする
    ///  ①評価結果
    ///  ②カテゴリ別NG件数カウント結果
    ///  ③評価結果NG項目
    ///  ④オフセット信号同期
    ///  ⑤MAP画像
    ///  ⑥路線別位置情報
    /// </remarks>
    class SummaryFileMaker : IDisposable
    {
        // Excel出力時の規定値
        private const int MaxSheetNum = 20;         // シートの最大枚数(20枚)
        private const int CellColorYellowR = 255;   // 黄色
        private const int CellColorYellowG = 242;   // 黄色
        private const int CellColorYellowB = 204;   // 黄色
        private const int CellColorBlueR = 217;     // 青
        private const int CellColorBlueG = 225;     // 青
        private const int CellColorBlueB = 242;     // 青
        private const int CellColorWhiteR = 255;    // 白
        private const int CellColorWhiteG = 255;    // 白
        private const int CellColorWhiteB = 255;    // 白
        //private const double MaxHeight = 836.16;    // MAP画像の高さ最大値(ポイント)
        //private const double MaxWidth = 1286.84;    // MAP画像の幅最大値(ポイント)

        // Excel操作用オブジェクト
        private Application XlApp = null;
        private Workbooks XlBooks = null;
        private Workbook XlBook = null;
        private Sheets XlSheets = null;
        private Worksheet XlSheet = null;

        // ディスポーザー
        private bool IsDispose = false;

        // DB接続
        private DatabaseAccessor databaseAccessor;  ///< データベース通信クラス

        /// <summary>
        /// リリース対象
        /// </summary>
        private enum EnumReleaseMode
        {
            Sheet,
            Sheets,
            Book,
            Books,
            App
        }

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public SummaryFileMaker()
        {
            // Excelアプリケーション生成
            XlApp = new Application();

            databaseAccessor = new DatabaseAccessor();

            // Excel非表示
            XlApp.Visible = false;
        }

        /// <summary>
        /// デストラクタ
        /// </summary>
        ~SummaryFileMaker()
        {
            // 呼出し側がDispose()してなかったらここでDispose
            if (IsDispose == false)
            {
                Dispose();
            }
        }

        /// <summary>
        /// 解放
        /// </summary>
        public void Dispose()
        {
            if (IsDispose == false)
            {                
                // Excelが使われなくなったときに破棄する
                ReleaseExcelComObject(EnumReleaseMode.App);

                // dispose判定フラグON
                IsDispose = true;

                // Dispose()が明示的に呼ばれたときは、GCからFinalize()呼び出しをさせない
                GC.SuppressFinalize(this);
            }

        }

        /// <summary>
        /// サマリファイル作成処理を実行する(サマリファイル作成のメイン処理)
        /// </summary>
        /// <param name="drivingInfoId">走行情報ID</param>
        /// <param name="summaryData">サマリファイル入力ファイルデータ一式</param>
        /// <returns>成功/失敗</returns>
        public void Start(int drivingInfoId, StSummaryData summaryData)
        {
            string outputFolderPath = "";        // 出力フォルダパス
            string outputPrefectureName = "";    // 出力都道府県名
            string outputSheetName = "";         // 出力シート名
            string evaluationDatetime = "";      // 評価日時
            string outputFileName = "";          // 出力ファイル名
            string outputFilePath = "";          // 出力ファイルパス

            // サマリファイル作成用データの存在有無を確認（1つでも無ければ、エラーとする）
            if (!CheckInputSummaryFile(summaryData))
            {
                throw new Exception("Error：CSVファイルが存在しない。");
            }

            try
            {            
                // 出力ファイルのフルパスを作成
                outputFolderPath = GetOutputFolderPath(summaryData.FilePath);
                outputPrefectureName = GetPrefecture(summaryData.FilePath);
                outputSheetName = GetSheetName(summaryData.CategoryCountResultFileName);
                evaluationDatetime = GetEevaluationDatetime(summaryData.CategoryCountResultFileName).Replace(".csv", "");
                outputFileName = GetOutputFileName(outputFolderPath, outputSheetName, evaluationDatetime, outputPrefectureName);
                outputFilePath = outputFolderPath + "\\" + outputFileName;
                                
                // Excelシートを開き、Excelファイルのフォーマットを整える
                XlBooks = XlApp.Workbooks;
                XlBook = (Workbook)XlBooks.Open(outputFilePath, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                XlSheets = XlBook.Worksheets;
                XlSheet = XlSheets[outputSheetName];
                
                // 都道府県名、路線No.、版、走行日時、評価日付をサマリファイルに書き込む
                WriteHeaderData(summaryData.CategoryCountResultFileName);

                // オフセット信号周期をサマリファイルに書き込む
                WriteOffsetSignalData(summaryData.FilePath, summaryData.OffsetSignalSyncValueFileName);

                // カテゴリ別NG件数カウント結果をサマリファイルに書き込む
                WriteCategoryCountResultData(summaryData.FilePath, summaryData.CategoryCountResultFileName);

                // 評価結果(NG)をサマリファイルに書き込む
                WriteEvaluationResultNgItemData(summaryData.FilePath, summaryData.EvaluationResultNgItemFileName);

                // 路線別位置情報をサマリファイルに書き込む
                WriteLocationInfoData(summaryData.FilePath, summaryData.LocationInfoFileName);

                // MAP(JPEG)をサマリファイルに書き込む
                WriteMapImage(summaryData.FilePath, summaryData.MapImageFileName);

                // 印刷フォーマットを整える
                MakeSummaryFileFormat();
            }
            catch (Exception e)
            {
                // エラー処理
                Console.WriteLine(e);
                
                // 評価履歴テーブルにエラーコードを挿入
                insertEvaluationImplementationHistory(drivingInfoId);

                // 対象ファイルの削除
                if (outputFileName != "")
                {
                    deleteExcel(outputFilePath, outputFileName, outputSheetName);
                }

                // 解放
                Dispose();
            }
            finally
            {
                // Excelの上書き保存
                if (XlBook != null)
                {
                    XlBook.Save();
                    //XlBook.Close();
                }
                if (XlApp != null)
                {
                    //XlApp.Quit();
                }

                //Excelのオブジェクトを開放
                Dispose();
            }
        }

        /// <summary>
        /// エラー時、評価履歴テーブルにエラーコードを挿入する
        /// </summary>
        /// <param name="drivingInfoId">走行情報ID</param>
        private void insertEvaluationImplementationHistory(int drivingInfoId)
        {
            // 評価実施履歴IDを採番(評価実施履歴の主キーを取得)
            int evaluationHistoryId = getEvaluationHistoryId(drivingInfoId);

            // 評価完了時点の時刻を取得して、評価実施日時とする
            var evaluatedTimestamp = DateTime.Now;

            // エラーコード取得
            var evalStatus = DatabaseAccessor.EvaluationStatus.ExportError_SummaryMakeError;

            // エラーを評価履歴テーブルに書き込み
            databaseAccessor.InsertEvaluationImplementationHistory(drivingInfoId, evaluationHistoryId, evaluatedTimestamp, evalStatus);
        }

        /// <summary>
        /// 評価実施履歴IDを採番
        /// </summary>
        /// <returns>評価実施履歴ID</returns>
        /// <remarks>評価実施履歴の主キーを取得する</remarks>
        private int getEvaluationHistoryId(int drivingInfoId)
        {
            // DBから最新の評価実施履歴IDを取得して、インクリメントした値を返却する
            return databaseAccessor.GetLatestEvaluationHistoryId(drivingInfoId) + 1;
        }

        /// <summary>
        /// エラー時に、Excelファイルまたはシートを削除する
        /// </summary>
        /// <param name="filePath">ファイルパス</param>
        /// <param name="sheetName">シート名</param>
        private void deleteExcel(string openFilePath, string fileName, string sheetName)
        {
            try
            {
                // Excelファイルのオープン
                XlBooks = XlApp.Workbooks;
                XlBook = XlBooks.Open(openFilePath, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                XlSheets = XlBook.Worksheets;

                // Excelファイル内のシート数確認
                var excelSheetcount = XlSheets.Count;

                // シート数が1の場合、ファイルを削除
                if(excelSheetcount == 1)
                {
                    Dispose();
                    File.Delete(openFilePath);
                }
                else
                {
                    // それ以外は、対象のシートを削除
                    XlSheet = XlSheets[sheetName];
                    XlApp.DisplayAlerts = false;
                    XlSheet.Delete();
                    XlApp.DisplayAlerts = true;
                    //　ファイルの上書き
                    XlBook.Save();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine($@"Excelファイルまたはシート削除失敗 ({openFilePath}) : {e.Message}");
            }
        }

        /// <summary>
        /// 必要なファイルの有無を確認する
        /// </summary>
        /// <param name="summaryData">ファイルパス及びファイル名</param>
        /// <returns>有無(true：有、false：無)</returns>
        private bool CheckInputSummaryFile(StSummaryData summaryData)
        {
            bool ret = true;

            string CategoryCountResultFilePath = summaryData.FilePath + '\\' + summaryData.CategoryCountResultFileName;
            string EvaluationResultNgItemFilePath = summaryData.FilePath + '\\' + summaryData.EvaluationResultNgItemFileName;
            string OffsetSignalSyncValueFilePath = summaryData.FilePath + '\\' + summaryData.OffsetSignalSyncValueFileName;
            string MapImageFilePath = summaryData.FilePath + '\\' + summaryData.MapImageFileName;
            string LocationInfoFilePath = summaryData.FilePath + '\\' + summaryData.LocationInfoFileName;

            // カテゴリ別NG件数ファイルが存在しない場合、falseを設定
            if (!(System.IO.File.Exists(@CategoryCountResultFilePath)))
            {
                ret = false;
            }
            // 評価結果(NGのみ)ファイルが存在しない場合、falseを設定
            if (!(System.IO.File.Exists(@EvaluationResultNgItemFilePath)))
            {
                ret = false;
            }
            // オフセット信号周期ファイルが存在しない場合、falseを設定
            if (!(System.IO.File.Exists(@OffsetSignalSyncValueFilePath)))
            {
                ret = false;
            }
            // MAP画像ファイルが存在しない場合、falseを設定
            if (!(System.IO.File.Exists(@MapImageFilePath)))
            {
                ret = false;
            }
            // 位置情報ファイルが存在しない場合、falseを設定
            if (!(System.IO.File.Exists(@LocationInfoFilePath)))
            {
                ret = false;
            }

            return ret;
        }

        /// <summary>
        /// サマリファイルの大枠を作成する
        /// </summary>
        private void MakeSummaryFileFormat()
        {
            // ------ タイトル作成 ------
            // 項目名入力
            XlSheet.Cells[1, 1] = "■評価結果";
            // フォント調整
            XlSheet.Cells[1, 1].Font.Size = 18;
            XlSheet.Cells[1, 1].Font.Bold = true;
            XlSheet.Cells[1, 1].Font.Underline = Excel.XlUnderlineStyle.xlUnderlineStyleSingle;


            // ------ ヘッダ部作成 ------
            // ---- 都道府県名～走行日時 ----
            // 項目名入力
            XlSheet.Cells[3, 1] = "都道府県名";
            XlSheet.Cells[4, 1] = "路線No.";
            XlSheet.Cells[5, 1] = "版";
            XlSheet.Cells[6, 1] = "走行日時";
            // セルの色変更、結合
            for (var i = 3; i <= 6; i++)
            {
                // 色変更、結合
                ChangeCellColor(i, 1, i, 2, CellColorYellowR, CellColorYellowG, CellColorYellowB);
                MargeCells(i, 1, i, 2);
            }
            for (var i = 3; i <= 6; i++)
            {
                // 色変更、結合
                ChangeCellColor(i, 3, i, 4, CellColorWhiteR, CellColorWhiteG, CellColorWhiteB);
                MargeCells(i, 3, i, 4);
            }
            // 文字の表示設定
            SetCellsPosition(3, 1, 6, 2, Constants.xlLeft, Constants.xlCenter);
            SetCellsPosition(3, 3, 6, 4, Constants.xlCenter, Constants.xlCenter);
            // 枠線を引く
            DrawFrame(3, 1, 6, 4);
            DrawInside(3, 1, 6, 4, false, 0, 0, false, 0, 0, false, 0, 0, false, 0, 0, true, XlLineStyle.xlContinuous, Excel.XlBorderWeight.xlThin, true, XlLineStyle.xlDouble, Excel.XlBorderWeight.xlThick);
            
            // ---- 評価日時 ----
            // 項目名入力
            XlSheet.Cells[3, 6] = "評価日付";
            // 色の変更
            XlSheet.Cells[3, 6].Interior.Color = ColorTranslator.ToOle(System.Drawing.Color.FromArgb(CellColorYellowR, CellColorYellowG, CellColorYellowB));
            // 色変更、結合
            ChangeCellColor(3, 7, 3, 8, CellColorWhiteR, CellColorWhiteR, CellColorWhiteR);
            MargeCells(3, 7, 3, 8);
            // 文字の表示設定
            SetCellsPosition(3, 6, 3, 6, Constants.xlLeft, Constants.xlCenter);
            SetCellsPosition(3, 7, 3, 8, Constants.xlCenter, Constants.xlCenter);
            // 枠線を引く
            DrawFrame(3, 6, 3, 8);
            DrawInside(3, 6, 3, 8, false, 0, 0, false, 0, 0, false, 0, 0, false, 0, 0, false, 0, 0, true, XlLineStyle.xlDouble, Excel.XlBorderWeight.xlThick);

            // ---- 範囲チェックNG件数、値チェックNG件数、整合性チェックNG件数、BITチェックNG件数 ----
            // 項目名入力
            XlSheet.Cells[3, 20] = "範囲チェックNG件数";
            XlSheet.Cells[4, 20] = "値チェックNG件数";
            XlSheet.Cells[5, 20] = "整合性チェックNG件数";
            XlSheet.Cells[6, 20] = "BITチェックNG件数";
            // セルの色変更、結合
            for (var i = 3; i <= 6; i++)
            {
                // 色変更、結合
                ChangeCellColor(i, 20, i, 21, CellColorYellowR, CellColorYellowG, CellColorYellowB);
                MargeCells(i, 20, i, 21);
            }
            // 色の変更
            ChangeCellColor(3, 22, 6, 22, CellColorWhiteR, CellColorWhiteG, CellColorWhiteB);
            // 文字の表示設定
            SetCellsPosition(3, 20, 6, 21, Constants.xlLeft, Constants.xlCenter);
            SetCellsPosition(3, 22, 6, 22, Constants.xlCenter, Constants.xlCenter);
            // 枠線を引く
            DrawFrame(3, 20, 6, 22);
            DrawInside(3, 20, 6, 22, false, 0, 0, false, 0, 0, false, 0, 0, false, 0, 0, true, XlLineStyle.xlContinuous, Excel.XlBorderWeight.xlThin, true, XlLineStyle.xlDouble, Excel.XlBorderWeight.xlThick);

            //---- オフセット信号周期(分) ----
            // 項目名入力
            XlSheet.Cells[3, 24] = "オフセット信号周期(分)";
            // 色変更、結合
            ChangeCellColor(3, 24, 3, 25, CellColorYellowR, CellColorYellowG, CellColorYellowB);
            MargeCells(3, 24, 3, 25);
            // 文字の表示設定
            SetCellsPosition(3, 24, 3, 25, Constants.xlLeft, Constants.xlCenter);
            SetCellsPosition(3, 26, 3, 26, Constants.xlCenter, Constants.xlCenter);
            // 枠線を引く
            DrawFrame(3, 24, 3, 26);
            DrawInside(3, 24, 3, 26, false, 0, 0, false, 0, 0, false, 0, 0, false, 0, 0, false, 0, 0, true, XlLineStyle.xlDouble, Excel.XlBorderWeight.xlThick);


            // ------ 地図 ------
            // 項目名入力
            XlSheet.Cells[8, 1] = "地図";
            // 色変更、結合
            ChangeCellColor(8, 1, 8, 18, CellColorYellowR, CellColorYellowG, CellColorYellowB);
            MargeCells(8, 1, 8, 18);
            ChangeCellColor(9, 1, 54, 18, CellColorWhiteR, CellColorWhiteG, CellColorWhiteB);
            // 文字の表示設定
            SetCellsPosition(8, 1, 8, 18, Constants.xlCenter, Constants.xlCenter);
            // 枠線を引く
            DrawFrame(8, 1, 54, 18);
            DrawInside(8, 1, 9, 18,  false, 0, 0, false, 0, 0, false, 0, 0, false, 0, 0, true, XlLineStyle.xlDouble, Excel.XlBorderWeight.xlThick, false, 0, 0);

            // ------ 路線別位置情報 ------
            // 色変更、結合
            ChangeCellColor(56, 1, 59, 9, CellColorBlueR, CellColorBlueG, CellColorBlueB);
            MargeCells(56, 1, 56, 9);
            ChangeCellColor(56, 10, 59, 18, CellColorYellowR, CellColorYellowG, CellColorYellowB);
            MargeCells(56, 10, 56, 18);
            for (var i = 1; i <= 9; i++)
            {
                MargeCells(57, i, 59, i);
            }
            MargeCells(57, 10, 57, 12);
            MargeCells(57, 14, 57, 16);
            MargeCells(57, 17, 57, 18);
            MargeCells(57, 13, 59, 13);
            for(var i = 10; i <= 18; i++)
            {
                if(i != 13)
                {
                    MargeCells(58, i, 59, i);
                }
            }
            // 項目名入力
            XlSheet.Cells[56, 1] = "ビーコン・交差点情報";
            XlSheet.Cells[57, 1] = "交差点" + Environment.NewLine + "順序";
            XlSheet.Cells[57, 2] = "管制" + Environment.NewLine + "管理番号";
            XlSheet.Cells[57, 3] = "交差点名称";
            XlSheet.Cells[57, 4] = "2次メッシュ" + Environment.NewLine + "座標" + Environment.NewLine + "(10進)";
            XlSheet.Cells[57, 5] = "正規化" + Environment.NewLine + "座標X" + Environment.NewLine + "(10進)";
            XlSheet.Cells[57, 6] = "正規化" + Environment.NewLine + "座標Y" + Environment.NewLine + "(10進)";
            XlSheet.Cells[57, 7] = "信号情報" + Environment.NewLine + "提供有無";
            XlSheet.Cells[57, 8] = "緯度" + Environment.NewLine + "(度)";
            XlSheet.Cells[57, 9] = "経度" + Environment.NewLine + "(度)";
            XlSheet.Cells[56, 10] = "位置精度確認";
            XlSheet.Cells[57, 10] = "真値";
            XlSheet.Cells[57, 13] = "データ有無";
            XlSheet.Cells[57, 14] = "走行結果";
            XlSheet.Cells[57, 17] = "誤差";
            XlSheet.Cells[58, 10] = "緯度" + Environment.NewLine + "(度)";
            XlSheet.Cells[58, 11] = "経度" + Environment.NewLine + "(度)";
            XlSheet.Cells[58, 12] = "道程距離" + Environment.NewLine + "(m)";
            XlSheet.Cells[58, 14] = "緯度" + Environment.NewLine + "(度)";
            XlSheet.Cells[58, 15] = "経度" + Environment.NewLine + "(度）";
            XlSheet.Cells[58, 16] = "道程距離" + Environment.NewLine + "(m)";
            XlSheet.Cells[58, 17] = "座標" + Environment.NewLine + "(m)";
            XlSheet.Cells[58, 18] = "道程距離" + Environment.NewLine + "(m)";
            // 文字の表示設定
            SetCellsPosition(56, 1, 78, 18, Constants.xlCenter, Constants.xlCenter);
            // 枠線を引く
            DrawFrame(56, 1, 78, 18);
            DrawInside(56, 1, 78, 18, false, 0, 0, false, 0, 0, false, 0, 0, false, 0, 0, true, XlLineStyle.xlContinuous, Excel.XlBorderWeight.xlThin, true, XlLineStyle.xlContinuous, Excel.XlBorderWeight.xlThin);
            DrawInside(57, 1, 78, 9,  false, 0, 0, false, 0, 0, false, 0, 0, false, 0, 0, true, XlLineStyle.xlContinuous, Excel.XlBorderWeight.xlHairline, true, XlLineStyle.xlContinuous, Excel.XlBorderWeight.xlHairline);
            DrawInside(57, 10, 78, 18,  false, 0, 0, false, 0, 0, false, 0, 0, false, 0, 0, true, XlLineStyle.xlContinuous, Excel.XlBorderWeight.xlHairline, true, XlLineStyle.xlContinuous, Excel.XlBorderWeight.xlHairline);
            DrawInside(56, 1, 59, 18, true, XlLineStyle.xlDouble, Excel.XlBorderWeight.xlThick, false, 0, 0, false, 0, 0, false, 0, 0, false, 0, 0, false, 0, 0);


            // ------ 結果 ------
            XlSheet.Cells[8, 20] = "No.";
            XlSheet.Cells[8, 21] = "項目";
            XlSheet.Cells[8, 22] = "値";
            XlSheet.Cells[8, 23] = "分類";
            XlSheet.Cells[8, 24] = "結果";
            XlSheet.Cells[9, 24] = "光ビーコン規格";
            XlSheet.Cells[9, 25] = "UTMS協会";
            XlSheet.Cells[9, 26] = "その他";
            XlSheet.Cells[78, 20] = "備考";
            // 色変更、結合
            ChangeCellColor(8, 20, 9, 26, CellColorYellowR, CellColorYellowG, CellColorYellowB);
            ChangeCellColor(10, 20, 78, 26, CellColorWhiteR, CellColorWhiteG, CellColorWhiteB);
            ChangeCellColor(78, 20, 78, 21, CellColorYellowR, CellColorYellowG, CellColorYellowB);
            for (var i = 20; i <= 23; i++)
            {
                MargeCells(8, i, 9, i);
            }
            // 結合
            MargeCells(8, 24, 8, 26);
            MargeCells(78, 20, 78, 21);
            MargeCells(78, 22, 78, 26);
            // 文字の表示設定
            SetCellsPosition(8, 20, 9, 26, Constants.xlCenter, Constants.xlCenter);
            SetCellsPosition(10, 20, 77, 20, Constants.xlCenter, Constants.xlTop);
            SetCellsPosition(10, 21, 77, 21, Constants.xlLeft, Constants.xlTop);
            SetCellsPosition(10, 22, 77, 26, Constants.xlCenter, Constants.xlTop);
            SetCellsPosition(78, 20, 78, 21, Constants.xlCenter, Constants.xlCenter);
            SetCellsPosition(78, 22, 78, 26, Constants.xlLeft, Constants.xlCenter);
            // 枠線を引く
            DrawFrame(8, 20, 78, 26);
            DrawInside(8, 20, 78, 26, false, 0, 0, false, 0, 0, false, 0, 0, false, 0, 0, true, XlLineStyle.xlContinuous, Excel.XlBorderWeight.xlHairline, true, XlLineStyle.xlContinuous, Excel.XlBorderWeight.xlHairline);
            DrawInside(8, 20, 9, 26, true, XlLineStyle.xlDouble, Excel.XlBorderWeight.xlThick, false, 0, 0, false, 0, 0, false, 0, 0, false, 0, 0, false, 0, 0);
            DrawInside(78, 20, 78, 26, false, 0, 0, true, XlLineStyle.xlContinuous, Excel.XlBorderWeight.xlThin, false, 0, 0, false, 0, 0, false, 0, 0, true, XlLineStyle.xlContinuous, Excel.XlBorderWeight.xlThin);

            // -------- 行列の幅を指定 --------
            // 列
            XlSheet.Cells[1, 1].ColumnWidth = 6.88;
            XlSheet.Cells[1, 2].ColumnWidth = 10.50;
            XlSheet.Cells[1, 3].ColumnWidth = 20.75;
            XlSheet.Cells[1, 4].ColumnWidth = 11.75;
            XlSheet.Cells[1, 5].ColumnWidth = 11.75;
            for (var i = 6; i <= 18; i++)
            {
                XlSheet.Cells[1, i].ColumnWidth = 12.00;
            }
            XlSheet.Cells[1, 19].ColumnWidth = 0.69;
            XlSheet.Cells[1, 20].ColumnWidth = 4.25;
            XlSheet.Cells[1, 21].ColumnWidth = 26.83;
            XlSheet.Cells[1, 22].ColumnWidth = 10.75;
            XlSheet.Cells[1, 23].ColumnWidth = 15.50;
            for (var i = 24; i <= 26; i++)
            {
                XlSheet.Cells[1, i].ColumnWidth = 14.38;
            }
            // 行
            XlSheet.Cells[2, 1].RowHeight = 7.5;
            XlSheet.Cells[7, 1].RowHeight = 7.5;
            
            // 表示の尺度を70%に変更
            XlSheet.Application.ActiveWindow.Zoom = 70;

            // 位置情報の小数表示設定
            ChangeCellDisplayFormat(60, 8, 78, 11, "0.000000");
            ChangeCellDisplayFormat(60, 14, 78, 15, "0.000000");
            ChangeCellDisplayFormat(60, 17, 78, 17, "0.0");
            
            // -------- 印刷フォーマットの設定 --------
            XlSheet.PageSetup.Orientation = XlPageOrientation.xlLandscape;    // ページを横向きに設定
            XlSheet.PageSetup.PrintArea = @"$A$1:$Z$78";                      // 印刷範囲を設定
            XlSheet.PageSetup.FitToPagesWide = 1;                             // 横のページ数を示す値を指定
            XlSheet.PageSetup.FitToPagesTall = 1;                             // 縦のページ数を示す値を指定
            XlSheet.PageSetup.Zoom = false;                                   // 縮小率をFitToPagesWide及びFitToPagesTallに依存するように設定
            XlSheet.PageSetup.PaperSize = XlPaperSize.xlPaperA3;              // 用紙をA3に設定
            XlSheet.PageSetup.PrintQuality = 600;                             // 印刷品質を設定
        }

        /// <summary>
        /// セルの色を変更する
        /// </summary>
        /// <param name="beginRowNum">開始(左上)行番号</param>
        /// <param name="beginColNum">開始(左上)列番号</param>
        /// <param name="endRowNum">終了(右下)行番号</param>
        /// <param name="endColNum">終了(右下)列番号</param>
        /// <param name="colorR">RGBの赤</param>
        /// <param name="colorG">RGBの緑</param>
        /// <param name="colorB">RGBの青</param>
        private void ChangeCellColor(int beginRowNum, int beginColNum, int endRowNum, int endColNum, int colorR, int colorG, int colorB)
        {
            var beginRange = XlSheet.Cells[beginRowNum, beginColNum];
            var endRange = XlSheet.Cells[endRowNum, endColNum];
            var targetRange = XlSheet.Range[beginRange, endRange];
            targetRange.Interior.Color = ColorTranslator.ToOle(Color.FromArgb(colorR, colorG, colorB));
        }

        /// <summary>
        /// セルを結合する
        /// </summary>
        /// <param name="beginRowNum">開始(左上)行番号</param>
        /// <param name="beginColNum">開始(左上)列番号</param>
        /// <param name="endRowNum">終了(右下)行番号</param>
        /// <param name="endColNum">終了(右下)列番号</param>
        private void MargeCells(int beginRowNum, int beginColNum, int endRowNum, int endColNum)
        {
            var beginRange = XlSheet.Cells[beginRowNum, beginColNum];
            var endRange = XlSheet.Cells[endRowNum, endColNum];
            var targetRange = XlSheet.Range[beginRange, endRange];
            targetRange.Merge();
        }

        /// <summary>
        /// 外枠線(太)を引く
        /// </summary>
        /// <param name="beginRowNum">開始(左上)行番号</param>
        /// <param name="beginColNum">開始(左上)列番号</param>
        /// <param name="endRowNum">終了(右下)行番号</param>
        /// <param name="endColNum">終了(右下)列番号</param>
        private void DrawFrame(int beginRowNum, int beginColNum, int endRowNum, int endColNum)
        {
            var beginRange = XlSheet.Cells[beginRowNum, beginColNum];
            var endRange = XlSheet.Cells[endRowNum, endColNum];
            var targetRange = XlSheet.Range[beginRange, endRange];
            targetRange.BorderAround(XlLineStyle.xlContinuous, Excel.XlBorderWeight.xlMedium);
        }

        /// <summary>
        /// 内側の線を引く
        /// </summary>
        /// <param name="beginRowNum">開始(左上)行番号</param>
        /// <param name="beginColNum">開始(左上)列番号</param>
        /// <param name="endRowNum">終了(右下)行番号</param>
        /// <param name="endColNum">終了(右下)列番号</param>
        /// <param name="edgeBottomFlg">下線の使用/未使用(True：使用、False：未使用)</param>
        /// <param name="edgeBottomType">下線の種類</param>
        /// <param name="edgeBottomWeight">下線の太さ</param>
        /// <param name="edgeTopFlg">上線の使用/未使用(True：使用、False：未使用)</param>
        /// <param name="edgeTopType">上線の種類</param>
        /// <param name="edgeTopWeight">上線の太さ</param>
        /// <param name="edgeLeftFlg">左線の使用/未使用(True：使用、False：未使用)</param>
        /// <param name="edgeLeftType">左線の種類</param>
        /// <param name="edgeLeftWeight">左線の太さ</param>
        /// <param name="edgeRightFlg">右線の使用/未使用(True：使用、False：未使用)</param>
        /// <param name="edgeRightType">右線の種類</param>
        /// <param name="edgeRightWeight">右線の太さ</param>
        /// <param name="insideHorizontalRangeFlg">横線の使用/未使用(True：使用、False：未使用)</param>
        /// <param name="insideHorizontalRangeType">横線の種類</param>
        /// <param name="insideHorizontalRangeWeight">横線の太さ</param>
        /// <param name="insideVerticalFlg">縦線の使用/未使用(True：使用、False：未使用)</param>
        /// <param name="insideVerticalType">縦線の種類</param>
        /// <param name="insideVerticalWeight">縦線の太さ</param>
        private void DrawInside(int beginRowNum,
                                int beginColNum,
                                int endRowNum,
                                int endColNum,
                                bool edgeBottomFlg,
                                XlLineStyle edgeBottomType,
                                Excel.XlBorderWeight edgeBottomWeight,
                                bool edgeTopFlg,
                                XlLineStyle edgeTopType,
                                Excel.XlBorderWeight edgeTopWeight,
                                bool edgeLeftFlg,
                                XlLineStyle edgeLeftType,
                                Excel.XlBorderWeight edgeLeftWeight,
                                bool edgeRightFlg,
                                XlLineStyle edgeRightType,
                                Excel.XlBorderWeight edgeRightWeight,
                                bool insideHorizontalRangeFlg,
                                XlLineStyle insideHorizontalRangeType,
                                Excel.XlBorderWeight insideHorizontalRangeWeight,
                                bool insideVerticalFlg,
                                XlLineStyle insideVerticalType,
                                Excel.XlBorderWeight insideVerticalWeight)
        {
            var beginRange = XlSheet.Cells[beginRowNum, beginColNum];
            var endRange = XlSheet.Cells[endRowNum, endColNum];
            var targetRange = XlSheet.Range[beginRange, endRange];

            // 下線
            if (edgeBottomFlg == true)
            {
                targetRange.Borders.Item[XlBordersIndex.xlEdgeBottom].LineStyle = edgeBottomType;
                targetRange.Borders.Item[XlBordersIndex.xlEdgeBottom].Weight = edgeBottomWeight;
            }
            // 上線
            if (edgeTopFlg == true)
            {
                targetRange.Borders.Item[XlBordersIndex.xlEdgeTop].LineStyle = edgeTopType;
                targetRange.Borders.Item[XlBordersIndex.xlEdgeTop].Weight = edgeTopWeight;
            }
            // 左線
            if (edgeLeftFlg == true)
            {
                targetRange.Borders.Item[XlBordersIndex.xlEdgeLeft].LineStyle = edgeLeftType;
                targetRange.Borders.Item[XlBordersIndex.xlEdgeLeft].Weight = edgeLeftWeight;
            }
            // 右線
            if (edgeRightFlg == true)
            {
                targetRange.Borders.Item[XlBordersIndex.xlEdgeRight].LineStyle = edgeRightType;
                targetRange.Borders.Item[XlBordersIndex.xlEdgeRight].Weight = edgeRightWeight;
            }
            // 横線
            if (insideHorizontalRangeFlg == true)
            {
                targetRange.Borders.Item[XlBordersIndex.xlInsideHorizontal].LineStyle = insideHorizontalRangeType;
                targetRange.Borders.Item[XlBordersIndex.xlInsideHorizontal].Weight = insideHorizontalRangeWeight;
            }
            // 縦線
            if (insideVerticalFlg == true)
            {
                targetRange.Borders.Item[XlBordersIndex.xlInsideVertical].LineStyle = insideVerticalType;
                targetRange.Borders.Item[XlBordersIndex.xlInsideVertical].Weight = insideVerticalWeight;
            }
        }

        /// <summary>
        /// 指定範囲内の文字列の位置を設定する
        /// </summary>
        /// <param name="beginRowNum">開始行番号</param>
        /// <param name="beginColNum">開始列番号</param>
        /// <param name="endRowNum">終了行番号</param>
        /// <param name="endColNum">終了列番号</param>
        /// <param name="horizontal">水平設定</param>
        /// <param name="vertical">垂直設定</param>
        private void SetCellsPosition(int beginRowNum, int beginColNum, int endRowNum, int endColNum, Constants horizontal, Constants vertical)
        {
            var beginRange = XlSheet.Cells[beginRowNum, beginColNum];
            var endRange = XlSheet.Cells[endRowNum, endColNum];
            var targetRange = XlSheet.Range[beginRange, endRange];
            targetRange.HorizontalAlignment = horizontal;
            targetRange.VerticalAlignment = vertical;
        }

        /// <summary>
        /// 指定範囲内の数値の表示を設定する
        /// </summary>
        /// <param name="beginRowNum">開始行番号</param>
        /// <param name="beginColNum">開始列番号</param>
        /// <param name="endRowNum">終了行番号</param>
        /// <param name="endColNum">終了列番号</param>
        /// <param name="format">形式</param>
        private void ChangeCellDisplayFormat(int beginRowNum, int beginColNum, int endRowNum, int endColNum, string format)
        {
            var beginRange = XlSheet.Cells[beginRowNum, beginColNum];
            var endRange = XlSheet.Cells[endRowNum, endColNum];
            XlSheet.Range[beginRange, endRange].NumberFormat = format;
        }

        /// <summary>
        /// 結果ファイル名から、都道府県名、路線No.、版、走行日時、評価日付を取得し、サマリファイルに書き込む
        /// </summary>
        /// <param name="resultFileName">結果ファイル名</param>
        private void WriteHeaderData(string resultFileName)
        {
            // ファイル名をカンマでスプリットし、都道府県名、路線No.、版、走行日時、評価日付を取得
            string[] headerData = resultFileName.Split('_');
            string prefectureName = headerData[2];
            string routeNum = headerData[3];
            string version = headerData[4];
            string drivingDatetime = headerData[0];
            string evaluationDate = headerData[5];

            // シート名の取得、選択
            string sheetName = GetSheetName(resultFileName);
            XlSheet = XlBook.Sheets[sheetName];

            // Excelシートに書き込む
            XlSheet.Cells[3, 3] = prefectureName;
            XlSheet.Cells[4, 3] = routeNum;
            XlSheet.Cells[5, 3] = version;
            XlSheet.Cells[6, 3] = drivingDatetime.Substring(0, 4) + "/" + 
                                    drivingDatetime.Substring(4, 2) + "/" + 
                                    drivingDatetime.Substring(6, 2) + " " +
                                    drivingDatetime.Substring(9, 2) + ":" +
                                    drivingDatetime.Substring(11, 2) + ":" +
                                    drivingDatetime.Substring(13, 2) + "." +
                                    drivingDatetime.Substring(15, 3);
            XlSheet.Cells[6, 3].NumberFormatLocal = "yyyy/mm/dd hh:mm:ss";
            XlSheet.Cells[3, 8] = evaluationDate.Substring(0, 4) + "/" +
                                    evaluationDate.Substring(4, 2) + "/" +
                                    evaluationDate.Substring(6, 2) + " " +
                                    evaluationDate.Substring(9, 2) + ":" +
                                    evaluationDate.Substring(11, 2) + ":" +
                                    evaluationDate.Substring(13, 2);
            XlSheet.Cells[3, 8].NumberFormatLocal = "yyyy/mm/dd hh:mm:ss";
        }

        /// <summary>
        /// オフセット信号周期をサマリファイルに書き込む
        /// </summary>
        /// <param name="summaryInputFilePath">サマリファイル入力パス</param>
        /// <param name="OffsetSignalSyncValueFileName">オフセット信号同期ファイル名</param>
        private void WriteOffsetSignalData(string summaryInputFilePath, string OffsetSignalSyncValueFileName)
        {
            // オフセット信号周期のファイルパスを作成し、ファイルを開く
            var filePath = @summaryInputFilePath + "\\" + OffsetSignalSyncValueFileName;
            var sr = new StreamReader(filePath, Encoding.GetEncoding("Shift_JIS"));

            // シート名の取得、選択
            string sheetName = GetSheetName(OffsetSignalSyncValueFileName);
            XlSheet = XlBook.Sheets[sheetName];

            var lineCnt = 0;
            while (!sr.EndOfStream)
            {
                // ファイルから1行読み込む
                var line = sr.ReadLine();

                // ヘッダ行以外であれば、文字列をサマリファイルに出力
                if (lineCnt != 0)
                {
                    // オフセット信号周期の書き込み
                    XlSheet.Cells[3, 26] = line;
                }
                lineCnt++;
            }
        }

        /// <summary>
        /// カテゴリ別NG件数カウント結果をサマリファイルに書き込む
        /// </summary>
        /// <param name="summaryInputFilePath">サマリファイル入力パス</param>
        /// <param name="categoryCountResultFileName">カテゴリ別NG件数カウント結果</param>
        private void WriteCategoryCountResultData(string summaryInputFilePath, string categoryCountResultFileName)
        {
            // カテゴリ別NG件数カウント結果のファイルパスを作成し、ファイルを開く
            var filePath = @summaryInputFilePath + "\\" + categoryCountResultFileName;
            var sr = new StreamReader(filePath, Encoding.GetEncoding("Shift_JIS"));

            // シート名の取得、選択
            string sheetName = GetSheetName(categoryCountResultFileName);
            XlSheet = XlBook.Sheets[sheetName];

            var lineCnt = 0;
            while (!sr.EndOfStream)
            {
                // ファイルから1行読み込む
                var line = sr.ReadLine();
                var values = line.Split(',');

                switch (lineCnt)
                {
                    case 1:
                        XlSheet.Cells[3, 22] = values[1];
                        break;
                    case 2:
                        XlSheet.Cells[4, 22] = values[1];
                        break;
                    case 3:
                        XlSheet.Cells[5, 22] = values[1];
                        break;
                    case 4:
                        XlSheet.Cells[6, 22] = values[1];
                        break;
                    default:
                        break;
                }
                lineCnt++;
            }
        }

        /// <summary>
        /// 評価結果(NG)をサマリファイルに書き込む
        /// </summary>
        /// <param name="summaryInputFilePath">サマリファイル入力パス</param>
        /// <param name="evaluationResultNgItemFileName">評価結果(NG)ファイル名</param>
        private void WriteEvaluationResultNgItemData(string summaryInputFilePath, string evaluationResultNgItemFileName)
        {
            // 評価結果(NG)のファイルパスを作成し、ファイルを開く
            var filePath = @summaryInputFilePath + "\\" + evaluationResultNgItemFileName;
            var sr = new StreamReader(filePath, Encoding.GetEncoding("Shift_JIS"));

            // シート名の取得、選択
            string sheetName = GetSheetName(evaluationResultNgItemFileName);
            XlSheet = XlBook.Sheets[sheetName];

            var lineCnt = 0;
            var targetRowNum = 10;      // 書き込み対象の行番号
            //var maxWriteFlg = false;    // 最大書き込み可能行数到達フラグ
            while (!sr.EndOfStream)
            {
                // ファイルから1行読み込む
                var line = sr.ReadLine();

                // ヘッダ行以外であれば、文字列をサマリファイルに出力
                if (lineCnt != 0)
                {
                    var values = line.Split(',');

                    // 最大書き込み行数可能行数に達しているが、まだNGがある場合、備考欄にその旨を書き込み終了
                    double stRowNum = (LenB(values[1]) / 28d);
                    double usingCellsNum = Math.Ceiling(stRowNum);
                    if ((targetRowNum + (int)usingCellsNum - 1) > 77)
                    {
                        XlSheet.Cells[78, 22] = "詳細は「評価結果NG項目」を参照。";
                        break;
                    }

                    // 路線別位置情報の書き込み
                    for (var i = 0; i < values.Length; i++)
                    {
                        //m_xlSheet.Cells[(lineCnt + targetRowNum - 1), (i + 20)] = values[i];
                        XlSheet.Cells[targetRowNum, (i + 20)] = values[i];
                    }
                        
                    // 項目が14文字(28byte)以上の場合、数に応じてセルを結合
                    if (LenB(values[1]) >= 28)
                    {
                        // セルの結合、折り返して表示
                        for (var i = 20; i <= 26; i++)
                        {
                            MargeCells(targetRowNum, i, (targetRowNum + (int)usingCellsNum - 1), i);
                            // 折り返して表示
                            XlSheet.Cells[targetRowNum, i].WrapText = true;
                        }
                        targetRowNum = targetRowNum + (int)usingCellsNum;
                    }
                }
                lineCnt++;
            }
        }

        /// <summary>
        /// 引数で受け取った文字列のバイト数を返す
        /// </summary>
        /// <param name="stTarget">対象文字列</param>
        /// <returns>バイト数</returns>
        private int LenB(string stTarget)
        {
            return System.Text.Encoding.GetEncoding("Shift_JIS").GetByteCount(stTarget);
        }

        /// <summary>
        /// 地図の画像をサマリファイルに書き込む
        /// </summary>
        /// <param name="summaryInputFilePath">サマリファイル入力パス</param>
        /// <param name="mapImageFileName">地図画像ファイル名</param>
        private void WriteMapImage(string summaryInputFilePath, string mapImageFileName)
        {
            // Excelのバージョン取得
            string xlVersion = XlApp.Version;

            // 最大値の決定
            double maxHeight = 0;   // MAP画像の高さ最大値(ポイント)
            double maxWidth = 0;    // MAP画像の幅最大値(ポイント)
            if(xlVersion == "14.0")
            {
                maxHeight = 600.00;
                maxWidth = 1274.73;
            }
            else
            {
                maxHeight = 836.16;
                maxWidth = 1286.84;
            }

            // 地図画像のファイルパスを作成
            var filePath = @summaryInputFilePath + "\\" + mapImageFileName;

            // シート名の取得、選択
            string sheetName = GetSheetName(mapImageFileName);
            XlSheet = XlBook.Sheets[sheetName];

            // シートに貼り付け
            Range range = XlSheet.Cells[10, 2];
            range.Select();
                
            Pictures pictures = (Pictures)XlSheet.Pictures(Type.Missing);
            Picture picture = pictures.Insert(filePath, Type.Missing);
            
            // 画像の高さと幅を取得
            double pictureHeight = picture.Height;
            double pictureWidth = picture.Width;
            // 一旦削除
            picture.Delete();
                
            // MAP画像サイズの決定
            double height = 0;
            double width = 0;
            if ((pictureWidth * maxHeight / pictureHeight) > maxWidth)
            {
                width = maxWidth;
                height = pictureHeight * maxWidth / pictureWidth;
            }
            else
            {
                width = pictureWidth * maxHeight / pictureHeight;
                height = maxHeight;
            }

            // MAP画像をサイズ調整して貼り付け
            float left = 0;
            float top = 0;
            if (xlVersion == "14.0")
            {
                left = 50;// range.Cells.Row;
                top = 120;//range.Cells.Column;
            }
            else
            {
                left = 50;// range.Cells.Row;
                top = 165;//range.Cells.Column;
            }
            XlSheet.Shapes.AddPicture(filePath, MsoTriState.msoFalse, MsoTriState.msoTrue, left, top, (float)width, (float)height);

            // カーソルを左上に戻す
            range = XlSheet.Cells[1, 1];
            range.Select();
        }

        /// <summary>
        /// 路線別位置情報をサマリファイルに書き込む
        /// </summary>
        /// <param name="summaryInputFilePath">サマリファイル入力パス</param>
        /// <param name="LocationInfoFileName">路線別位置情報ファイル名</param>
        private void WriteLocationInfoData(string summaryInputFilePath, string LocationInfoFileName)
        {
            // 路線別位置情報のファイルパスを作成し、ファイルを開く
            var filePath = @summaryInputFilePath + "\\" + LocationInfoFileName;
            var sr = new StreamReader(filePath, Encoding.GetEncoding("Shift_JIS"));

            // シート名の取得、選択
            string sheetName = GetSheetName(LocationInfoFileName);
            XlSheet = XlBook.Sheets[sheetName];

            var lineCnt = 0;
            while (!sr.EndOfStream)
            {
                // ファイルから1行読み込む
                var line = sr.ReadLine();

                // ヘッダ行以外であれば、文字列をサマリファイルに出力
                if (lineCnt != 0)
                {
                    var values = line.Split(',');

                    // 路線別位置情報の書き込み
                    for (var i = 0; i < values.Length; i++)
                    {
                        XlSheet.Cells[(lineCnt + 59), (i + 1)] = values[i];
                    }
                }
                lineCnt++;
            }

            // 交差点数が19未満の場合
            if(lineCnt < 19)
            {
                for (var i = lineCnt; i <= 19; i++)
                {
                    for(var j = 1; j <= 18; j++)
                    {
                        XlSheet.Cells[(i + 59), (j)] = "'--";
                    }
                }
            }
        }

        /// <summary>
        /// ファイル名からシート名を作成し、値を返す
        /// </summary>
        /// <param name="fileName">ファイル名</param>
        /// <returns>シート名</returns>
        private string GetSheetName(string fileName)
        {
            string retSheetName = "";

            // ファイル名をカンマでスプリットし、路線No.、走行日時を取得
            string[] headerData = fileName.Split('_');
            string routeNum = headerData[3];
            string drivingDatetime = headerData[0];

            // シート名の取得、選択
            retSheetName = routeNum + "_" + drivingDatetime;

            return retSheetName;
        }

        /// <summary>
        /// ファイル名から評価日時を取得
        /// </summary>
        /// <param name="fileName">ファイル名</param>
        /// <returns></returns>
        private string GetEevaluationDatetime(string fileName)
        {
            // ファイル名をカンマでスプリットし、評価日時を取得
            string[] headerData = fileName.Split('_');

            return headerData[5];
        }

        /// <summary>
        /// ファイルパスから対象の「都道府県No._都道府県名」を取得する
        /// </summary>
        /// <param name="summaryInputFilePath">サマリファイル入力パス</param>
        /// <returns>都道府県No._都道府県名</returns>
        private string GetPrefecture(string summaryInputFilePath)
        {
            string retFolderName = "";

            // フォルダパスを\でスプリットし、各フォルダ名を配列に格納する。
            string[] arrayFolderName = summaryInputFilePath.Split('\\');
            // 最後から2番目のフォルダ名を取得し、戻り値用の変数に格納する。
            retFolderName = arrayFolderName[arrayFolderName.Length - 2].Replace("_", "-");

            return retFolderName;
        }

        /// <summary>
        /// サマリファイル入力パスから、出力先のパスを作成する
        /// </summary>
        /// <param name="summaryInputFilePath">サマリファイル入力パス</param>
        /// <returns>都道府県No._都道府県名</returns>
        private string GetOutputFolderPath(string summaryInputFilePath)
        {
            string retOutputFilePath = "";
            string[] folderNames = summaryInputFilePath.Split('\\');

            for(var i = 0; i < (folderNames.Length - 3); i++)
            {
                if(i == 0)
                {
                    retOutputFilePath = folderNames[i];
                }
                else
                {
                    retOutputFilePath = retOutputFilePath + "\\" + folderNames[i];
                }
            }

            retOutputFilePath = retOutputFilePath + "\\00_サマリ";

            return retOutputFilePath;
        }

        /// <summary>
        /// 出力ファイル名を取得する
        /// </summary>
        /// <param name="outputFolderPath">出力先のフォルダパス</param>
        /// <param name="outputSheetName">シート名</param>
        /// <param name="evaluationDatetime">評価日時</param>
        /// <param name="prefectureName">都道府県名</param>
        /// <returns>出力ファイル名</returns>
        private string GetOutputFileName(string outputFolderPath, string outputSheetName, string evaluationDatetime, string prefectureName)
        {
            string retFileName = "";
            string baseFileName = evaluationDatetime + "_評価結果サマリ_" + prefectureName + "-";

            // 出力先のフォルダパス内に存在する全ファイル名を取得する。
            string[] outputFolderFiles = Directory.GetFiles(outputFolderPath);
            List<string> targetFilePaths = new List<string>();
            if (outputFolderFiles.Length != 0)
            { 
                for (var i = 0; i < outputFolderFiles.Length; i++)
                {
                    // ファイル名内に該当の都道府県名が含まれている場合
                    if (outputFolderFiles[i].IndexOf(prefectureName) > 0)
                    {
                        targetFilePaths.Add(outputFolderFiles[i]);
                    }
                }
            }
           
            if (targetFilePaths.Count == 0) // ファイルが存在していない場合
            {
                retFileName = baseFileName + (targetFilePaths.Count + 1).ToString("000") + ".xlsx";
                // 新規ファイルの作成
                MakeNewExcelFile(outputFolderPath, retFileName, outputSheetName);
                initExcelFile(outputFolderPath, retFileName);
            }
            else // ファイルが存在している場合
            {   
                string openFilePath = targetFilePaths[targetFilePaths.Count - 1];
                string tmpFileName = Path.GetFileNameWithoutExtension(openFilePath);
                int cutPosition = tmpFileName.LastIndexOf('-');
                baseFileName = tmpFileName.Substring(0, cutPosition + 1);
                XlBooks = XlApp.Workbooks;

                try
                {
                    XlBook = XlBooks.Open(openFilePath, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                    XlSheets = XlBook.Worksheets;
                    // シート数を確認し、20以上の場合新規ファイル名を作成
                    if (XlSheets.Count >= MaxSheetNum)
                    {
                        retFileName = baseFileName + (targetFilePaths.Count + 1).ToString("000") + ".xlsx";
                        // 新規ファイルの作成
                        MakeNewExcelFile(outputFolderPath, retFileName, outputSheetName);
                        initExcelFile(outputFolderPath, retFileName);
                    }
                    else
                    {
                        retFileName = baseFileName + targetFilePaths.Count.ToString("000") + ".xlsx";
                        // 新規シートの作成
                        MakeNewWorkSheet(outputFolderPath, retFileName, outputSheetName);
                    }
                    // 一旦Excelファイルを終了
                    XlBook.Close();
                }
                catch (Exception e)
                {
                    Console.WriteLine($@"ファイルオープン失敗 ({openFilePath}) : {e.Message}");
                }
            }
            
            return retFileName;
        }

        /// <summary>
        /// Excelファイル新規作成時に、シートを1つにする
        /// </summary>
        /// <param name="folderPath">フォルダパス</param>
        /// <param name="fileName">ファイル名</param>
        private void initExcelFile(string folderPath, string fileName)
        {
            string openFilePath = folderPath + @"\" + fileName;

            try
            {
                // Excelファイルのオープン
                XlBooks = XlApp.Workbooks;
                XlBook = XlBooks.Open(openFilePath, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                XlSheets = XlBook.Worksheets;

                // Excelファイル内のシート数確認
                var excelSheetcount = XlSheets.Count;

                // シート数が1より多い場合、シート1以外を削除
                if (excelSheetcount > 1)
                {
                    XlApp.DisplayAlerts = false;
                    for (var i = 2; i <= excelSheetcount; i++)
                    {
                        string deleteSheetName = "Sheet" + i.ToString();
                        XlSheet = XlSheets[deleteSheetName];
                        XlSheet.Delete();
                    }
                    XlApp.DisplayAlerts = true;
                    //　ファイルの上書き
                    XlBook.Save();
                }
            }
            catch(Exception e)
            {
                Console.WriteLine($@"Excelファイル新規作成時のシート削除失敗 ({openFilePath}) : {e.Message}");
            }
        }

        /// <summary>
        /// Excelファイルを新規作成する。その際、シート名を指定の名称に変更する。
        /// </summary>
        /// <param name="folderPath">新規作成Excelファイルの出力先フォルダパス</param>
        /// <param name="fileName">新規作成Excelファイルのファイル名</param>
        /// <param name="workSheetName">新規作成Excelファイルのシート名</param>
        private void MakeNewExcelFile(string folderPath, string fileName, string workSheetName)
        {
            // 新規ファイル作成
            XlBooks = XlApp.Workbooks;
            XlBook = XlBooks.Add();
            
            // シート選択、シート名変更
            XlSheets = XlBook.Worksheets;
            XlSheet = XlSheets[1] as Worksheet;
            XlSheet.Name = workSheetName;

            // Excelファイルの保存
            string outputFilePath = folderPath + "\\" + fileName;
            XlBook.SaveAs(outputFilePath);
        }

        /// <summary>
        /// 指定のファイルの末尾に指定の名称で新規ワークシートを作成する
        /// </summary>
        /// <param name="folderPath">指定ファイル格納先のフォルダパス</param>
        /// <param name="fileName">指定ファイル名</param>
        /// <param name="workSheetName">新規ワークシート名</param>
        private void MakeNewWorkSheet(string folderPath, string fileName, string workSheetName)
        {
            // 既存のExcelファイルを開く
            string openFilePath = folderPath + "\\" + fileName;
            XlBooks = XlApp.Workbooks;
            XlBook = XlBooks.Open(Path.GetFullPath(@openFilePath));

            // 末尾にシートを追加
            XlSheet = XlBook.Worksheets.Add();
            XlSheet.Select(Type.Missing);
            XlSheet.Name = workSheetName;
            int totalSheets = XlBook.Sheets.Count;
            XlSheet.Move(Type.Missing, XlBook.Worksheets[totalSheets]);
            
            // Excelファイルの保存
            string outputFilePath = folderPath + "\\" + fileName;
            XlBook.Save();
        }

        /// <summary>
        /// Excelリソース解放
        /// </summary>
        /// <param name="ReleaseMode">リリース対象Enum</param>
        private void ReleaseExcelComObject(EnumReleaseMode ReleaseMode)
        {
            try
            {
                // m_xlSheet解放
                if (XlSheet != null)
                {
                    Marshal.ReleaseComObject(XlSheet);
                }

                // m_xlSheets解放
                if (XlSheets != null)
                {
                    Marshal.ReleaseComObject(XlSheets);
                }

                // m_xlBook解放
                if (XlBook != null)
                {
                    XlBook.Close();
                    Marshal.ReleaseComObject(XlBook);
                }

                // m_xlBooks解放
                if (XlBooks != null)
                {
                    Marshal.ReleaseComObject(XlBooks);
                }

                // m_xlApp解放
                if (XlApp != null)
                {
                    XlApp.Quit();
                    Marshal.ReleaseComObject(XlApp);
                }
            }
            catch { }
            finally
            {
                // オブジェクト初期化
                XlSheet = null;
                XlSheets = null;
                XlBook = null;
                XlBooks = null;
                XlApp = null;

                // ガベージコレクションの解放
                GC.Collect();

                // Excelプロセス強制終了（GCで解放してくれないため）
                System.Diagnostics.Process[] ps = System.Diagnostics.Process.GetProcessesByName("EXCEL");
                foreach (System.Diagnostics.Process p in ps)
                {
                    p.Kill();
                }

            }
        }
    }
}
