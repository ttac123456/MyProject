﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BeaconDataEvaluator
{
    /// <summary>
    /// サマリーデータ構造体
    /// </summary>
    public struct StSummryData
    {
        public string FilePath;             ///< 格納パス
        public List<string> FileNameList;   ///< 各サマリーファイル名リスト
    }


}
