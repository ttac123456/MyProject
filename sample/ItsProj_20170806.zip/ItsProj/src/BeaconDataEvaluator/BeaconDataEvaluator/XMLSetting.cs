﻿using System.Collections.Generic;

namespace BeaconDataEvaluator
{
    /// <summary>
    /// ビーコンデータ評価ツール設定情報クラス
    /// </summary>
    [System.Xml.Serialization.XmlRoot("XMLSetting")]
    public class XMLSetting
    {
        /// <summary>
        /// DB接続情報
        /// </summary>
        [System.Xml.Serialization.XmlElement("DatabaseConnection")]
        public DatabaseConnection databaseConnection { get; set; }

        /// <summary>
        /// MAP作成情報
        /// </summary>
        [System.Xml.Serialization.XmlElement("MapMaker")]
        public MapMaker mapMaker { get; set; }
    }

    /// <summary>
    /// DB接続情報クラス
    /// </summary>
    public class DatabaseConnection
    {
        /// <summary>
        /// サーバー名称
        /// </summary>
        [System.Xml.Serialization.XmlElement("ServerName")]
        public string ServerName { get; set; }

        /// <summary>
        /// ポート番号
        /// </summary>
        [System.Xml.Serialization.XmlElement("PortName")]
        public string PortName { get; set; }

        /// <summary>
        /// ユーザーID
        /// </summary>
        [System.Xml.Serialization.XmlElement("UserId")]
        public string UserId { get; set; }

        /// <summary>
        /// パスワード
        /// </summary>
        [System.Xml.Serialization.XmlElement("Password")]
        public string Password { get; set; }

        /// <summary>
        /// DB名称
        /// </summary>
        [System.Xml.Serialization.XmlElement("DatabaseName")]
        public string DatabaseName { get; set; }
    }

    /// <summary>
    /// MAP作成情報クラス
    /// </summary>
    public class MapMaker
    {
        /// <summary>
        /// 画像描画完了ディレイ(秒)
        /// </summary>
        [System.Xml.Serialization.XmlElement("ImageDrawCompletionDelaySec")]
        public string ImageDrawCompletionDelaySec { get; set; }

    }
}
