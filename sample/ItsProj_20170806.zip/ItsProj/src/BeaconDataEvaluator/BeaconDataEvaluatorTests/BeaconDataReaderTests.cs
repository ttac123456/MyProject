﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using BeaconDataEvaluator;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BeaconDataEvaluator.Tests
{
    [TestClass()]
    public class BeaconDataReaderTests
    {
        [TestMethod()]
        public void BeaconDataReaderTest()
        {
            var beaconDataReader = new BeaconDataReader();
            Assert.IsNotNull(beaconDataReader);
        }

        [TestMethod()]
        public void ReadTest()
        {
            var beaconDataReader = new BeaconDataReader();
            string filepath = @"../../test.dat";
            byte[] readBuf;
            beaconDataReader.Read(filepath, out readBuf);
            Assert.IsNotNull(readBuf);
            Assert.AreEqual(9, readBuf.Count());
        }

        [TestMethod()]
        public void GetBitFieldDataTest()
        {
            var beaconDataReader = new BeaconDataReader();
            string filepath = @"../../test.dat";
            byte[] readBuf;
            beaconDataReader.Read(filepath, out readBuf);
            // ビットフィールドデータ取得テスト
            ulong resultValue;
            BeaconDataReader.Results result;
            result = beaconDataReader.GetBitFieldData(readBuf, 0, 0, 2, out resultValue);
            Assert.AreEqual(BeaconDataReader.Results.Success, result);
            result = beaconDataReader.GetBitFieldData(readBuf, 0, 2, 2, out resultValue);
            Assert.AreEqual(BeaconDataReader.Results.Success, result);
            result = beaconDataReader.GetBitFieldData(readBuf, 0, 4, 4, out resultValue);
            Assert.AreEqual(BeaconDataReader.Results.Success, result);
            result = beaconDataReader.GetBitFieldData(readBuf, 1, 0, 4, out resultValue);
            Assert.AreEqual(BeaconDataReader.Results.Success, result);
            result = beaconDataReader.GetBitFieldData(readBuf, 1, 4, 8, out resultValue);
            Assert.AreEqual(BeaconDataReader.Results.Success, result);
            result = beaconDataReader.GetBitFieldData(readBuf, 2, 4, 4, out resultValue);
            Assert.AreEqual(BeaconDataReader.Results.Success, result);
            result = beaconDataReader.GetBitFieldData(readBuf, 3, 0, 8, out resultValue);
            Assert.AreEqual(BeaconDataReader.Results.Success, result);
            result = beaconDataReader.GetBitFieldData(readBuf, 4, 0, 28, out resultValue);
            Assert.AreEqual(BeaconDataReader.Results.Success, result);
            result = beaconDataReader.GetBitFieldData(readBuf, 0, 4, 32, out resultValue);
            Assert.AreEqual(BeaconDataReader.Results.Success, result);
            result = beaconDataReader.GetBitFieldData(readBuf, 0, 4, 64, out resultValue);
            Assert.AreEqual(BeaconDataReader.Results.Success, result);
            result = beaconDataReader.GetBitFieldData(readBuf, 0, 4, 68, out resultValue);
            Assert.AreEqual(BeaconDataReader.Results.LengthError, result);

        }
    }
}