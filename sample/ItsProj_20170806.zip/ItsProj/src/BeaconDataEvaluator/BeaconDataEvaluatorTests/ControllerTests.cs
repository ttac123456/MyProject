﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using BeaconDataEvaluator;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BeaconDataEvaluator.Tests
{
    [TestClass()]
    public class ControllerTests
    {
        [TestMethod()]
        public void ControllerTest()
        {
            //Assert.Fail();
        }

        [TestMethod()]
        public void StartTest()
        {
            //Assert.Fail();
        }

        [TestMethod()]
        public void CancelTest()
        {
            //Assert.Fail();
        }
    }
}