﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using BeaconDataEvaluator;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BeaconDataEvaluator.Tests
{
    [TestClass()]
    public class DataExporterTests
    {
        [TestMethod()]
        public void makeExporteFilepathTest()
        {
            var dataBaseAccessor = new DatabaseAccessor();

            var exporteFilepath1 = DataExporter.makeExporteFilepath(1, dataBaseAccessor, DataExporter.ExportType.EvalResults);         ///< 評価結果
            var exporteFilepath2 = DataExporter.makeExporteFilepath(1, dataBaseAccessor, DataExporter.ExportType.NGCountByCategory);   ///< カテゴリ別NG件数カウント結果
            var exporteFilepath3 = DataExporter.makeExporteFilepath(1, dataBaseAccessor, DataExporter.ExportType.EvalResultNGCount);   ///< 評価結果NG項目
            var exporteFilepath4 = DataExporter.makeExporteFilepath(1, dataBaseAccessor, DataExporter.ExportType.SyncOffsetSignal);    ///< オフセット信号同期
            var exporteFilepath5 = DataExporter.makeExporteFilepath(1, dataBaseAccessor, DataExporter.ExportType.MapHTML);             ///< 地図HTML
            var exporteFilepath6 = DataExporter.makeExporteFilepath(1, dataBaseAccessor, DataExporter.ExportType.MapImage);            ///< 地図画像
            var exporteFilepath7 = DataExporter.makeExporteFilepath(1, dataBaseAccessor, DataExporter.ExportType.LocationInfoByRoute); ///< 路線別位置情報
        }
    }
}