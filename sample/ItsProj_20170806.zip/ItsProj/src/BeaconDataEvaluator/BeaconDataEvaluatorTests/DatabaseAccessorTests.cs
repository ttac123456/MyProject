﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using BeaconDataEvaluator;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BeaconDataEvaluator.Tests
{
    [TestClass()]
    public class DatabaseAccessorTests
    {
        [TestMethod()]
        public void ReferenceTableTest()
        {
            var dataBaseAccessor = new DatabaseAccessor();
            Assert.IsNotNull(dataBaseAccessor);
            var ReferencePrefectureId = dataBaseAccessor.ReferencePrefectureId(@"北海道");
            Assert.IsNotNull(ReferencePrefectureId);
        }

        [TestMethod()]
        public void InsertTableTest()
        {
            int driving_info_id = 1;
            int prefecture_id = 2;
            int route_num = 3;
            DateTime driving_datetime = DateTime.Now;
            string driving_datetime_string = driving_datetime.ToString("yyyy-MM-dd HH:mm:ss.fff");
            int specification_version = 0;

            var sqlCommand = @"insert into driving_info_t ";
            sqlCommand += @"driving_info_id, prefecture_id, route_num, driving_datetime, specification_version ";
            sqlCommand += @"values ";
            sqlCommand += driving_info_id.ToString() + ", ";
            sqlCommand += prefecture_id.ToString() + ", ";
            sqlCommand += route_num.ToString() + ", ";
            sqlCommand += driving_datetime_string + ", ";
            sqlCommand += specification_version.ToString();

            //SELECT TO_CHAR(timing,'yyyy/mm/dd hh24:mi:ss:us') FROM DateTimeTest





            //var dataBaseAccessor = new DatabaseAccessor();
            //var insertTableResult = dataBaseAccessor.InsertTable(sqlCommand);
            //Assert.IsFalse(insertTableResult);
        }
    }
}