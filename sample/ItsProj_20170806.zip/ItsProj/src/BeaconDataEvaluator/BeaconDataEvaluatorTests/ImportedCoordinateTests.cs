﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using BeaconDataEvaluator;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//using BeaconDataEvaluator;

namespace BeaconDataEvaluator.Tests
{
    [TestClass()]
    public class ImportedCoordinateTests
    {
        [TestMethod()]
        public void DistanceTest()
        {
            var impCoordinate1 = new ImportedCoordinate();
            Assert.AreEqual(0, impCoordinate1.Coordinate.X);
            Assert.AreEqual(0, impCoordinate1.Coordinate.Y);
            Assert.AreEqual(0, impCoordinate1.Destination);
            Assert.AreEqual(0, impCoordinate1.DistanceCoordinate);
            Assert.AreEqual(0, impCoordinate1.DistanceDestination);
            Assert.AreEqual(0, impCoordinate1.OriginalCoordinateIndex);

            var point2 = new Point(100, 200);
            var impCoordinate2 = new ImportedCoordinate(point2);
            Assert.AreEqual(100, impCoordinate2.Coordinate.X);
            Assert.AreEqual(200, impCoordinate2.Coordinate.Y);
            Assert.AreEqual(0, impCoordinate2.Destination);
            Assert.AreEqual(0, impCoordinate2.DistanceCoordinate);
            Assert.AreEqual(0, impCoordinate2.DistanceDestination);
            Assert.AreEqual(0, impCoordinate2.OriginalCoordinateIndex);

            var impCoordinate3 = new ImportedCoordinate(300, 400);
            Assert.AreEqual(300, impCoordinate3.Coordinate.X);
            Assert.AreEqual(400, impCoordinate3.Coordinate.Y);
            Assert.AreEqual(0, impCoordinate3.Destination);
            Assert.AreEqual(0, impCoordinate3.DistanceCoordinate);
            Assert.AreEqual(0, impCoordinate3.DistanceDestination);
            Assert.AreEqual(0, impCoordinate3.OriginalCoordinateIndex);

            impCoordinate2.Destination = 3;
            impCoordinate2.DistanceCoordinate = 4;
            impCoordinate2.DistanceDestination = 5;
            impCoordinate2.OriginalCoordinateIndex = 6;
            var impCoordinate4 = new ImportedCoordinate(impCoordinate2);
            Assert.AreEqual(100, impCoordinate4.Coordinate.X);
            Assert.AreEqual(200, impCoordinate4.Coordinate.Y);
            Assert.AreEqual(3, impCoordinate4.Destination);
            Assert.AreEqual(4, impCoordinate4.DistanceCoordinate);
            Assert.AreEqual(5, impCoordinate4.DistanceDestination);
            Assert.AreEqual(6, impCoordinate4.OriginalCoordinateIndex);
        }
    }
}