﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using BeaconDataEvaluator;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BeaconDataEvaluator.Tests
{
    [TestClass()]
    public class IntersectionHtmlBrowserTests
    {
        [TestMethod()]
        public void SetHtmlFilepathTest()
        {
            //var dispatcher = new System.Windows.Threading.Dispatcher();
            //var browser = new IntersectionHtmlBrowser(dispatcher);
            var browser = new IntersectionHtmlBrowser(null);
            var value = new byte[2];
            value[0] = 0;
            value[1] = 1;
        }
    }
}