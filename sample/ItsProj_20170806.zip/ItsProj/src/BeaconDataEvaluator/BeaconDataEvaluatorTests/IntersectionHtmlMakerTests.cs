﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using BeaconDataEvaluator;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BeaconDataEvaluator.Tests
{
    [TestClass()]
    public class IntersectionHtmlMakerTests
    {
        [TestMethod()]
        public void ExtractMarkerImagesTest_Create()
        {
            //var dataBaseAccessor = new DatabaseAccessor();
            //var htmlMaker = new IntersectionHtmlMaker(dataBaseAccessor);
            //Assert.IsNotNull(htmlMaker);
        }

        [TestMethod()]
        public void CalculateLocationInformationByRouteTest()
        {
            //var dataBaseAccessor = new DatabaseAccessor();
            //var htmlMaker = new IntersectonHtmlMaker(dataBaseAccessor);
            //List<DatabaseAccessor.StIntersectionInfo> intersectionInfos;
            //List<ImportedCoordinate> ImportedCoordinates;
            //htmlMaker.CalculateLocationInformationByRoute(out intersectionInfos, out ImportedCoordinates);
        }

        [TestMethod()]
        public void StartTest()
        {
            //var dataBaseAccessor = new DatabaseAccessor();
            //var htmlMaker = new IntersectionHtmlMaker(dataBaseAccessor);
            //string inputPath = @"C:\光インフラデータ\INPUT";
            //string destinationPath = @"C:\光インフラデータ\OUTPUT\";
            //htmlMaker.Start(inputPath, destinationPath);
        }

        [TestMethod()]
        public void StartWithIntersectionCoordinatesTest()
        {
            //var dataBaseAccessor = new DatabaseAccessor();
            //var htmlMaker = new IntersectonHtmlMaker(dataBaseAccessor);
            //string inputPath = @"C:\光インフラデータ\INPUT";
            //string destinationPath = @"C:\光インフラデータ\OUTPUT\";
            //List<DatabaseAccessor.StIntersectionInfo> intersectionInfos;
            //List<ImportedCoordinate> ImportedCoordinates;
            //htmlMaker.CalculateLocationInformationByRoute(out intersectionInfos, out ImportedCoordinates);
            //htmlMaker.Start(inputPath, destinationPath, intersectionInfos, ImportedCoordinates);
        }

        [TestMethod()]
        public void chooseNearestCoordinateTest()
        {
            //var originalCoordinates = new List<DatabaseAccessor.StIntersectionInfo>();
            //DatabaseAccessor.StIntersectionInfo originalCoordinate;

            //// [34.166844,131.481086,'宮島町交差点'],
            //originalCoordinate = new DatabaseAccessor.StIntersectionInfo();
            //originalCoordinate.Id = 1;                              // 交差点情報ID
            //originalCoordinate.LatitudeTrueValue = 34.166844;       // 緯度(真値)
            //originalCoordinate.LongitudeTrueValue = 131.481086;     // 経度(真値)
            //originalCoordinates.Add(originalCoordinate);

            //// [34.167194,131.478786,'宮島町バス停先'],
            //originalCoordinate = new DatabaseAccessor.StIntersectionInfo();
            //originalCoordinate.Id = 2;
            //originalCoordinate.LatitudeTrueValue = 34.167194;
            //originalCoordinate.LongitudeTrueValue = 131.478786;
            //originalCoordinates.Add(originalCoordinate);

            //// [34.167744,131.478024,'新鰐石橋南詰交差点'],
            //originalCoordinate = new DatabaseAccessor.StIntersectionInfo();
            //originalCoordinate.Id = 3;
            //originalCoordinate.LatitudeTrueValue = 34.167744;
            //originalCoordinate.LongitudeTrueValue = 131.478024;
            //originalCoordinates.Add(originalCoordinate);

            //// [34.169402,131.476049,'山口駅入口交差点'],
            //originalCoordinate = new DatabaseAccessor.StIntersectionInfo();
            //originalCoordinate.Id = 4;
            //originalCoordinate.LatitudeTrueValue = 34.169402;
            //originalCoordinate.LongitudeTrueValue = 131.476049;
            //originalCoordinates.Add(originalCoordinate);

            //// [34.170594,131.474761,'旭通り交差点'],
            //originalCoordinate = new DatabaseAccessor.StIntersectionInfo();
            //originalCoordinate.Id = 5;
            //originalCoordinate.LatitudeTrueValue = 34.170594;
            //originalCoordinate.LongitudeTrueValue = 131.474761;
            //originalCoordinates.Add(originalCoordinate);

            //// [34.172277,131.472786,'荒高交差点'],
            //originalCoordinate = new DatabaseAccessor.StIntersectionInfo();
            //originalCoordinate.Id = 6;
            //originalCoordinate.LatitudeTrueValue = 34.172277;
            //originalCoordinate.LongitudeTrueValue = 131.472786;
            //originalCoordinates.Add(originalCoordinate);

            //// [34.173777,131.471049,'中央交差点']
            //originalCoordinate = new DatabaseAccessor.StIntersectionInfo();
            //originalCoordinate.Id = 7;
            //originalCoordinate.LatitudeTrueValue = 34.173777;
            //originalCoordinate.LongitudeTrueValue = 131.471049;
            //originalCoordinates.Add(originalCoordinate);


            //var importedCoordinates = new List<ImportedCoordinate>();
            //ImportedCoordinate importedCoordinate;

            //// [34.167744,131.478024,'交差点位置情報(3)_取得データ'],
            //importedCoordinate = new ImportedCoordinate();
            //importedCoordinate.Coordinate = new Point(34.167744, 131.478024);   // インポートされた座標
            //importedCoordinates.Add(importedCoordinate);

            //// [34.169402,131.476049,'交差点位置情報(4)_取得データ'],
            //importedCoordinate = new ImportedCoordinate();
            //importedCoordinate.Coordinate = new Point(34.169402, 131.476049);
            //importedCoordinates.Add(importedCoordinate);

            //// [34.170594,131.474761,'交差点位置情報(5)_取得データ'],
            //importedCoordinate = new ImportedCoordinate();
            //importedCoordinate.Coordinate = new Point(34.170594, 131.47476);
            //importedCoordinates.Add(importedCoordinate);

            //// [34.172277,131.472786,'交差点位置情報(6)_取得データ'],
            //importedCoordinate = new ImportedCoordinate();
            //importedCoordinate.Coordinate = new Point(34.172277, 131.472786);
            //importedCoordinates.Add(importedCoordinate);

            //// [34.173777,131.471049,'交差点位置情報(7)_取得データ']
            //importedCoordinate = new ImportedCoordinate();
            //importedCoordinate.Coordinate = new Point(34.173777, 131.471049);
            //importedCoordinates.Add(importedCoordinate);


            //IntersectonHtmlMaker.chooseNearestCoordinate(originalCoordinates, ref importedCoordinates);
        }

        [TestMethod()]
        public void MakeImageFilePathTest()
        {
            //var dataBaseAccessor = new DatabaseAccessor();
            //var htmlMaker = new IntersectonHtmlMaker(dataBaseAccessor);
            //string imageFilePath = htmlMaker.makeImageFilePath();
            //string destinationPath = @"c:\aaa\bbb";
            //string dstHtmlFilePath = System.IO.Path.Combine(destinationPath, System.IO.Path.ChangeExtension(htmlMaker.makeImageFilePath(), @"htm"));
        }
    }
}