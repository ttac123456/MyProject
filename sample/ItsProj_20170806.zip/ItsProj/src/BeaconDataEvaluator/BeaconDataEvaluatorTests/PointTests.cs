﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using BeaconDataEvaluator;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BeaconDataEvaluator.Tests
{
    [TestClass()]
    public class PointTests
    {
        [TestMethod()]
        public void PointTest()
        {
            var p1 = new Point();
            Assert.AreEqual(p1.X, 0);
            Assert.AreEqual(p1.Y, 0);
            Assert.AreEqual(p1.ToString(), "(0, 0)");

            var p2 = new Point(100, 200);
            Assert.AreEqual(p2.X, 100);
            Assert.AreEqual(p2.Y, 200);
            Assert.AreEqual(p2.ToString(), "(100, 200)");

            var p3 = new Point(p2);
            Assert.AreEqual(p3.X, 100);
            Assert.AreEqual(p3.Y, 200);
            Assert.AreNotEqual(p3, p2);
            Assert.AreEqual(p3.ToString(), "(100, 200)");

            var p4 = new Point();
            p4 = p2;
            Assert.AreEqual(p4.X, 100);
            Assert.AreEqual(p4.Y, 200);
            Assert.AreEqual(p4, p2);
            Assert.AreEqual(p4.ToString(), "(100, 200)");
        }
    }
}